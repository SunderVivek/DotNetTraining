﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Intern_Project.Models;

 

namespace Intern_Project.Controllers
{
    public class HomeController : Controller
    {

        
       
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

       
        [HttpPost]
        public ActionResult Login(string email,string password,bool rememberme)
        {
            EmployeeDAL dal = new EmployeeDAL();
           
             if (Membership.ValidateUser(email, password))
             {
                 FormsAuthentication.SetAuthCookie(email, rememberme);
                 string designation= dal.GetDesignation(email);
                  EmployeeModel model=dal.GetProfile(Convert.ToInt32(email));   //getting name
                  ViewBag.name = model.FirstName;
                 if (designation == "ProjectManager")
                     return View("Home","ProjectManagerLayout");
                 else if (designation == "RecruitmentManager")
                     return View("Home", "RecruiterLayout");
                 
                 else if(designation == "HRManager")
                     return View("Home", "HRManagerLayout");
                 else
                     return View("Home","EmployeeLayout");
             }
            
            else
            {
                ViewBag.msg = "Invalid";
                return View();
            }
        }

        [HttpPost]
        public ActionResult Chart()
        {
            return PartialView();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }



       public ActionResult EmployeeProfile(int empid = 0)
       {
           EmployeeDAL dal = new EmployeeDAL();
           EmployeeModel model;
           if (empid == 0 || empid == Convert.ToInt32(User.Identity.Name))  // or(basically dafault parameter)
           {                                                                   //condition as we may get a search of our own profile
               model = dal.GetProfile(Convert.ToInt32(User.Identity.Name));
               return PartialView(model);
            
           }
           else
           {
               model = dal.GetProfile(empid);
           }
           List<SelectListItem> skillset = new List<SelectListItem>();
           foreach (string s in model.EmployeeSkillSet)
           {
               skillset.Add(new SelectListItem { Text = s });
           }
           ViewBag.skillset = skillset;

           return PartialView(model);
       }


       
      [AllowAnonymous]        
     public ActionResult AddCandidate()
       {           
           List<SelectListItem> domainlist = new List<SelectListItem>();
          ProjectInfoDAL dal=new ProjectInfoDAL();
          List<Projectlist> projlist = dal.GetProjectDomain();
           foreach (Projectlist item in projlist)
           {
              domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
          }
           ViewBag.domainlist = domainlist;
           return View();
      }

       [HttpPost]
       [AllowAnonymous]
      public ActionResult AddCandidate(CandidateModel model, HttpPostedFileBase candidateimage)
       {
           List<SelectListItem> domainlist = new List<SelectListItem>();
           ProjectInfoDAL dal = new ProjectInfoDAL();
           List<Projectlist> projlist = dal.GetProjectDomain();
           foreach (Projectlist item in projlist)
           {
               domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
           }
           ViewBag.domainlist = domainlist;
           
           
           CandidateDAL candidate_dal = new CandidateDAL();
           if (candidate_dal.AddCandidate(model))
           {
               candidateimage.SaveAs(Server.MapPath(model.CandidateImage));

               ViewBag.msg = "Candidate Added";
               ModelState.Clear();
               return View();
           }
           else
           {
               ViewBag.msg = "Candidate Not Added";
               return View();
           }
       }

       [AllowAnonymous]
       public ActionResult AddEmployee()
       {
           return View();
       }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult AddEmployee(EmployeeModel model, HttpPostedFileBase employeeimage)
       {
           EmployeeDAL dal = new EmployeeDAL();
           if (dal.AddEmployee(model))
           {
               employeeimage.SaveAs(Server.MapPath(""+model.EmployeeImageUrl));
               ViewBag.msg = "Employee Added";
               ModelState.Clear();
               return View();
           }
           else
           {
               ViewBag.msg = "Employee Not Added";
               return View();
           }
       }

        [AllowAnonymous]
        public ActionResult InitiateProject()
        {
            List<SelectListItem> domainlist = new List<SelectListItem>();
            ProjectInfoDAL obj = new ProjectInfoDAL();
            List<Projectlist> list = obj.GetProjectDomain();
                       
            foreach (Projectlist item in list)
            {
                domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
            }
            ViewBag.domainlist = domainlist;
            return PartialView();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult InitiateProject(ProjectInfo model)
        {
            List<SelectListItem> domainlist = new List<SelectListItem>();
            ProjectInfoDAL obj = new ProjectInfoDAL();
            List<Projectlist> list = obj.GetProjectDomain();
            model.ProjectManagerID = Convert.ToInt32(User.Identity.Name);
            foreach (Projectlist item in list)
            {
                domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
            }
            ViewBag.domainlist = domainlist;
            
            ProjectInfoDAL dal = new ProjectInfoDAL();
            ViewBag.status = dal.NewProject(model);
            ModelState.Clear(); //Clears data in HTML

            return PartialView();
        }
       
       public ActionResult NewRecruit()
       {
           return View();
       }
              
      
        public ActionResult Search()
        {

            return PartialView();
        }

        [HttpPost]
        public ActionResult Search(string SearchEmpName)
        {
            EmployeeDAL dal = new EmployeeDAL();
            List<EmployeeModel> searchlist = dal.SearchProfile(SearchEmpName,0);    //flag=0 since getting emplist based on name
            if (searchlist.Count==0)
            {
                ViewBag.msg = "Employee Not Found";
                return PartialView();
            }
            return PartialView("SearchProfile", searchlist);
        }

        public ActionResult ContactHR()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult ContactHR(string query)
        {
            if (query == "Resignation")
                return PartialView("Resignation");
            else if (query == "Leave Request")
                return PartialView("LeaveRequest");
            else if (query == "Project Change")
                return RedirectToAction("ProjectChange");
            else
                return PartialView();
        }

       

        [HttpPost]
        public ActionResult Resignation(string Reason)  //Create model and invoke dal
        {
            EmployeeDAL dal = new EmployeeDAL();
            
            Resignation model = new Resignation();
            model.EmployeeID = Convert.ToInt32(User.Identity.Name);
            model.Reason = Reason;
            if (dal.ResignationRequest(model))
                return Json("Resignation Request Succesful");
            else
                return Json("Resignation Request Unsuccesful");
        }

        
        [HttpPost]
        public ActionResult LeaveRequest(DateTime LeaveDate, string Reason) 
        {
            EmployeeDAL dal = new EmployeeDAL();
            LeaveReqModel model = new LeaveReqModel();
            model.EmployeeID = Convert.ToInt32(User.Identity.Name);
            model.leavedate = LeaveDate;
            model.reason = Reason;

            if (dal.ApplyLeave(model))
            {
                return Json("Leave Request succesful!");
            }
            else
            {
                return Json("Leave Request Not Succesful");
            }
        }
        
        public ActionResult LeaveList()
        {
            EmployeeDAL dal = new EmployeeDAL();
            List<LeaveReqModel> model = dal.GetLeaveList();
            return PartialView(model);
            
        }

        [HttpPost]
        public ActionResult ApproveLeave(int EmployeeID)
        {
            EmployeeDAL dal = new EmployeeDAL();
            if(dal.ApproveLeave(EmployeeID, true))
                return Json("Leave Approved");
            else
                return Json("Leave Not Approved");
        }

        public ActionResult ResignationList()
        {
            //get list from dal
            EmployeeDAL dal = new EmployeeDAL();
            List<Resignation> ResignationList = dal.GetResignationList();   

            return PartialView("ApproveResignation",ResignationList);
        }
        [HttpPost]
        public ActionResult ApproveResignation(int EmployeeID)
        {
            EmployeeDAL dal = new EmployeeDAL();
            if (dal.ResignationApproval(EmployeeID))
            {
                return Json("Resignation Approved");
            }
            else
            {
                return Json("Resignation not Succesfully Approved");
            }
        }
        
        public ActionResult ProjectChange()
        {
            List<SelectListItem> domainlist = new List<SelectListItem>();
            ProjectInfoDAL obj = new ProjectInfoDAL();
            List<Projectlist> list = obj.GetProjectDomain();

            foreach (Projectlist item in list)
            {
                domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
            }
            ViewBag.domainlist = domainlist;
            return PartialView();
        }
        [HttpPost]
        public ActionResult ProjectChange(string Reason, ProjectInfo obj)
        {
            List<SelectListItem> domainlist = new List<SelectListItem>();
            ProjectInfoDAL dal = new ProjectInfoDAL();
            List<Projectlist> list = dal.GetProjectDomain();
                      
            foreach (Projectlist item in list)
            {
                domainlist.Add(new SelectListItem { Text = item.projdomain, Value = item.DomainID.ToString() });
            }
            ViewBag.domainlist = domainlist;

            string interesteddomain=obj.Project_Domain;


            EmployeeDAL empdal= new EmployeeDAL();
            if(empdal.ProjChangeReq(Convert.ToInt32(User.Identity.Name),interesteddomain,Reason))
                return Json("Project Change Request Succesful");
            else
                return Json("Project Change Request Unsuccesful");
        }

        public ActionResult ManageProject()
        {

            return PartialView();
        }
        [HttpPost]
        public ActionResult ManageProject(string managing)
        {
            if (managing == "SearchProject")
                return PartialView("SearchProject");
            else //this is default ..check
            {
                ProjectInfoDAL dal = new ProjectInfoDAL();

                int projectid = dal.GetProjectID(Convert.ToInt32(User.Identity.Name));
                ProjectInfo model= dal.GetProject(projectid);
                return PartialView("ProjectDetails",model);            
            } 
                
        }

        [HttpPost]
        public ActionResult SearchProject(int projectid)
        {
            ProjectInfoDAL dal = new ProjectInfoDAL();
            ProjectInfo model = dal.GetProject(projectid);
            return PartialView("ProjectDetails",model);
        }

    }
}
