﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Intern_Project.Models
{
    public class LeaveReqModel
    {
        public int EmployeeID{get;set;}
        public DateTime leavedate{get;set;}
        public string reason{get;set;}
        public  string status{get;set;}
    }
}
