﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Intern_Project.Models
{
    public class Resignation
    {
        public int EmployeeID{get;set;}
        public string EmployeeResignStatus{get;set;}
        public DateTime EmployeeDOJ{get;set;}
        public DateTime EmployeeDOR {get;set;}
        public string Reason{get;set;}
          
    }
}