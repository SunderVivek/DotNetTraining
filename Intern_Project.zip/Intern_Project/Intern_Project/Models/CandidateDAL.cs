﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace Intern_Project.Models
{
    public class CandidateDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddCandidate(CandidateModel model)
        {

            try
            {
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_insert_candidate = new SqlCommand("insert Candidate values(@fname,@lname,@tenth,@twelfth,@degree,null,@gender,@exp,@domain)", con);
                com_insert_candidate.Parameters.AddWithValue("@fname", model.FirstName);
                com_insert_candidate.Parameters.AddWithValue("@lname", model.LastName);
                com_insert_candidate.Parameters.AddWithValue("@tenth", model.TenthPercentage);
                com_insert_candidate.Parameters.AddWithValue("@twelfth", model.TwelfthPercentage);
                com_insert_candidate.Parameters.AddWithValue("@degree", model.DegreePercentage);
                com_insert_candidate.Parameters.AddWithValue("@gender", model.Gender);
                com_insert_candidate.Parameters.AddWithValue("@exp", model.Experience);
                com_insert_candidate.Parameters.AddWithValue("@domain", model.Domain_Applied);
                com_insert_candidate.Transaction = trans;
                con.Open();
                com_insert_candidate.ExecuteNonQuery();
                SqlCommand com_canid = new SqlCommand("select @@identity", con);
                com_canid.Transaction = trans;
                model.CandidateID = Convert.ToInt32(com_canid.ExecuteScalar());

                model.CandidateImage = "/CandidateImage/" + model.CandidateID + ".jpg";
                SqlCommand com_updatecanimg = new SqlCommand("update Candidate set CandidateImgUrl=@img where CandidateID=@cid", con);
                com_updatecanimg.Parameters.AddWithValue("@img", model.CandidateImage);
                com_updatecanimg.Parameters.AddWithValue("@cid", model.CandidateID);
                com_updatecanimg.Transaction = trans;
                com_updatecanimg.ExecuteNonQuery();

                trans.Commit();
                return true;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();

                }
            }
        }
    }
}