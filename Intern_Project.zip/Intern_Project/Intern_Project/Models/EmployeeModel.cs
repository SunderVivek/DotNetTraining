﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Intern_Project.Models
{
    public class EmployeeModel
    {
        public int EmployeeID { get; set; }

        [Display(Name = "Employee FirstName")]
        public String FirstName { get; set; }

        [Display(Name = "Employee LastName")]
        public String LastName { get; set; }
        
        [Display(Name="Employee Image")]
        public string EmployeeImageUrl { get; set; }

        [Display(Name = "Employee Designation")]
        public string EmployeeDesignation { get; set; }

        [Display(Name = "Employee Date of Joining")]
        public DateTime EmployeeDOJ { get; set; }

        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Display(Name = "Experience")]
        public int Experience { get; set; }

        [Display(Name = "Employee Salary")]
        public int EmployeeSalary { get; set; }

        [Display(Name = "Manager ID")]
        public int ManagerID { get; set; }

        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "EmployeeEmailAddress")]
        public string EmployeeEmailAddress { get; set; }

        [Display(Name = "SecurityQuestion")]
        public string SecurityQuestion { get; set; }

        [Display(Name = "SecurityAnswer")]
        public string SecurityAnswer { get; set; }

        public List<string> EmployeeSkillSet { get; set; }
      
    }
}
/*
Create table Employee 
(
EmployeeID int identity(2500,1) primary key,
EmployeeFName varchar(20) not null,
EmployeeLName varchar(20) not null,
EmployeeImageUrl varchar(50) not null,
EmployeeDesignation varchar(20),
EmployeeDOJ Datetime,
Gender varchar(10),
EmployeeExperience int,
EmployeeSalary int,
ManagerID int foreign key references Employee(EmployeeID) null
)*/
