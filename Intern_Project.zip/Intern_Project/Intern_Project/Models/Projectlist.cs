﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Intern_Project.Models
{
    public class Projectlist
    {
        public int DomainID { get; set; }
        public string projdomain { get; set; }
    }
}