﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Security;

namespace Intern_Project.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool AddEmployee(EmployeeModel emp)
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_insert_employee = new SqlCommand("insert employee values(@empfname,@emplname,null,@empdesign,@empdoj,@gender,@empexp,@empsal,null)", con);
                com_insert_employee.Parameters.AddWithValue("@empfname", emp.FirstName);
                com_insert_employee.Parameters.AddWithValue("@emplname", emp.LastName);
                com_insert_employee.Parameters.AddWithValue("@empdesign", emp.EmployeeDesignation);
                com_insert_employee.Parameters.AddWithValue("@gender", emp.Gender);
                com_insert_employee.Parameters.AddWithValue("@empdoj", emp.EmployeeDOJ);
                com_insert_employee.Parameters.AddWithValue("@empexp", emp.Experience);
                com_insert_employee.Parameters.AddWithValue("@empsal", emp.EmployeeSalary);
                //com_insert_employee.Parameters.AddWithValue("@mid", emp.ManagerID);
                com_insert_employee.Transaction = trans;
                com_insert_employee.ExecuteNonQuery();

                SqlCommand com_employeeid = new SqlCommand("select @@identity", con);
                com_employeeid.Transaction = trans;
                emp.EmployeeID = Convert.ToInt32(com_employeeid.ExecuteScalar());

                emp.EmployeeImageUrl = "/EmployeeImage/" + emp.EmployeeID + ".jpg";
                SqlCommand com_update_empimg = new SqlCommand("update Employee set EmployeeImageUrl=@img where EmployeeID=@empid", con);
                com_update_empimg.Parameters.AddWithValue("@img", emp.EmployeeImageUrl);
                com_update_empimg.Parameters.AddWithValue("@empid", emp.EmployeeID);
                com_update_empimg.Transaction = trans;
                com_update_empimg.ExecuteNonQuery();
                MembershipCreateStatus status;
                Membership.CreateUser(emp.EmployeeID.ToString(), emp.Password,emp.EmployeeEmailAddress, emp.SecurityQuestion, emp.SecurityAnswer, true, out status);
                if (status == MembershipCreateStatus.Success)
                {
                    trans.Commit();
                    return true;
                }
                else
                {
                    trans.Rollback();
                    return false;
                }
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public string GetDesignation(string EmpID)
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_getdesignation = new SqlCommand("select EmployeeDesignation from Employee where EmployeeID=@empid", con);
                com_getdesignation.Parameters.AddWithValue("@empid", Convert.ToInt32(EmpID));
                
                com_getdesignation.Transaction = trans;
                string designation = Convert.ToString(com_getdesignation.ExecuteScalar());
                        
                trans.Commit();
                
                return designation;
            }
                          
            
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            
        }
        public EmployeeModel GetProfile(int EmployeeID)
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            try
            {
                SqlCommand com_getprofile = new SqlCommand("select * from Employee where EmployeeID=@empid", con);
                com_getprofile.Parameters.AddWithValue("@empid", EmployeeID);
                
                com_getprofile.Transaction = trans;
                SqlDataReader dr = com_getprofile.ExecuteReader();
                EmployeeModel model = null;
                if (dr.Read())
                {
                    model = new EmployeeModel();
                    model.EmployeeID = dr.GetInt32(0);
                    model.FirstName = dr.GetString(1);
                    model.LastName = dr.GetString(2);
                    model.EmployeeImageUrl = dr.GetString(3);
                    model.EmployeeDesignation = dr.GetString(4);
                    model.EmployeeDOJ = dr.GetDateTime(5);
                    model.Gender = dr.GetString(6);
                    model.Experience = dr.GetInt32(7);
                    model.EmployeeSalary = dr.GetInt32(8);
                  //  model.ManagerID = dr.GetInt32(9);

                    SqlCommand com_getskillset = new SqlCommand("select EmployeeSkill from EmployeeSkillset where EmployeeID=@empid", con);
                    com_getskillset.Parameters.AddWithValue("@empid", EmployeeID);
                    com_getskillset.Transaction = trans;
                    dr.Close();//closing datareader

                    dr = com_getskillset.ExecuteReader();
                    model.EmployeeSkillSet = new List<string>();
                    while (dr.Read())
                    {
                        string s = dr.GetString(0);
                        model.EmployeeSkillSet.Add(s);
                    }
                }
                dr.Close();
                trans.Commit();
                return model;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            
            
        }
        public List<EmployeeModel> SearchProfile(string search_type,int flag)      
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            try
            {
                SqlCommand com_getprofile;
                if (flag == 0)
                {   //get emplist by name
                    com_getprofile = new
                     SqlCommand("select * from Employee where EmployeeFName like '%" + search_type + "%' or EmployeeLName like '%" + search_type + "%'", con);
                    com_getprofile.Transaction = trans;
                }
                else if (flag == 1)
                {
                    com_getprofile = new
                      SqlCommand
                      ("select * from Employee join EmployeeSkillset on Employee.EmployeeID=EmployeeSkillset.EmployeeID where EmployeeSkillset.EmployeeSkill=@skill order by Employee.EmployeeExperience desc", con);
                    com_getprofile.Parameters.AddWithValue("@skill", search_type);
                    com_getprofile.Transaction = trans;
                    //get emplist by proj domain i.e skill set
                }
                else
                {
                    com_getprofile = new
                     SqlCommand("select * from Employee left join EmployeeProjectChangeReq on Employee.EmployeeID=EmployeeProjectChangeReq.EmployeeID where EmployeeProjectChangeReq.InterestedDomain=@interest order by Employee.EmployeeExperience desc", con);
                    com_getprofile.Parameters.AddWithValue("@interest", search_type);
                    com_getprofile.Transaction = trans;
                    //proj req table
                }
                
                SqlDataReader dr = com_getprofile.ExecuteReader();
                List<EmployeeModel> searchlist = new List<EmployeeModel>();

                while (dr.Read())
                {
                    EmployeeModel model = new EmployeeModel();
                    model.EmployeeID = dr.GetInt32(0);
                    model.FirstName = dr.GetString(1);
                    model.LastName = dr.GetString(2);
                    model.EmployeeImageUrl = dr.GetString(3);
                    model.EmployeeDesignation = dr.GetString(4);
                    model.EmployeeDOJ = dr.GetDateTime(5);
                    model.Gender = dr.GetString(6);
                    model.Experience = dr.GetInt32(7);
                    model.EmployeeSalary = dr.GetInt32(8);
                  //  model.ManagerID = dr.GetInt32(9);


                    SqlCommand com_getskillset = new SqlCommand("select EmployeeSkill from EmployeeSkillset where EmployeeID=@empid", con);
                    com_getskillset.Parameters.AddWithValue("@empid", model.EmployeeID);
                    com_getskillset.Transaction = trans;
                    dr.Close();     //closing datareader
                    dr = com_getskillset.ExecuteReader();

                    model.EmployeeSkillSet = new List<string>();
                    while (dr.Read())
                    {
                        string s = dr.GetString(0);
                        model.EmployeeSkillSet.Add(s);
                    }
                    searchlist.Add(model);
                }
                dr.Close();
                trans.Commit();
                return searchlist;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        
        }

        public bool ResignationRequest(Resignation model)
        {
            con.Open();
            SqlTransaction trans=con.BeginTransaction();
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                EmployeeModel emp=dal.GetProfile(model.EmployeeID);
                model.EmployeeDOJ = emp.EmployeeDOJ;
                SqlCommand com_resignreq = new SqlCommand("insert EmployeeResignation values(@empid,@status,@doj,null,@reason)", con);
                com_resignreq.Parameters.AddWithValue("@empid", model.EmployeeID);
                com_resignreq.Parameters.AddWithValue("@status", "Not Approved");
                com_resignreq.Parameters.AddWithValue("@doj", model.EmployeeDOJ);
                com_resignreq.Parameters.AddWithValue("@reason", model.Reason);
                com_resignreq.Transaction = trans;
                
                com_resignreq.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool ResignationApproval(int empid)//Write triggers to set designation as resigned and also (HR Manager invokess this)
        {
            try
            {
                EmployeeDAL dal = new EmployeeDAL();
                EmployeeModel model = dal.GetProfile(empid);
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_resignapproval = new SqlCommand("update EmployeeResignation set EmployeeResignStatus=@status,EmployeeDOR=getDate() where EmployeeID=@empid", con);
                com_resignapproval.Parameters.AddWithValue("@status", "Approved");
                com_resignapproval.Transaction = trans;
                
                com_resignapproval.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool ProjChangeReq(int empid, string interest,string Reason)
        {
            try
            {
                con.Open();
                SqlTransaction trans= con.BeginTransaction();
                SqlCommand com_projchangereq = new SqlCommand("insert EmployeeProjectChangeReq values(@empid,@interest,@reason)", con);
                com_projchangereq.Parameters.AddWithValue("@empid", empid);
                com_projchangereq.Parameters.AddWithValue("@interest", interest);
                com_projchangereq.Parameters.AddWithValue("@reason", Reason);
                com_projchangereq.Transaction = trans;
                
                com_projchangereq.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
       }

        public bool ApplyLeave(LeaveReqModel model)
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_leavereq = new SqlCommand("insert LeaveRequest values(@empid,@date,@reason,'pending')", con);
                com_leavereq.Parameters.AddWithValue("@empid", model.EmployeeID);
                com_leavereq.Parameters.AddWithValue("@reason", model.reason);
                com_leavereq.Parameters.AddWithValue("@date", model.leavedate);
                com_leavereq.Transaction = trans;
                com_leavereq.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            finally
            {
                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }

        public List<LeaveReqModel> GetLeaveList()
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_list_leave = new SqlCommand("select * from LeaveRequest", con);
                com_list_leave.Transaction = trans;
                SqlDataReader dr = com_list_leave.ExecuteReader();
                List<LeaveReqModel> leavelist = new List<LeaveReqModel>();
                while (dr.Read())
                {
                    LeaveReqModel leave = new LeaveReqModel();
                    leave.EmployeeID = dr.GetInt32(0);
                    leave.leavedate = dr.GetDateTime(1);
                    leave.reason = dr.GetString(2);
                    leave.status = dr.GetString(3);
                    leavelist.Add(leave);
                }
                dr.Close();
                trans.Commit();
                return leavelist;
            }
            finally
            {

                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }


        public bool ApproveLeave(int EmployeeID,bool status)
        { 
            try
            {
                string s;
                if (status)
                {
                    s = "Approved";
                }
                else
                {
                    s = "Request Cancelled";
                }
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_approveleave = new SqlCommand("update LeaveRequest set status=@status where EmployeeID=@empid", con);
                com_approveleave.Parameters.AddWithValue("@status",s);
                com_approveleave.Parameters.AddWithValue("@empid",EmployeeID);
                com_approveleave.Transaction=trans;
                com_approveleave.ExecuteNonQuery();
                trans.Commit();
                return true;
            }
            finally
            {
                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }

        }

        public List<Resignation> GetResignationList()
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_list_resign = new SqlCommand("select * from EmployeeResignation", con);
                com_list_resign.Transaction = trans;
                SqlDataReader dr = com_list_resign.ExecuteReader();
                List<Resignation> resignlist = new List<Resignation>();
                while (dr.Read())
                {
                    Resignation obj = new Resignation();
                    obj.EmployeeID = dr.GetInt32(0);
                    obj.EmployeeResignStatus = dr.GetString(1);
                    obj.EmployeeDOJ = dr.GetDateTime(2);
                    obj.Reason = dr.GetString(4);
                    resignlist.Add(obj);
                }
                dr.Close();
                trans.Commit();
                return resignlist;

            }
            finally
            {
                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }
    }
}

