﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Intern_Project.Models
{
    public class ProjectInfo
    {
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string Project_Domain { get; set; }
        public string Objective { get; set; }
        public int ProjectManagerID { get; set; }
        public int NumofTeamLeaders { get; set; }
        public int NumofTeamMembers { get; set; }
        public DateTime ProjectEndDate { get; set; }
        public DateTime ProjectStartDate { get; set; }
        public string ProjectType { get; set; }
        public string Client { get; set; }
        public string ClientType { get; set; }
    }
}