﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace Intern_Project.Models
{
    public class ProjectInfoDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public string NewProject(ProjectInfo model)   //Insert into employeeallocated and employeeprojhistory(trigger)(done)
        {
            con.Open();
          //  SqlTransaction trans = con.BeginTransaction();
            try
            {
                SqlCommand com_newProj = new SqlCommand("insert ProjectInfo values(@projname,@projdomain,@objective,@managerid,@lead,@member,@enddate,@startdate,@projtype,@client,@clienttype)", con);
                com_newProj.Parameters.AddWithValue("@projname", model.ProjectName);
                com_newProj.Parameters.AddWithValue("@projdomain", model.Project_Domain);
                com_newProj.Parameters.AddWithValue("@objective", model.Objective);
                com_newProj.Parameters.AddWithValue("@managerid", model.ProjectManagerID);
                com_newProj.Parameters.AddWithValue("@lead", model.NumofTeamLeaders);
                com_newProj.Parameters.AddWithValue("@member", model.NumofTeamMembers);
                com_newProj.Parameters.AddWithValue("@enddate", model.ProjectEndDate);
                com_newProj.Parameters.AddWithValue("@startdate", model.ProjectStartDate);
                com_newProj.Parameters.AddWithValue("@projtype", model.ProjectType);
                com_newProj.Parameters.AddWithValue("@client", model.Client);
                com_newProj.Parameters.AddWithValue("@clienttype", model.ClientType);
                //com_newProj.Transaction = trans;

                SqlCommand com_numoflead = new               
             SqlCommand("select count(*) from Employee left join EmployeeSkillset on Employee.EmployeeID= EmployeeSkillset.EmployeeID where Employee.EmployeeDesignation=@desig and EmployeeSkillset.EmployeeSkill=@skill"
                        , con);
                com_numoflead.Parameters.AddWithValue("@desig", "TeamLeader");
                com_numoflead.Parameters.AddWithValue("@skill", model.Project_Domain);
            //    com_numoflead.Transaction = trans;

                SqlCommand com_numofmem = new               
             SqlCommand("select count(*) from Employee left  join EmployeeSkillset on Employee.EmployeeID= EmployeeSkillset.EmployeeID where Employee.EmployeeDesignation=@desig and EmployeeSkillset.EmployeeSkill=@skill"
                        , con);
                com_numofmem.Parameters.AddWithValue("@desig", "TeamMember");
                com_numofmem.Parameters.AddWithValue("@skill", model.Project_Domain);
            //    com_numofmem.Transaction = trans;

                
                int check_lead = Convert.ToInt32(com_numoflead.ExecuteScalar());
                int check_mem = Convert.ToInt32(com_numofmem.ExecuteScalar());
                int lead = 0, member = 0;
                List<EmployeeModel> resources = new List<EmployeeModel>();    //Resources to be allocated

                if (check_lead >= model.NumofTeamLeaders)
                {
                    if (check_mem >= model.NumofTeamMembers)
                    {
                        com_newProj.ExecuteNonQuery();      //ProjectInitiated
                        SqlCommand com_projid = new SqlCommand("select @@identity", con);
                       // com_projid.Transaction = trans;
                        model.ProjectID = Convert.ToInt32(com_projid.ExecuteScalar());

                        EmployeeDAL dal = new EmployeeDAL();

                        List<EmployeeModel> emplist_requested = dal.SearchProfile(model.Project_Domain, 2);   //Project Requested 

                        for (int i = 0; i < emplist_requested.Count; i++)
                        {
                            if (emplist_requested[i].EmployeeDesignation == "TeamLeader" && lead < model.NumofTeamLeaders)
                            {
                                lead++;
                                resources.Add(emplist_requested[i]);
                            }
                            else if (emplist_requested[i].EmployeeDesignation == "TeamMember" && member < model.NumofTeamMembers)
                            {
                                member++;
                                resources.Add(emplist_requested[i]);
                            }
                        }
                        List<EmployeeModel> emplist_skillset = dal.SearchProfile(model.Project_Domain, 1);   //Project from skill set
                        if (lead < model.NumofTeamLeaders)
                        {
                            for (int i = 0; i < emplist_skillset.Count; i++)
                            {
                                if (emplist_skillset[i].EmployeeDesignation == "TeamLeader" && lead < model.NumofTeamLeaders)  //check duplicacy
                                {
                                    EmployeeModel emp = emplist_skillset[i];

                                    if (!emplist_requested.Contains(emp))
                                    {
                                        lead++;
                                        resources.Add(emplist_skillset[i]);
                                    }
                                }
                            }
                        }
                        if (member < model.NumofTeamMembers)
                        {
                            for (int i = 0; i < emplist_skillset.Count; i++)
                            {
                                if (emplist_skillset[i].EmployeeDesignation == "TeamMember" && member < model.NumofTeamMembers)  //check duplicacy
                                {
                                    EmployeeModel emp = emplist_skillset[i];
                                    if (!emplist_requested.Contains(emp))
                                    {
                                        member++;
                                        resources.Add(emplist_skillset[i]);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                      //  trans.Commit();
                        return "Team Members Not Available";
                    }
                }
                else
                {
                    //trans.Commit();
                    return "Team Leads Not Available";
                }



                ProjectInfoDAL projdal = new ProjectInfoDAL();
                projdal.AllocateToProject(resources, model.ProjectID);  //Project Resources Allocated
               // trans.Commit();
                return "Project Initiated";
            }
            finally
            {
                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }
        //SqlDataAdapter adp = new SqlDataAdapter();
//adp.SelectCommand.CommandTimeout = 0;  // Set the Time out on the Command Object
        public void AllocateToProject(List<EmployeeModel> resources, int ProjectID)
        {
            //con.Open();
           // SqlTransaction trans = con.BeginTransaction();
            try
            {
                
                for (int i = 0; i < resources.Count; i++)
                {
                    EmployeeModel emp = resources[i];                   //Insert for project manager also
                    SqlCommand com_allocate_to_project = new SqlCommand("insert EmployeeAllocated values(@empid,@projid)", con);
                    com_allocate_to_project.Parameters.AddWithValue("@empid", emp.EmployeeID);
                    com_allocate_to_project.Parameters.AddWithValue("@projid", ProjectID);
                  //  com_allocate_to_project.Transaction = trans;
                    com_allocate_to_project.ExecuteNonQuery();

                }
                ProjectInfoDAL dal = new ProjectInfoDAL();
                ProjectInfo project = dal.GetProject(ProjectID);
                List<EmployeeModel> TeamLeads = new List<EmployeeModel>();
                List<EmployeeModel> TeamMembers = new List<EmployeeModel>();
                for (int i = 0; i < resources.Count; i++)
                {
                    if (resources[i].EmployeeDesignation == "TeamLeader")        //Updating ManagerID of TeamLeads and Team Members
                    {
                        SqlCommand com_update_managerid = new SqlCommand("update Employee set ManagerID=@managerid where EmployeeID=@empid", con);
                        com_update_managerid.Parameters.AddWithValue("@empid", resources[i].EmployeeID);
                        com_update_managerid.Parameters.AddWithValue("@managerid", project.ProjectManagerID);
                      ////  com_update_managerid.Transaction = trans;
                        TeamLeads.Add(resources[i]);
                    }
                    else
                    {
                        TeamMembers.Add(resources[i]);
                    }
                }

                int a, b, c;

                for (a = 0, c = 0; a < TeamLeads.Count; a++)
                {
                    if (c < TeamMembers.Count)
                    {
                        for (b = 0; b < TeamMembers.Count / TeamLeads.Count; b++)
                        {

                            SqlCommand com_update_managerid = new SqlCommand("update Employee set ManagerID=@managerid where EmployeeID=@empid", con);
                            com_update_managerid.Parameters.AddWithValue("@empid", TeamMembers[c].EmployeeID);
                            com_update_managerid.Parameters.AddWithValue("@managerid", TeamLeads[a].EmployeeID);
                          //  com_update_managerid.Transaction = trans;
                            c++;
                        }

                    }

                }
                //trans.Commit();
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<Projectlist> GetProjectDomain()
        {
            try
            {
                con.Open();
             //   SqlTransaction trans = con.BeginTransaction();
                List<Projectlist> projlist = new List<Projectlist>();
                SqlCommand com_getlist = new SqlCommand("select * from Projectlist", con);
              //  com_getlist.Transaction = trans;
                
                SqlDataReader dr = com_getlist.ExecuteReader();
                while (dr.Read())
                {
                    Projectlist obj = new Projectlist();
                    obj.DomainID = dr.GetInt32(0);
                    obj.projdomain = dr.GetString(1);
                    projlist.Add(obj);
                }
                dr.Close();
              //  trans.Commit();
                return projlist;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public ProjectInfo GetProject(int ProjectID)
        {
            try
            {
                con.Open();
               // SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_getproj = new SqlCommand("select *,dbo.getdomainname(Project_Domain) from ProjectInfo where ProjectID=@pid", con);
                com_getproj.Parameters.AddWithValue("@pid", ProjectID);
              //  com_getproj.Transaction = trans;
                
                SqlDataReader dr = com_getproj.ExecuteReader();
                ProjectInfo project = null;
                if (dr.Read())
                {
                    project = new ProjectInfo();
                    project.ProjectID = dr.GetInt32(0);
                    project.ProjectName = dr.GetString(1);

                    project.Objective = dr.GetString(3);
                    project.ProjectManagerID = dr.GetInt32(4);
                    project.NumofTeamLeaders = dr.GetInt32(5);
                    project.NumofTeamMembers = dr.GetInt32(6);
                    project.ProjectEndDate = dr.GetDateTime(7);
                    project.ProjectStartDate = dr.GetDateTime(8);
                    project.ProjectType = dr.GetString(9);
                    project.Client = dr.GetString(10);
                    project.ClientType = dr.GetString(11);
                    project.Project_Domain = dr.GetString(12);

                }
                dr.Close();
              //  trans.Commit();
                return project;
            }
            finally
            {
                if (System.Data.ConnectionState.Open == con.State)
                {
                    con.Close();
                }
            }
        }

        public int GetProjectID(int empid)
        {
            try
            {
                con.Open();
              //  SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_getprojid = new SqlCommand("select ProjectID from EmployeeAllocated where EmployeeID=@empid", con);
                com_getprojid.Parameters.AddWithValue("@empid", empid);
              //  com_getprojid.Transaction = trans;
                
                int projectid = Convert.ToInt32(com_getprojid.ExecuteScalar());
             //   trans.Commit();
                return projectid;
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
