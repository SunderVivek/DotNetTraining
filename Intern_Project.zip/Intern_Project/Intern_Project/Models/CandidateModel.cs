﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Intern_Project.Models
{
    public class CandidateModel
    {
        public int CandidateID { get; set; }
        
        [Display(Name="Candidate First Name")]
        public String FirstName { get; set; }
        
        [Display(Name="Candidate Last Name")]
        public String LastName { get; set; }
        
        [Display(Name="Tenth Percentage")]
        public float TenthPercentage { get; set; }

        [Display(Name = "Twelfth Percentage")]
        public float TwelfthPercentage { get; set; }

        [Display(Name = "Degree Percentage")]
        public float DegreePercentage { get; set; }

        [Display(Name="Candidate Image")]
        public string CandidateImage { get; set; }

        [Display(Name = "Experience")]
        public int Experience { get; set; }

        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Display(Name = "Domain_Applied")]
        public int Domain_Applied { get; set; }
    }
}

