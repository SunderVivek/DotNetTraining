﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;

namespace Mvc_FinalProject.Models
{
    public class employee
    {
         [Required(ErrorMessage = "Enter EmpID")]
        public int EmployeeID { get; set; }
         [Required(ErrorMessage = "Enter EmpName")]
       public string EmployeeName { get; set; }
        [Required(ErrorMessage = "Enter Email")]
        [EmailAddress]
        public string EmpEmail { get; set; }
        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string EmployeePassword { get; set; }


        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityQuestion { get; set; }

        [Required(ErrorMessage = "Enter Security Ans")]
        public string SecurityAnswer { get; set; }

    }
}