﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;


namespace Mvc_FinalProject.Models
{
    public class OrderDAL
    {
         SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
         public bool PlaceOrder(OrderModel o)
        {
            con.Open();
           
        
            SqlCommand com_insert_cust = new SqlCommand("insert orderdetailsofcustomers values(@custid,@itemid,@quantity,@totalcost,@restid,@addr,@paytype,null,getdate()) ", con);
            com_insert_cust.Parameters.AddWithValue("@custid", o.CustomerMobileNumber);
            com_insert_cust.Parameters.AddWithValue("@itemid", o.ItemID);
            com_insert_cust.Parameters.AddWithValue("@quantity", o.ItemQuantity);
            com_insert_cust.Parameters.AddWithValue("@totalcost", o.TotalCost);
            com_insert_cust.Parameters.AddWithValue("@restid", o.RestaurantID);
            com_insert_cust.Parameters.AddWithValue("@paytype", o.PaymentType);
            com_insert_cust.Parameters.AddWithValue("@addr", o.DeliveryAddress);
          
            
            com_insert_cust.ExecuteNonQuery();
            SqlCommand com_oid = new SqlCommand("select @@identity", con);
            int oid = Convert.ToInt32(com_oid.ExecuteScalar());
            o.ItemImage = "/ItemImages/" + o.ItemID + ".jpg";
            o.OrderID = oid;


            SqlCommand com_update_imaddress = new SqlCommand("update orderdetailsofcustomers set ItemImage=@im where Itemid=@itmid", con);
            com_update_imaddress.Parameters.AddWithValue("@itmid", o.ItemID);
            com_update_imaddress.Parameters.AddWithValue("@im", o.ItemImage);
            com_update_imaddress.ExecuteNonQuery();
            con.Close();
            return true;

        }

         public bool RemoveBasket(OrderModel o)
         {
            
             con.Open();
             
             SqlCommand con_delete_cart = new SqlCommand("delete Basket where ItemID in (select ItemID from orderdetailsofcustomers where Orderid=@oid)", con);
             con_delete_cart.Parameters.AddWithValue("@oid", o.OrderID);
             
             con_delete_cart.ExecuteNonQuery();
             con.Close();
             return true;

         }


         public List<OrderModel> GetOrders(string customermobilenumber)
        {
            con.Open();
            List<OrderModel> list_item = new List<OrderModel>();
            SqlCommand com_item = new SqlCommand("select * from orderdetailsofcustomers where CustomerMobileNumber=@custmob", con);
            com_item.Parameters.AddWithValue("@custmob", customermobilenumber);
            SqlDataReader dr = com_item.ExecuteReader();
            while (dr.Read())
            {
                OrderModel model = new OrderModel();
                model.OrderID = dr.GetInt32(0);
                model.CustomerMobileNumber = dr.GetString(1);
                model.ItemID = dr.GetInt32(2);
                model.ItemQuantity = dr.GetInt32(3);
                model.TotalCost = dr.GetInt32(4);
                model.RestaurantID = dr.GetInt32(5);
                model.DeliveryAddress = dr.GetString(6);
                model.PaymentType = dr.GetString(7);
                model.ItemImage = dr.GetString(8);
                model.orderdate = dr.GetDateTime(9);
                list_item.Add(model);

            }
            con.Close();
            return list_item;
        }

         public List<OrderModel> GetOrdersAdmin(string customermobilenumber)
         {
             con.Open();
             List<OrderModel> list_item = new List<OrderModel>();
             SqlCommand com_item = new SqlCommand("select * from orderdetailsofcustomers", con);
            
             SqlDataReader dr = com_item.ExecuteReader();
             while (dr.Read())
             {
                 OrderModel model = new OrderModel();
                 model.OrderID = dr.GetInt32(0);
                 model.CustomerMobileNumber = dr.GetString(1);
                 model.ItemID = dr.GetInt32(2);
                 model.ItemQuantity = dr.GetInt32(3);
                 model.TotalCost = dr.GetInt32(4);
                 model.RestaurantID = dr.GetInt32(5);
                 model.DeliveryAddress = dr.GetString(6);
                 model.PaymentType = dr.GetString(7);
                 model.ItemImage = dr.GetString(8);
                 model.orderdate = dr.GetDateTime(9);
                 list_item.Add(model);

             }
             con.Close();
             return list_item;
         }

          
    }
    }
