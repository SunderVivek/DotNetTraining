﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Mvc_FinalProject.Models
{
    public class RestaurantsModel

    {
         
         [Display(Name="ID")]
         [Required(ErrorMessage ="*")]
         public int RestaurantID { get; set; }
         
         [Display(Name = "Image")]
         [Required(ErrorMessage = "*")]
         public string RestaurantImage { get; set; }
        
         [Display(Name=" Restaurants ")]
         [Required(ErrorMessage = "*")]
         public string RestaurantName { get; set; }
         
         [Display(Name="  Restaurant Type  " )]
         [Required(ErrorMessage = "*")]
         public string RestaurantType { get; set; }
         
         [Display(Name="CityID")]
         [Required(ErrorMessage = "*")]
         public string CityID {get; set;}
         
         [Display(Name="Restaurant Location")]
         [Required(ErrorMessage = "*")]
         public string RestaurantLocation {get; set;}
        
         [Display(Name="Landmark")]
         [Required(ErrorMessage = "*")]
         public string Landmark{get; set;}
    }
}