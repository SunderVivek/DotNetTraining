﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;




namespace Mvc_FinalProject.Models
{
    public class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddEmployee(employee emp)
        {
            SqlCommand com_add_res = new SqlCommand("insert employees values (@empname,@empemail)", con);
            com_add_res.Parameters.AddWithValue("@empname", emp.EmployeeName);
            com_add_res.Parameters.AddWithValue("@empemail", emp.EmpEmail);

            con.Open();
            com_add_res.ExecuteNonQuery();
            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int Employeeid = Convert.ToInt32(com_empid.ExecuteScalar());
            emp.EmployeeID = Employeeid;
            con.Close();
            

            MembershipCreateStatus status;
            Membership.CreateUser(emp.EmployeeID.ToString(), emp.EmployeePassword, emp.EmpEmail,
                emp.SecurityQuestion, emp.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }

            
        }
    }
}