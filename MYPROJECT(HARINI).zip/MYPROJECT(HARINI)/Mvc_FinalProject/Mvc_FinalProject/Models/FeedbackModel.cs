﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Mvc_FinalProject.Models
{
    public class FeedbackModel
    {
        public int FeedBackID { get; set; }
        [Display(Name = "Customer Mobile Number")]
        [Required(ErrorMessage = "Enter Customer Name")]
        public string CustomerMobileNumber { get; set; }

        [Display(Name = "FeedBack")]
        [Required(ErrorMessage = "Enter yor Feedback")]
        public string CustomerFeedBack { get; set; }

        public DateTime FeedBackDate { get; set; }
    }
    
}