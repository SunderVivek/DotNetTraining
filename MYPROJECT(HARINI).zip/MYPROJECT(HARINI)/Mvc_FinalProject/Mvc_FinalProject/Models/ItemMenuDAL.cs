﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


namespace Mvc_FinalProject.Models
{
    public class ItemMenuDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
       
        public bool AddMenu(ItemMenuModel model)
        {
            SqlCommand com_additem = new SqlCommand("insert ItemMenu values(@resid,@name,@price,@combo,@type,@category,@subcategory,null)", con);
            com_additem.Parameters.AddWithValue("@resid", model.RestaurantID);
            com_additem.Parameters.AddWithValue("@name", model.ItemName);
            com_additem.Parameters.AddWithValue("@price", model.ItemPrice);
            com_additem.Parameters.AddWithValue("@combo", model.ItemCombo);
            com_additem.Parameters.AddWithValue("@type", model.ItemType);
            com_additem.Parameters.AddWithValue("@category", model.ItemCategory);
            com_additem.Parameters.AddWithValue("@subcategory", model.ItemSubcategory);
            con.Open();
            com_additem.ExecuteNonQuery();
            SqlCommand com_item_id = new SqlCommand("Select @@identity", con);
            int itemid = Convert.ToInt32(com_item_id.ExecuteScalar());
            model.ItemImage = "/ItemImages/" + itemid + ".jpg";
            model.ItemID = itemid;

            SqlCommand com_update_imgaddress = new SqlCommand("update ItemMenu set ItemImage=@itemimg where itemid=@itemid", con);

            com_update_imgaddress.Parameters.AddWithValue("@itemid", model.ItemID);
            com_update_imgaddress.Parameters.AddWithValue("@itemimg", model.ItemImage);
            com_update_imgaddress.ExecuteNonQuery();
            con.Close();

            return true;
        }



        public List<ItemMenuModel> ItemMenu(int id)
        {
            
            List<ItemMenuModel> ItemList = new List<ItemMenuModel>();
            SqlCommand com_viewitems = new SqlCommand("select * from ItemMenu where RestaurantID=@resid", con);
            com_viewitems.Parameters.AddWithValue("@resid", id);
            con.Open();
            SqlDataReader dr = com_viewitems.ExecuteReader();

            while (dr.Read())
            {ItemMenuModel item = new ItemMenuModel();
                item.RestaurantID = dr.GetInt32(0);    
                item.ItemID = dr.GetInt32(1);
                item.ItemName = dr.GetString(2);
                item.ItemPrice = dr.GetInt32(3);
                item.ItemCombo = dr.GetString(4);
                item.ItemType = dr.GetString(5);
                item.ItemCategory = dr.GetString(6);
                item.ItemSubcategory = dr.GetString(7);
                item.ItemImage = dr.GetString(8);
                ItemList.Add(item);
            }
            con.Close();
            return ItemList;
        }
        
         public List<RestaurantsModel> GetRes()
        {
            List<RestaurantsModel> list_restaurent= new List<RestaurantsModel>();
            SqlCommand com_res = new SqlCommand("select restaurantid,restaurantname from Restaurants", con);
            con.Open();
            SqlDataReader dr = com_res.ExecuteReader();
            while (dr.Read())
            {
                RestaurantsModel r = new RestaurantsModel();
                r.RestaurantID = dr.GetInt32(0);
                r.RestaurantName = dr.GetString(1);
                list_restaurent.Add(r);

            }
            con.Close();
            return list_restaurent;
        }
    
    
    }

}