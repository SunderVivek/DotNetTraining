﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_FinalProject.Models
{
    public class CityModel
    {
        public int CityID { get; set; }
        public string CityName { get; set; }
    }
}