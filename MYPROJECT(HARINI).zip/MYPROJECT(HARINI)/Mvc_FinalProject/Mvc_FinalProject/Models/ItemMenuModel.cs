﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Mvc_FinalProject.Models
{
    public class ItemMenuModel
    {   [Required(ErrorMessage="Select Restaurant")]
        [Display(Name = "Restaurant ID ")]
        public int  RestaurantID {get;set;}
         [Required(ErrorMessage = "Enter ItemID")]
        [Display(Name = " ItemID ")]
        public int  ItemID {get;set;}
         [Required(ErrorMessage = " Enter MEnu")]
        [Display(Name = " Menu ")]
        public string ItemName {get;set;}
         [Required(ErrorMessage = "Enter Price")]
        [Display(Name = "Price")]
        public int ItemPrice {get;set;}
         [Required(ErrorMessage = "Enter Combo")]
        [Display(Name = " Combo ")]
        public string ItemCombo {get;set;}
         [Required(ErrorMessage = " Enter ItemType")]
        [Display(Name = " Item type ")]
        public string ItemType {get;set;}
         [Required(ErrorMessage = "Select Category")]
        [Display(Name = " Menu Category ")]
        public string ItemCategory {get;set;}
         [Required(ErrorMessage = "Veg/NON-Veg")]
        [Display(Name = " Veg/NON-VEG ")]
        public string ItemSubcategory {get;set;}
         [Required(ErrorMessage = "*")]
        [Display(Name = " ")]
        public string ItemImage { get; set; }


    }
}