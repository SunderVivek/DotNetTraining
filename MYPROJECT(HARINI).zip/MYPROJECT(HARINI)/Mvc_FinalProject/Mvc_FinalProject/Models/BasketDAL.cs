﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;


namespace Mvc_FinalProject.Models
{
    public class BasketDAL
    {
         SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
 
        public bool AddBasket(BasketModel b)
        { 

            SqlCommand com_check = new SqlCommand("select count(*) from basket where itemid=@iteid and customermobilenumber=@custno", con);

            com_check.Parameters.AddWithValue("@iteid", b.ItemID);
            com_check.Parameters.AddWithValue("@custno", b.CustomerMobileNumber);
            con.Open();
            int count = Convert.ToInt32(com_check.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return false;
            } 

  
            else{
            con.Open();
            SqlCommand com_insert = new SqlCommand("select itemprice from itemmenu where itemid=@iteid", con);
            com_insert.Parameters.AddWithValue("@iteid", b.ItemID);
            int itemprice = Convert.ToInt32(com_insert.ExecuteScalar());
            SqlCommand com_insert_bskt = new SqlCommand("insert basket values(@custmob,@itemid,@restid,@itemprice,@itemqty,@total,null) ", con);
            com_insert_bskt.Parameters.AddWithValue("@custmob", b.CustomerMobileNumber);
            com_insert_bskt.Parameters.AddWithValue("@itemid", b.ItemID);
            com_insert_bskt.Parameters.AddWithValue("@restid", b.RestaurantID);
            com_insert_bskt.Parameters.AddWithValue("@itemprice", b.ItemPrice);
            com_insert_bskt.Parameters.AddWithValue("@itemqty", b.Quantity);
           
            b.TotalCost = itemprice * b.Quantity;
            com_insert_bskt.Parameters.AddWithValue("@total", b.TotalCost);
          
            
            com_insert_bskt.ExecuteNonQuery();
            
            
            SqlCommand com_b_id = new SqlCommand("Select @@identity", con);
            int Basketid= Convert.ToInt32(com_b_id.ExecuteScalar());
            b.ItemImage = "/ItemImages/" + b.ItemID + ".jpg";
            b.BasketID = Basketid;
         

            SqlCommand com_update_imgaddress = new SqlCommand("update basket set ItemImage=@img where Itemid=@iid", con);

            com_update_imgaddress.Parameters.AddWithValue("@iid", b.ItemID);
            com_update_imgaddress.Parameters.AddWithValue("@img", b.ItemImage);
            com_update_imgaddress.ExecuteNonQuery();
            con.Close();

            return true;

        }
        }

        public List<BasketModel> ShowBasket(string CustomerMobileNumber)
        {
            con.Open();
            List<BasketModel> list_bst = new List<BasketModel>();
            SqlCommand com_basket = new SqlCommand("select * from basket where customermobilenumber=@custmob", con);
            com_basket.Parameters.AddWithValue("@custmob", CustomerMobileNumber);
            SqlDataReader dr = com_basket.ExecuteReader();
            while (dr.Read())
            {
                BasketModel model = new BasketModel();
                model.CustomerMobileNumber = dr.GetString(0);
                model.RestaurantID = dr.GetInt32(2);
                model.ItemID = dr.GetInt32(1);
                model.ItemPrice = dr.GetInt32(3);
                model.Quantity = dr.GetInt32(4);
                model.TotalCost= dr.GetInt32(5);
                model.ItemImage = dr.GetString(6);
                model.BasketID = dr.GetInt32(7);

                list_bst.Add(model);

            }
            con.Close();
            return list_bst;    
        
        }





        public bool Delete(int BasketID)
        {
            con.Open();
            SqlCommand com_basket_rem = new SqlCommand("delete from basket where BasketID=@bid ", con);


            com_basket_rem.Parameters.AddWithValue("@bid", BasketID);
           
            com_basket_rem.ExecuteNonQuery();
            con.Close();
            return true;
        }
    }
    }
