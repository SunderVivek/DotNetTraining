﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


namespace Mvc_FinalProject.Models
{
    public class SelectrestaurantDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public RestaurantsModel SelectRestaurant(int Restaurantid)
        {
            SqlCommand com_SelectRestaurant = new SqlCommand("select * from Restaurants where RestaurantID=@Rid", con);
            com_SelectRestaurant.Parameters.AddWithValue("Rid", Restaurantid);
            RestaurantsModel model = new RestaurantsModel();
            con.Open();
            SqlDataReader dr = com_SelectRestaurant.ExecuteReader();
            if (dr.Read())
            {
                model.RestaurantID = dr.GetInt32(0);

                model.RestaurantName = dr.GetString(1);
            }
            return model;

        }
    }
}