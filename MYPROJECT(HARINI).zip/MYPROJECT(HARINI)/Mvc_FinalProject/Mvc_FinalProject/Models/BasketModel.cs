﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc_FinalProject.Models
{
    public class BasketModel
    {

        public string CustomerMobileNumber { get; set; }
        public int ItemID { get; set; }
        public int RestaurantID { get; set; }
       
        public int Quantity { get; set; }
        public int ItemPrice { get; set; }
        public int TotalCost { get; set; }
        public string ItemImage { get; set; }
        public int BasketID { get; set; }

    }
}