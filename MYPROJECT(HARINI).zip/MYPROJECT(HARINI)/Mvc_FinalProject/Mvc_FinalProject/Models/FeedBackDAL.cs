﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


namespace Mvc_FinalProject.Models
{
    public class FeedBackDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddFeedback(FeedbackModel model)
        {
            SqlCommand com_addfeedback = new SqlCommand("insert Feedback values(@cusnumber,@cusfeed,getdate())", con);
            com_addfeedback.Parameters.AddWithValue("@cusnumber", model.CustomerMobileNumber);

            com_addfeedback.Parameters.AddWithValue("@cusfeed", model.CustomerFeedBack);
            con.Open();
            com_addfeedback.ExecuteNonQuery();
            SqlCommand com_feedbackid = new SqlCommand("Select @@identity", con);
            int feedbackid = Convert.ToInt32(com_feedbackid.ExecuteScalar());
            model.FeedBackID = feedbackid;
            con.Close();
            return true;
        }
        public List<FeedbackModel> GetFeedback()
        {

            List<FeedbackModel> list_fb = new List<FeedbackModel>();
            SqlCommand com_get_feedback = new SqlCommand("select * from Feedback ", con);

            con.Open();
            SqlDataReader dr = com_get_feedback.ExecuteReader();
            while (dr.Read())
            {
                FeedbackModel feed = new FeedbackModel();
                feed.FeedBackID = dr.GetInt32(0);
                feed.CustomerMobileNumber = dr.GetString(1);
                feed.CustomerFeedBack = dr.GetString(2);
                feed.FeedBackDate = dr.GetDateTime(3);
                list_fb.Add(feed);

            }
            con.Close();
            return list_fb;
        } 
    }
}