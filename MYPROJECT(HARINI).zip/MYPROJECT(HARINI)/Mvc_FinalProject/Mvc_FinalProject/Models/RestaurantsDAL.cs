﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace Mvc_FinalProject.Models
{
    public class RestaurantsDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddRestaurant(RestaurantsModel model)
        {
            SqlCommand com_addres = new SqlCommand("insert Restaurants values(null,@name,@type,@cityid,@location,@landmark)", con);
            com_addres.Parameters.AddWithValue("@name", model.RestaurantName);
            com_addres.Parameters.AddWithValue("@type", model.RestaurantType);
            com_addres.Parameters.AddWithValue("@cityid", model.CityID);
            com_addres.Parameters.AddWithValue("@location", model.RestaurantLocation);
            com_addres.Parameters.AddWithValue("@landmark", model.Landmark);
            con.Open();
            com_addres.ExecuteNonQuery();
            SqlCommand com_res_id = new SqlCommand("Select @@identity", con);
            int restaurantid = Convert.ToInt32(com_res_id.ExecuteScalar());
            model.RestaurantImage = "/Images/" + restaurantid + ".jpg";
            model.RestaurantID = restaurantid;

            SqlCommand com_update_imgaddress = new SqlCommand("update Restaurants set RestaurantImage=@img where restaurantid=@rid", con);

            com_update_imgaddress.Parameters.AddWithValue("@rid", model.RestaurantID);
            com_update_imgaddress.Parameters.AddWithValue("@img", model.RestaurantImage);
            com_update_imgaddress.ExecuteNonQuery();
            con.Close();

            return true;


    }

        public List<RestaurantsModel> SearchViewRestaurants()
        {
            List<RestaurantsModel> RestaurantList = new List<RestaurantsModel>();
            SqlCommand com_viewrestaurants = new SqlCommand("select r.restaurantid,r.restaurantimg,r.restaurantname,r.restauranttype,c.cityname,r.restaurantlocation,r.landmark from restaurants r join cities c on r.cityid=c.cityid where r.cityid=@cid ", con);

            con.Open();
            SqlDataReader dr = com_viewrestaurants.ExecuteReader();

            while (dr.Read())
            {
                RestaurantsModel res = new RestaurantsModel();
                res.RestaurantID = dr.GetInt32(0);
                res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
                res.CityID = dr.GetString(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);
               
                RestaurantList.Add(res);
            }
            con.Close();
            return RestaurantList;
        }

        public List<RestaurantsModel> GetRestaurantsByCity(int cityid)
        {
            con.Open();
           //search city
            List<RestaurantsModel> list_cust = new List<RestaurantsModel>();
            SqlCommand com_view = new SqlCommand("select r.restaurantid,r.restaurantimage,r.restaurantname,r.restauranttype,c.cityname,r.restaurantlocation,r.landmark from restaurants r join cities c on r.cityid=c.cityid where r.cityid=@cid ", con);
            com_view.Parameters.AddWithValue("@cid", cityid);
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read())
            {
                RestaurantsModel res = new RestaurantsModel();
               
                 res.RestaurantID = dr.GetInt32(0);
                res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
                res.CityID = dr.GetString(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);
                list_cust.Add(res);

            }
            con.Close();
            return list_cust;
        }

        public List<RestaurantsModel> ViewRestaurants()
        {
            con.Open();
            
            List<RestaurantsModel> list_cus = new List<RestaurantsModel>();
            SqlCommand com_view = new SqlCommand("select * from Restaurants ", con);
            
            SqlDataReader dr = com_view.ExecuteReader();
            while (dr.Read())
            {
                RestaurantsModel res = new RestaurantsModel();

                res.RestaurantID = dr.GetInt32(0);
                res.RestaurantImage = dr.GetString(1);

                res.RestaurantName = dr.GetString(2);
                res.RestaurantType = dr.GetString(3);
              //  res.CityID = dr.GetString(4);
                res.RestaurantLocation = dr.GetString(5);
                res.Landmark = dr.GetString(6);
                list_cus.Add(res);

            }
            con.Close();
            return list_cus;
        }
    }
}