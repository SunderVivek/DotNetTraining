﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;


namespace Mvc_FinalProject.Models
{
    public class OrderModel
    {
        //orderdetailsodcust
        public int OrderID { get; set; }
        public string CustomerMobileNumber { get; set; }
        public int ItemID { get; set; }
        public int ItemQuantity { get; set; }
        public int TotalCost { get; set; }
        public int RestaurantID { get; set; }
      
        public string DeliveryAddress { get; set; }
        [Display(Name = "Payment Type")]
        [Required(ErrorMessage = "Payment Type")]
        public string PaymentType { get; set; }
        public string ItemImage { get; set; }
        public DateTime orderdate { get; set; }
      
    }
}