﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;

namespace Mvc_FinalProject.Models
{
    public class CustomerDetailsModel
    {
         
        [Required(ErrorMessage="Enter Your Mobile Number")]
        public string CustomerMobileNumber { get; set; }
        
        [Required(ErrorMessage="Enter Your Name")]
        public string CustomerName { get; set; }

        [Required(ErrorMessage = "Enter Password")]
        [DataType(DataType.Password)]
        public string CustomerPassword { get; set; }

        [Required(ErrorMessage= "Enter Your City")]
        public string CustomerCity { get; set; }
        
        [Required(ErrorMessage= "Enter Your City")]
        public string CustomerEmail { get; set; }
        
        [Required(ErrorMessage="Enter your Address")]
        public string CustomerAddress { get; set; }
        
        [Required(ErrorMessage = "Enter Security Question")]
        public string SecurityQuestion { get; set; }

        [Required(ErrorMessage = "Enter Security Ans")]
        public string SecurityAnswer { get; set; }


    }
}