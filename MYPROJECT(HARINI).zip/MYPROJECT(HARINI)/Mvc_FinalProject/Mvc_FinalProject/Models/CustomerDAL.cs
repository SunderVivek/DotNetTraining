﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Configuration;
using System.Data.SqlClient;

namespace Mvc_FinalProject.Models
{
    public class CustomerDAL
    {
        public List<CityModel> GetCities()
        {
            List<CityModel> list_cities = new List<CityModel>();
            SqlCommand com_city = new SqlCommand("select * from Cities", con);
            con.Open();
            SqlDataReader dr = com_city.ExecuteReader();
            while (dr.Read())
            {
                CityModel c = new CityModel();
                c.CityID = dr.GetInt32(0);
                c.CityName = dr.GetString(1);
                list_cities.Add(c);

            }
            con.Close();
            return list_cities;
        }
        
            //DAL 
             SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool AddCustomers(CustomerDetailsModel cus)
        {
            SqlCommand com_addcustomer = new SqlCommand("insert CustomerDetails values (@CustomerMobileNumber,@CustomerName,@CustomerCity,@CustomerEmail,@CustomerAddress)", con);
            com_addcustomer.Parameters.AddWithValue("@CustomerMobileNumber", cus.CustomerMobileNumber);
            com_addcustomer.Parameters.AddWithValue("@CustomerName", cus.CustomerName);
            com_addcustomer.Parameters.AddWithValue("@CustomerCity", cus.CustomerCity);
            
            com_addcustomer.Parameters.AddWithValue("@CustomerEmail", cus.CustomerEmail);
            com_addcustomer.Parameters.AddWithValue("@CustomerAddress", cus.CustomerAddress);
            con.Open();
            com_addcustomer.ExecuteNonQuery();
        
           

            MembershipCreateStatus status;
            Membership.CreateUser(cus.CustomerMobileNumber, cus.CustomerPassword, cus.CustomerEmail,
                cus.SecurityQuestion, cus.SecurityAnswer, true, out status);
            if (status == MembershipCreateStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
            con.Close();

        }
    }
}