﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Mvc_FinalProject.Models;


namespace Mvc_FinalProject.Controllers
{
    public class HomeAdminController : Controller
    {

        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Home");
        }
        [Authorize]
        public ActionResult IndexAdmin()
        {
            return View();
        }
        [AllowAnonymous]
        public ActionResult LoginAdmin()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult LoginAdmin(string EmployeeID, string EmployeePassword, bool RememberMe)
        {
            if (Membership.ValidateUser(EmployeeID, EmployeePassword))
            {
                FormsAuthentication.SetAuthCookie(EmployeeID, RememberMe);
                return RedirectToAction("IndexAdmin", "HomeAdmin");
            }
            else
            {
                ViewBag.msg = "invalid empid or password";
                return View();
            }

        }
        [Authorize]
        public ActionResult NewEmployee()
        {
            return View();
        }

        [Authorize]
        [HttpPost]
        public ActionResult NewEmployee(employee emp)
        {


            EmployeeDAL dal = new EmployeeDAL();
            bool flag = dal.AddEmployee(emp);
            if (flag == true)
            {
                ViewBag.msg = "Employee Added";
                return View();
            }
            else
            {
                ViewBag.msg = "Employee not created";
                return View();

            }
        }
        [Authorize]
        public ActionResult AddRestaurant()
        {

            RestaurantsDAL dal = new RestaurantsDAL();
            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            return View();

        }
        [Authorize]
        [HttpPost]
        public ActionResult AddRestaurant(RestaurantsModel res, HttpPostedFileBase img)
        {


            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            RestaurantsDAL dal = new RestaurantsDAL();
            dal.AddRestaurant(res);
            img.SaveAs(Server.MapPath(res.RestaurantImage));

            @ViewBag.msg = "Restaurant Added Successfully";
            ModelState.Clear();
            return View();

        }
        [Authorize]
        public ActionResult AddItemMenu()
        {

            RestaurantsDAL dal = new RestaurantsDAL();
            ItemMenuDAL rdal = new ItemMenuDAL();

            List<SelectListItem> list_item = new List<SelectListItem>();
            List<RestaurantsModel> item = rdal.GetRes();
            foreach (RestaurantsModel model in item)
            {
                list_item.Add(new SelectListItem { Text = model.RestaurantName, Value = model.RestaurantID.ToString() });
            }
            ViewBag.cities = list_item;

            return View();

        }
        [Authorize]
        [HttpPost]
        public ActionResult AddItemMenu(ItemMenuModel add, HttpPostedFileBase image)
        {
            ItemMenuDAL rdal = new ItemMenuDAL();

            List<SelectListItem> list_item = new List<SelectListItem>();
            List<RestaurantsModel> item = rdal.GetRes();
            foreach (RestaurantsModel model in item)
            {
                list_item.Add(new SelectListItem { Text = model.RestaurantName, Value = model.RestaurantID.ToString() });
            }

            ViewBag.cities = list_item;

            ItemMenuDAL iDAL = new ItemMenuDAL();
            iDAL.AddMenu(add);
            image.SaveAs(Server.MapPath(add.ItemImage));

            @ViewBag.msg = "Item Added Successfully";
            ModelState.Clear();
            return View();
        }
        [Authorize]
        public ActionResult ViewRestaurants()
        {

            RestaurantsDAL vres = new RestaurantsDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);


            List<RestaurantsModel> itemlist = vres.ViewRestaurants();
            return View(itemlist);
        }
        [Authorize]
        public ActionResult ListAllOrders()
        {

            OrderDAL myord = new OrderDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);


            List<OrderModel> itemlist = myord.GetOrdersAdmin(CustomerMobileNumber);
            return View(itemlist);


        }
        public ActionResult FeedBack()
        {

            FeedBackDAL feeddal = new FeedBackDAL();

            List<FeedbackModel> itemfb = feeddal.GetFeedback();
            return View(itemfb);


        }
    }
}