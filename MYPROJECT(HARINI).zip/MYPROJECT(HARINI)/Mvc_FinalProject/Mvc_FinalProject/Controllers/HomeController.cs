﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Mvc_FinalProject.Models;


namespace Mvc_FinalProject.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
      
       
        [Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login","Home");
        }
         [Authorize]
        public ActionResult Index()
        {
            return View();
        }
         public ActionResult HomePage()
         {
             return View();
         }
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        public ActionResult Login(string CustomerMobileNumber,string CustomerPassword,bool RememberMe)
        {
            
            if(Membership.ValidateUser(CustomerMobileNumber,CustomerPassword))
                {
                    FormsAuthentication.SetAuthCookie(CustomerMobileNumber, RememberMe);
                    return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.msg = "invalid mobilenumber or password";
                return View();
            }
           
        }
        [AllowAnonymous]
        public ActionResult NewCustomer()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult NewCustomer(CustomerDetailsModel Custdet)
        {
        
        
            CustomerDAL dal = new CustomerDAL();
            bool flag = dal.AddCustomers(Custdet);
            if(flag==true)
            {
                ViewBag.msg = "Customer created";
                return View();
            }
            else
            {
                ViewBag.msg = "Customer not created";
                return View();

            }
        }
        [Authorize]
        public ActionResult SearchCity()
        {
            RestaurantsDAL dal = new RestaurantsDAL();
            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult SearchCity(RestaurantsModel res)
        {
            RestaurantsDAL dal = new RestaurantsDAL();
            CustomerDAL cdal = new CustomerDAL();
            List<SelectListItem> list_city = new List<SelectListItem>();
            List<CityModel> city = cdal.GetCities();
            foreach (CityModel item in city)
            {
                list_city.Add(new SelectListItem { Text = item.CityName, Value = item.CityID.ToString() });
            }
            ViewBag.cities = list_city;
            RestaurantsModel r = new RestaurantsModel();
            int cityid = Convert.ToInt32(res.CityID);
            List<RestaurantsModel> list = dal.GetRestaurantsByCity(cityid);
            return View("ShowRestaurants", list);
        }
        [Authorize]
        public ActionResult ItemMenu(int id)
        {
            ItemMenuDAL iDAL = new ItemMenuDAL();
            List<ItemMenuModel> itemlist = iDAL.ItemMenu(id);
            return View("ItemMenu", itemlist);

        }

        [Authorize]
        public ActionResult AddBasket(int ItemID, int RestaurantID,int ItemPrice, string ItemImage)
        {

            BasketDAL dal = new BasketDAL();
           string CustomerMobileNumber = Convert.ToString(User.Identity.Name);
            TempData["ItemID"] = ItemID;
            TempData["RestauarantID"] = RestaurantID;
           
            TempData["ItemPrice"] = ItemPrice;
            
            // TempData["ItemImage"] = ItemImage;
            return View();
        }


        [Authorize]
        [HttpPost]
        public ActionResult AddBasket(BasketModel b)
        {

            BasketDAL adal = new BasketDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);
            b.CustomerMobileNumber = CustomerMobileNumber;
            b.CustomerMobileNumber = CustomerMobileNumber;

            if (adal.AddBasket(b))
            {
                ViewBag.Item = "ITEM ADDED TO CART...VIEW IN CART";
            }
            else
            {
                ViewBag.Item = "Item Already Added To Cart";
            }


            ModelState.Clear();
            return RedirectToAction("Result","Home");

        }
        [Authorize]

        public ActionResult Result()
        {
          


            return View();
        }


        [Authorize]
        public ActionResult MyCart()
        {

            BasketDAL Cartdal = new BasketDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);


            List<BasketModel> itemlist = Cartdal.ShowBasket(CustomerMobileNumber);
            return View("MyCart", itemlist);


        }
       

        [Authorize]
        public ActionResult Delete(int BasketID)
        {
            BasketDAL bdal = new BasketDAL();
            bool status = bdal.Delete(BasketID);
            ViewBag.msg1 = "Deleted successfully";
            return View("Delete");

        }

        [Authorize]
         public ActionResult PlaceOrder( int BasketID , string CustomerMobileNumber,int ItemID ,int ItemQuantity ,int TotalCost ,int RestaurantID ,string ItemImage)
        {
            OrderModel o = new OrderModel();

            CustomerMobileNumber = Convert.ToString(User.Identity.Name);
            TempData["ItemID"] = ItemID;
            TempData["Quantity"] = ItemQuantity;
            TempData["TotalCost"] = TotalCost;

            TempData["RestaurantID"] = RestaurantID;

            TempData["BasketID"] = BasketID;
           
            return View();
        }


        [HttpPost]
        public ActionResult PlaceOrder(OrderModel o, int ItemID)
        {

            BasketDAL dal = new BasketDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);
            o.CustomerMobileNumber = CustomerMobileNumber;



            OrderDAL odal = new OrderDAL();


            if (odal.PlaceOrder(o))
            {
                ViewBag.status = "PAYMENT SUCCESSFULL,Order Placed Successfully Your OrderID:" + " " + o.OrderID + " " + "Order Will Be Delivered By 45 Minutes.";
            }
            else
            {
                ViewBag.status = "Request Failed Try Again";
            }

            odal.RemoveBasket(o);
            ModelState.Clear();
            return RedirectToAction("Success", "Home");
        }



        [Authorize]
        public ActionResult MyOrders()
        {

            OrderDAL myord = new OrderDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);


            List<OrderModel> itemlist = myord.GetOrders(CustomerMobileNumber);
            return View(itemlist);


        }

        [Authorize]
       
        public ActionResult Success()
        {

          
            return View();
        }
      
        [Authorize]
        public ActionResult Feedback()
        
        {
            FeedBackDAL dal = new FeedBackDAL();
            

            return View();
        }
        [Authorize]
        [HttpPost]
        public ActionResult Feedback(FeedbackModel model)
        {
            FeedBackDAL dal = new FeedBackDAL();
            string CustomerMobileNumber = Convert.ToString(User.Identity.Name);
            model.CustomerMobileNumber = CustomerMobileNumber;
            dal.AddFeedback(model);
            ViewBag.feed = "FeedBack Sent!!";
            ModelState.Clear();
            return View();
        }

    }
}
