﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_addemployee_Click(object sender, EventArgs e)
    {
        Employee emp = new Employee();
        emp.employeename = txt_empname.Text;
        emp.empcity = txt_empcity.Text;
       
        EmployeeDAL dal = new EmployeeDAL();
        if (dal.AddEmployee(emp, txt_securityquestion.Text, txt_answer.Text, txt_empid.Text, txt_emppassword.Text))
        {
            txt_empid.Text = emp.empid.ToString();
            lbl_status.Text = "User Created";
        }
        else
        {
            lbl_status.Text = "User Not Created";
        }
    }
    protected void btn_login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_loginid.Text, txt_password.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_loginid.Text, chk_RememberMe.Checked);
            Response.Redirect("~/HomePage.aspx");
        }
        else
        {
            lbl_msg.Text = "Invalid userid or password";
        }
    }
}