﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Security;

/// <summary>
/// Summary description for EmployeeDAL
/// </summary>
public class EmployeeDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


    public bool AddEmployee(Employee emp,string securityquestion,string securityanswer,string email,string password)
    {
        SqlCommand com_insertemp = new SqlCommand("insert EmployeeLogin values(@empname,@empcity)", con);
        com_insertemp.Parameters.AddWithValue("@empname", emp.employeename);
        com_insertemp.Parameters.AddWithValue("@empcity", emp.empcity);
    
        con.Open();
        com_insertemp.ExecuteNonQuery();
        SqlCommand com_empid = new SqlCommand("Select @@identity",con);
        emp.empid = Convert.ToInt32(com_empid.ExecuteScalar());
        con.Close();
        MembershipCreateStatus status;
        Membership.CreateUser(emp.empid.ToString(), password, email, securityquestion, securityanswer, true,out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}