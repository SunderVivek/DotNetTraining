﻿namespace Win_exception
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_GetValue = new System.Windows.Forms.Button();
            this.txt_Value = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_GetValue
            // 
            this.btn_GetValue.Location = new System.Drawing.Point(45, 78);
            this.btn_GetValue.Name = "btn_GetValue";
            this.btn_GetValue.Size = new System.Drawing.Size(75, 23);
            this.btn_GetValue.TabIndex = 0;
            this.btn_GetValue.Text = "Get Value";
            this.btn_GetValue.UseVisualStyleBackColor = true;
            this.btn_GetValue.Click += new System.EventHandler(this.btn_GetValue_Click);
            // 
            // txt_Value
            // 
            this.txt_Value.Location = new System.Drawing.Point(207, 80);
            this.txt_Value.Name = "txt_Value";
            this.txt_Value.Size = new System.Drawing.Size(100, 20);
            this.txt_Value.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 403);
            this.Controls.Add(this.txt_Value);
            this.Controls.Add(this.btn_GetValue);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_GetValue;
        private System.Windows.Forms.TextBox txt_Value;
    }
}

