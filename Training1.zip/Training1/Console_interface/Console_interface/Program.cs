﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductA a = new ProductA();
            a.pid = "121";
            a.pname = "Mobile";
            a.CustomerName = "XYZ";
            a.address = "Delhi";

            ProductB b= new ProductB();
            b.prod_id = "1231";
            b.prod_name = "Laptop";
            b.Cust_Name = "PQR";
            b.Cust_addr = "Hyderabad";


            Testing test = new Testing();
            bool statusa = test.RecProductForTesting(a);
            bool statusb = test.RecProductForTesting(b);


            Transport t = new Transport();
            if (statusa == true)
                t.Rec_Product(a);
            else
                Console.WriteLine("Product is not okay");
            if(statusb==true )
                t.Rec_Product(b);
            else
                Console.WriteLine("Product is not okay");
            Console.ReadLine();

           
        }
    }
}
