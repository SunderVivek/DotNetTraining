﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class Testing
    {
        public bool RecProductForTesting(ITesting obj)
        {
            bool status1 = obj.Run();
            bool status2 = obj.Stop();
            if (status1 == true && status2 == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
