﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class Transport
    {
        public void Rec_Product(ITransport obj)
        {
            String address = obj.GetCustomerAddress();
                        
            Console.WriteLine(address);
        }
    }
}
