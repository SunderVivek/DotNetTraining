﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class ProductB :ITransport,ITesting
    {
        public string prod_id;
        public string prod_name;
        public string Cust_addr;
        public string Cust_Name;
        //public string spec_details;
        public void run()
        {
            Console.WriteLine("Executed");
        }
        public void stop()
        {
            Console.WriteLine("Stopped");
        }
        public string GetCustDetails()
        {
            return prod_name + " " + Cust_addr;
        }

        #region ITransport Members

        public string GetCustomerAddress()
        {
            return prod_name + " " + Cust_addr;
            throw new NotImplementedException();
        }

        #endregion

        #region ITesting Members

        public bool Run()
        {
            this.run();
            return true;
            throw new NotImplementedException();
        }

        public bool Stop()
        {
            this.stop();
            return true;
            throw new NotImplementedException();
        }

        #endregion
    }
}
