﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_interface
{
    class ProductA :ITransport,ITesting 
    {
        public string pid;
        public string pname;
        public string address;
        public string CustomerName;
        public void play()
        {
            Console.WriteLine("Prod running");
        }
        public void stop()
        {
            Console.WriteLine("Stopped");
        }
        public string GetAddress()
        {
            return pid + " " + pname + " " + address;
        }


        #region ITransport Members

        public string GetCustomerAddress()
        {
            return pid + " " + pname + " " + address;
            throw new NotImplementedException();
        }

        #endregion

        #region ITesting Members

        public bool Run()
        {
            this.play();
            return true;
        }

        public bool Stop()
        {
            this.stop();
            return true;   
        }

        #endregion
    }
}
