﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "hello";
            String str1 = "abc";
            str = str1;
            str1 = "xyz";
            
            Console.WriteLine(str);
            foreach (char ch in str)
            {
                Console.WriteLine(ch);
            }
            Console.ReadLine();
        }
    }
}
