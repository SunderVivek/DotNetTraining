﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment
{
    /// <summary>
    /// Interaction logic for Win_Home.xaml
    /// </summary>
    public partial class Win_Home : Window
    {
        public Win_Home()
        {
            InitializeComponent();
        }

        private void btn_calculator_Click(object sender, RoutedEventArgs e)
        {
            Win_Calculator obj = new Win_Calculator();
            obj.Show();
            this.Close();
        }

        private void btn_placeorder_Click(object sender, RoutedEventArgs e)
        {
            Win_Order obj = new Win_Order();
            obj.Show();
            this.Close();
        }
    }
}
