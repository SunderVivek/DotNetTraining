﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADIO2
{
    class Item
    {
        public int OrderID { get; set; }
        public int ItemID { get; set; }
        public DateTime OrderDate { get; set; }
        public int itemprice { get; set; }
        public int itemqty { get; set; }
    }
}
