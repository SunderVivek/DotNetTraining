﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADIO2
{
    class OrdersDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public void AddOrder(Order ord)
        {
            try
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();
                SqlCommand com_order = new SqlCommand("insert orders values(@custname,getDate())", con);
                com_order.Parameters.AddWithValue("@custname", ord.CustomerName);
                com_order.Transaction = trans;
                com_order.ExecuteNonQuery();
                SqlCommand com_orderid = new SqlCommand("Select @@identity", con);
                com_orderid.Transaction = trans;
                int orderid = Convert.ToInt32(com_orderid.ExecuteScalar());
                ord.OrderID = orderid;

                foreach (Item item in ord.items)
                {
                    SqlCommand com_item = new SqlCommand("insert orderdetails values(@oid,@itemid,@itemqty,@itemprice)", con);
                    com_item.Parameters.AddWithValue("@oid", orderid);
                    com_item.Parameters.AddWithValue("@itemid", item.ItemID);
                    com_item.Parameters.AddWithValue("@itemqty", item.itemqty);
                    com_item.Parameters.AddWithValue("@itemprice", item.itemprice);
                    com_item.Transaction = trans;
                    com_item.ExecuteNonQuery();
                }
                System.Windows.Forms.MessageBox.Show("Wait");
                trans.Commit();
            }
            finally
            {
                if (con.State == System.Data.ConnectionState.Open)
                {
                    con.Close();
                }
            }
            //ADIO.NET
        }
    }
}
