﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ADIO2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Order ord = new Order();
                ord.CustomerName = txt_CustName.Text;

                Item item = new Item();
                item.ItemID = Convert.ToInt32(txt_ItemID.Text);
                item.itemprice = Convert.ToInt32(txt_ItemPrice.Text);
                item.itemqty = Convert.ToInt32(txt_ItemQty.Text);
                ord.AddItem(item);

                OrdersDAL dal = new OrdersDAL();
                dal.AddOrder(ord);
                txt_OrderID.Text = ord.OrderID.ToString();
            }
            catch (Exception exp) { MessageBox.Show(exp.Message); }
        }

    }
}
