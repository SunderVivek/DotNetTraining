﻿namespace Win_ADIO2
{
    partial class Frm_Proc_from_frontend
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Login = new System.Windows.Forms.Button();
            this.txt_EmpID = new System.Windows.Forms.TextBox();
            this.txt_Emppwd = new System.Windows.Forms.TextBox();
            this.lbl_empid = new System.Windows.Forms.Label();
            this.lbl_pwd = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(140, 198);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(109, 53);
            this.btn_Login.TabIndex = 0;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // txt_EmpID
            // 
            this.txt_EmpID.Location = new System.Drawing.Point(244, 36);
            this.txt_EmpID.Name = "txt_EmpID";
            this.txt_EmpID.Size = new System.Drawing.Size(100, 20);
            this.txt_EmpID.TabIndex = 1;
            // 
            // txt_Emppwd
            // 
            this.txt_Emppwd.Location = new System.Drawing.Point(244, 89);
            this.txt_Emppwd.Name = "txt_Emppwd";
            this.txt_Emppwd.Size = new System.Drawing.Size(100, 20);
            this.txt_Emppwd.TabIndex = 2;
            // 
            // lbl_empid
            // 
            this.lbl_empid.AutoSize = true;
            this.lbl_empid.Location = new System.Drawing.Point(78, 42);
            this.lbl_empid.Name = "lbl_empid";
            this.lbl_empid.Size = new System.Drawing.Size(39, 13);
            this.lbl_empid.TabIndex = 3;
            this.lbl_empid.Text = "EmpID";
            // 
            // lbl_pwd
            // 
            this.lbl_pwd.AutoSize = true;
            this.lbl_pwd.Location = new System.Drawing.Point(72, 89);
            this.lbl_pwd.Name = "lbl_pwd";
            this.lbl_pwd.Size = new System.Drawing.Size(53, 13);
            this.lbl_pwd.TabIndex = 4;
            this.lbl_pwd.Text = "Password";
            // 
            // Frm_Proc_from_frontend
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 379);
            this.Controls.Add(this.lbl_pwd);
            this.Controls.Add(this.lbl_empid);
            this.Controls.Add(this.txt_Emppwd);
            this.Controls.Add(this.txt_EmpID);
            this.Controls.Add(this.btn_Login);
            this.Name = "Frm_Proc_from_frontend";
            this.Text = "Frm_Proc_from_frontend";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Login;
        private System.Windows.Forms.TextBox txt_EmpID;
        private System.Windows.Forms.TextBox txt_Emppwd;
        private System.Windows.Forms.Label lbl_empid;
        private System.Windows.Forms.Label lbl_pwd;
    }
}