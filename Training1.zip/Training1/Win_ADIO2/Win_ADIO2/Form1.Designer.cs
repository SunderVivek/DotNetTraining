﻿namespace Win_ADIO2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_orderid = new System.Windows.Forms.Label();
            this.lbl_CustName = new System.Windows.Forms.Label();
            this.txt_OrderID = new System.Windows.Forms.TextBox();
            this.txt_CustName = new System.Windows.Forms.TextBox();
            this.lbl_itemid = new System.Windows.Forms.Label();
            this.lbl_qty = new System.Windows.Forms.Label();
            this.lbl_price = new System.Windows.Forms.Label();
            this.btn_placaorder = new System.Windows.Forms.Button();
            this.txt_ItemID = new System.Windows.Forms.TextBox();
            this.txt_ItemQty = new System.Windows.Forms.TextBox();
            this.txt_ItemPrice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_orderid
            // 
            this.lbl_orderid.AutoSize = true;
            this.lbl_orderid.Location = new System.Drawing.Point(64, 50);
            this.lbl_orderid.Name = "lbl_orderid";
            this.lbl_orderid.Size = new System.Drawing.Size(44, 13);
            this.lbl_orderid.TabIndex = 0;
            this.lbl_orderid.Text = "OrderID";
            // 
            // lbl_CustName
            // 
            this.lbl_CustName.AutoSize = true;
            this.lbl_CustName.Location = new System.Drawing.Point(64, 96);
            this.lbl_CustName.Name = "lbl_CustName";
            this.lbl_CustName.Size = new System.Drawing.Size(79, 13);
            this.lbl_CustName.TabIndex = 1;
            this.lbl_CustName.Text = "CustomerName";
            // 
            // txt_OrderID
            // 
            this.txt_OrderID.Location = new System.Drawing.Point(256, 43);
            this.txt_OrderID.Name = "txt_OrderID";
            this.txt_OrderID.Size = new System.Drawing.Size(100, 20);
            this.txt_OrderID.TabIndex = 2;
            // 
            // txt_CustName
            // 
            this.txt_CustName.Location = new System.Drawing.Point(256, 96);
            this.txt_CustName.Name = "txt_CustName";
            this.txt_CustName.Size = new System.Drawing.Size(100, 20);
            this.txt_CustName.TabIndex = 3;
            // 
            // lbl_itemid
            // 
            this.lbl_itemid.AutoSize = true;
            this.lbl_itemid.Location = new System.Drawing.Point(64, 141);
            this.lbl_itemid.Name = "lbl_itemid";
            this.lbl_itemid.Size = new System.Drawing.Size(38, 13);
            this.lbl_itemid.TabIndex = 4;
            this.lbl_itemid.Text = "ItemID";
            // 
            // lbl_qty
            // 
            this.lbl_qty.AutoSize = true;
            this.lbl_qty.Location = new System.Drawing.Point(64, 188);
            this.lbl_qty.Name = "lbl_qty";
            this.lbl_qty.Size = new System.Drawing.Size(43, 13);
            this.lbl_qty.TabIndex = 5;
            this.lbl_qty.Text = "ItemQty";
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Location = new System.Drawing.Point(64, 231);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(51, 13);
            this.lbl_price.TabIndex = 6;
            this.lbl_price.Text = "ItemPrice";
            // 
            // btn_placaorder
            // 
            this.btn_placaorder.Location = new System.Drawing.Point(125, 293);
            this.btn_placaorder.Name = "btn_placaorder";
            this.btn_placaorder.Size = new System.Drawing.Size(86, 45);
            this.btn_placaorder.TabIndex = 7;
            this.btn_placaorder.Text = "Place Order";
            this.btn_placaorder.UseVisualStyleBackColor = true;
            this.btn_placaorder.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_ItemID
            // 
            this.txt_ItemID.Location = new System.Drawing.Point(256, 141);
            this.txt_ItemID.Name = "txt_ItemID";
            this.txt_ItemID.Size = new System.Drawing.Size(100, 20);
            this.txt_ItemID.TabIndex = 8;
            // 
            // txt_ItemQty
            // 
            this.txt_ItemQty.Location = new System.Drawing.Point(256, 185);
            this.txt_ItemQty.Name = "txt_ItemQty";
            this.txt_ItemQty.Size = new System.Drawing.Size(100, 20);
            this.txt_ItemQty.TabIndex = 9;
            // 
            // txt_ItemPrice
            // 
            this.txt_ItemPrice.Location = new System.Drawing.Point(256, 224);
            this.txt_ItemPrice.Name = "txt_ItemPrice";
            this.txt_ItemPrice.Size = new System.Drawing.Size(100, 20);
            this.txt_ItemPrice.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 449);
            this.Controls.Add(this.txt_ItemPrice);
            this.Controls.Add(this.txt_ItemQty);
            this.Controls.Add(this.txt_ItemID);
            this.Controls.Add(this.btn_placaorder);
            this.Controls.Add(this.lbl_price);
            this.Controls.Add(this.lbl_qty);
            this.Controls.Add(this.lbl_itemid);
            this.Controls.Add(this.txt_CustName);
            this.Controls.Add(this.txt_OrderID);
            this.Controls.Add(this.lbl_CustName);
            this.Controls.Add(this.lbl_orderid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_orderid;
        private System.Windows.Forms.Label lbl_CustName;
        private System.Windows.Forms.TextBox txt_OrderID;
        private System.Windows.Forms.TextBox txt_CustName;
        private System.Windows.Forms.Label lbl_itemid;
        private System.Windows.Forms.Label lbl_qty;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.Button btn_placaorder;
        private System.Windows.Forms.TextBox txt_ItemID;
        private System.Windows.Forms.TextBox txt_ItemQty;
        private System.Windows.Forms.TextBox txt_ItemPrice;
    }
}

