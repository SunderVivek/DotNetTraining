﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADIO2
{
    public partial class Frm_Mars : Form
    {
        public Frm_Mars()
        {
            InitializeComponent();
        }

        private void btn_mars_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            con.Open();
            SqlCommand com_order = new SqlCommand("Select * from orders", con);
            SqlDataReader dr_order = com_order.ExecuteReader();
            SqlCommand com_items = new SqlCommand("select * from orderdetails", con);
            SqlDataReader dr_items = com_items.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr_order);

            dg_Orders.DataSource = dt;
            //Reading
            con.Close();
        }
    }
}
