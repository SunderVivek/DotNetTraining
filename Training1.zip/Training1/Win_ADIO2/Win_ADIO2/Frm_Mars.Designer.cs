﻿namespace Win_ADIO2
{
    partial class Frm_Mars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_mars = new System.Windows.Forms.Button();
            this.dg_Orders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_Orders)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_mars
            // 
            this.btn_mars.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_mars.Location = new System.Drawing.Point(34, 12);
            this.btn_mars.Name = "btn_mars";
            this.btn_mars.Size = new System.Drawing.Size(100, 62);
            this.btn_mars.TabIndex = 0;
            this.btn_mars.Text = "MARS";
            this.btn_mars.UseVisualStyleBackColor = true;
            this.btn_mars.Click += new System.EventHandler(this.btn_mars_Click);
            // 
            // dg_Orders
            // 
            this.dg_Orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_Orders.Location = new System.Drawing.Point(12, 95);
            this.dg_Orders.Name = "dg_Orders";
            this.dg_Orders.Size = new System.Drawing.Size(570, 323);
            this.dg_Orders.TabIndex = 1;
            // 
            // Frm_Mars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(594, 430);
            this.Controls.Add(this.dg_Orders);
            this.Controls.Add(this.btn_mars);
            this.Name = "Frm_Mars";
            this.Text = "Frm_Mars";
            ((System.ComponentModel.ISupportInitialize)(this.dg_Orders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_mars;
        private System.Windows.Forms.DataGridView dg_Orders;
    }
}