﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADIO2
{
    class Order
    {
        public int OrderID { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDate { get; set; }

         public List<Item> items = new List<Item>();
        public void AddItem(Item item)
        {
            items.Add(item);
        }

        
    }
}
