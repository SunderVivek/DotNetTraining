﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_ADIO2
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string Employeepassword { get; set; }
        public string EmployeeName { get; set; }
    }
}
