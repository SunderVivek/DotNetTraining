﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ADIO2
{
    public partial class Frm_Proc_from_frontend : Form
    {
        public Frm_Proc_from_frontend()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.EmployeeID = Convert.ToInt32(txt_EmpID.Text);
            obj.Employeepassword = txt_Emppwd.Text;
            Employee_DAL dal = new Employee_DAL();
            bool status=dal.Login(obj);
            if (status)
            { MessageBox.Show("Valid user:" + obj.EmployeeName); }
            else
            { MessageBox.Show("Invalid user"); }

        }
    }
}
