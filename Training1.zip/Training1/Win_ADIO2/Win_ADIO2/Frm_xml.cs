﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ADIO2
{
    public partial class Frm_xml : Form
    {
        public Frm_xml()
        {
            InitializeComponent();
        }

        private void btn_save_xml_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlDataAdapter adapter_orders = new SqlDataAdapter("Select * from orders", con);
            DataSet ds = new DataSet();
            adapter_orders.Fill(ds, "ord");
            ds.WriteXml("C:/xml_test/ords.xml");
            MessageBox.Show("XML file generated");
        }

        private void btn_read_xml_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds.ReadXml("C:/xml_test/ords.xml");
            dg_orders.DataSource = ds.Tables[0];
        }
    }
}
