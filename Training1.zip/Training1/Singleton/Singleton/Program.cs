﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Singleton
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager man1 = Manager.GetManager();
            Manager man2 = Manager.GetManager();
            if (man1 == man2)
                Console.WriteLine("Same manager");
            Console.ReadLine();

        }
    }
}
