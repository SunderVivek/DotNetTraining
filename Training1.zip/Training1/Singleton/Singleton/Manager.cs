﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Singleton
{
    class Manager
    {
        String ManagerName;
        int Managerid;
        public String PManagername
        {
            get {
                return ManagerName;
            }
                      
        }
        public int PManagerid
        {
            get {
                return Managerid;
                }
        }
        private Manager(String ManagerName, int Managerid)
        {
            this.ManagerName = ManagerName;
            this.Managerid = Managerid;
        }
        static Manager m;
        public static Manager GetManager()
        {            
            if(m==null)
                m = new Manager("abc", 25);
            return m;
        }
    }
}
