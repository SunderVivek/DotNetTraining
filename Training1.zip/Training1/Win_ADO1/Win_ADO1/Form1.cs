﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO1
{
    public partial class Frm_EmpDetails : Form
    { SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            
        public Frm_EmpDetails()
        {
            InitializeComponent();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_EmpID.Text = "";
            txt_EmpName.Text = "";
           
            txt_EmpAge.Text = "";
            txt_EmpPass.Text = "";
        }

        private void btn_AddEmp_Click(object sender, EventArgs e)
        {
            Employee obj = new Employee();
            obj.EmployeeName = txt_EmpName.Text;
            obj.EmployeeCity = cmb_Empcity.Text;
            obj.EmployeeAge = Convert.ToInt32(txt_EmpAge.Text);
            obj.EmployeePassword = txt_EmpPass.Text;

            EmployeesDAL dal = new EmployeesDAL();
            dal.AddEmployee(obj);
            MessageBox.Show("Employee added succesfully:"+obj.EmployeeID);
             
        }

        private void btn_findEmp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_find_emp = new SqlCommand("Select * from Employees where EmployeeID=@empid", con);
            com_find_emp.Parameters.AddWithValue("@empid", txt_EmpID.Text);
            SqlDataReader dr = com_find_emp.ExecuteReader();
            if (dr.Read())
            {
                txt_EmpID.Text = dr.GetInt32(0).ToString();
                txt_EmpName.Text = dr.GetString(1);
                cmb_Empcity.Text = dr.GetString(2);
                txt_EmpAge.Text = dr.GetInt32(3).ToString();
                txt_EmpPass.Text = dr.GetString(4);
            }
            else { MessageBox.Show("Employee not found"); }
            con.Close();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_update_emp=new SqlCommand("update employees set employeename=@empname,employeecity=@empcity where employeeid=@empid",con);
            com_update_emp.Parameters.AddWithValue("@empname", txt_EmpName.Text);
            com_update_emp.Parameters.AddWithValue("@empcity", cmb_Empcity.Text);
            com_update_emp.Parameters.AddWithValue("@empid", txt_EmpID.Text);

            int rowsaffected = com_update_emp.ExecuteNonQuery();
            con.Close();
            if (rowsaffected > 0)
            {
                MessageBox.Show("Emplyee updated");
            }
            else { MessageBox.Show("Employee not found"); }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_cities = new SqlCommand("Select cityname from cities", con);
            SqlDataReader dr = com_cities.ExecuteReader();
            while (dr.Read())
            {
                cmb_Empcity.Items.Add(dr.GetString(0));
            }
            con.Close();
        }
    }
}
