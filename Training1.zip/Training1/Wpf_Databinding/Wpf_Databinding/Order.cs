﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_Databinding
{
    class Order
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public DateTime OrderDate { get; set; }
        public string OrderAddress { get; set; }
        public int ProductID { get; set; }
        public int ProductPrice { get; set; }
        public int ProductQty { get; set; }
    }
}
