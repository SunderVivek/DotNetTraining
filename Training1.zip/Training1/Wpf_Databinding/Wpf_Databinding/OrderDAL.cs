﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_Databinding
{
    class OrderDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public bool PlaceOrder(Order ord)
        {
            SqlCommand com_order_insert = new SqlCommand("insert orders values(@custid,getDate(),@addr,@pid,@price,@qty)", con);
            com_order_insert.Parameters.AddWithValue("@custid", ord.CustomerID);
            com_order_insert.Parameters.AddWithValue("@addr", ord.OrderAddress);
            com_order_insert.Parameters.AddWithValue("@pid", ord.ProductID);
            com_order_insert.Parameters.AddWithValue("@price", ord.ProductPrice);
            com_order_insert.Parameters.AddWithValue("@qty", ord.ProductQty);
            con.Open();
            com_order_insert.ExecuteNonQuery();
            SqlCommand com_orderid = new SqlCommand("select @@identity", con);
            int orderid = Convert.ToInt32(com_orderid.ExecuteScalar());
            ord.OrderID = orderid;
            con.Close();
            return true;
        }
        public List<Order> GetOrders(int CustomerID)
        {

            List<Order> orderslist = new List<Order>();
            SqlCommand com_orders = new SqlCommand("Select * from orders where customerid=@custid", con);
            com_orders.Parameters.AddWithValue("@custid", CustomerID);
            con.Open();
            SqlDataReader dr = com_orders.ExecuteReader();
            while (dr.Read())
            {
                Order ord = new Order();
                ord.OrderID = dr.GetInt32(0);
                ord.CustomerID = dr.GetInt32(1);
                ord.OrderDate = dr.GetDateTime(2);
                ord.OrderAddress = dr.GetString(3);
                ord.ProductID = dr.GetInt32(4);
                ord.ProductPrice = dr.GetInt32(5);
                ord.ProductQty = dr.GetInt32(6);
                orderslist.Add(ord);
            }
            con.Close();
            return orderslist;
        }

    }
}
