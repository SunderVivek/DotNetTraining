﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_Databinding
{
    class ProductDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public Product GetProduct(int ProductID)
        {
            Product p = new Product();
            SqlCommand com_product = new SqlCommand("Select* from products where productid=@pid", con);
            com_product.Parameters.AddWithValue("@pid", ProductID);
            con.Open();
            SqlDataReader dr = com_product.ExecuteReader();
            if (dr.Read())
            {
                p.ProductID = dr.GetInt32(0);
                p.ProductName = dr.GetString(1);
                p.ProductPrice = dr.GetInt32(2);
            }
            con.Close();
            return p;
        }

        public List<Product> GetProducts()
        {
            
            SqlCommand com_product = new SqlCommand("Select* from products ", con);
            List<Product> productlist = new List<Product>();
            con.Open();
            SqlDataReader dr = com_product.ExecuteReader();
            while (dr.Read())
            {
                Product p = new Product();
                p.ProductID = dr.GetInt32(0);
                p.ProductName = dr.GetString(1);
                p.ProductPrice = dr.GetInt32(2);
                productlist.Add(p);
            }
            con.Close();
            return productlist;
        }
    }
}
