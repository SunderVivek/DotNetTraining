﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Databinding
{
    /// <summary>
    /// Interaction logic for Window_Login.xaml
    /// </summary>
    public partial class Window_Login : Window
    {
        public Window_Login()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            Customer c = new Customer();
            c.CustomerID = Convert.ToInt32(txt_loginid.Text);
            c.CustomerPassword = txt_password.Password;
            if (dal.Login(c))
            {
                MessageBox.Show("Valid Customer");
                App.Current.Properties.Add("cid", txt_loginid.Text);
                Window_home home = new Window_home();
                home.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Customer");
            }
        }
    }
}
