﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_Databinding
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool Login(Customer obj)
        {
            con.Open();
            SqlCommand com_customer_login=new SqlCommand("Select count(*) from customers where customerid=@custid and CustomerPassword=@custpwd",con);
            com_customer_login.Parameters.AddWithValue("@custid", obj.CustomerID);
            com_customer_login.Parameters.AddWithValue("@custpwd", obj.CustomerPassword);
            int count = Convert.ToInt32(com_customer_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

            
        }
    }
}
