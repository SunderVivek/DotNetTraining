﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Databinding
{
    /// <summary>
    /// Interaction logic for Window_home.xaml
    /// </summary>
    public partial class Window_home : Window
    {
        public Window_home()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_customerid.Text = "CustomerID:"+App.Current.Properties["cid"].ToString();
        }

        private void btn_PlaceOrder_Click(object sender, RoutedEventArgs e)
        {
            Window_PlaceOrder placeorder = new Window_PlaceOrder();
            placeorder.Show();
        }

        private void btn_ShowOrders_Click(object sender, RoutedEventArgs e)
        {
            Window_ShowOrders showorders = new Window_ShowOrders();
            showorders.Show();
        }

        private void btn_FindProduct_Click(object sender, RoutedEventArgs e)
        {
            Window_ShowProduct obj = new Window_ShowProduct();
            obj.Show();

        }
    }
}
