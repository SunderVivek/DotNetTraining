﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Databinding
{
    /// <summary>
    /// Interaction logic for Window_ShowOrders.xaml
    /// </summary>
    public partial class Window_ShowOrders : Window
    {
        public Window_ShowOrders()
        {
            InitializeComponent();
        }

        private void btn_show_orders_Click(object sender, RoutedEventArgs e)
        {
            OrderDAL dal = new OrderDAL();
            int CustomerID = Convert.ToInt32(App.Current.Properties["cid"]);
            dg_orders.ItemsSource = dal.GetOrders(CustomerID);
        }
    }
}
