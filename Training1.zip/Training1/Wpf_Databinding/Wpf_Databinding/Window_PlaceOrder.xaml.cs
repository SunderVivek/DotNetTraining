﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Databinding
{
    /// <summary>
    /// Interaction logic for Window_PlaceOrder.xaml
    /// </summary>
    public partial class Window_PlaceOrder : Window
    {
        public Window_PlaceOrder()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ProductDAL dal = new ProductDAL();
            lst_Products.ItemsSource = dal.GetProducts();

        }

        private void btn_placeorder_Click(object sender, RoutedEventArgs e)
        {
            Product p = lst_Products.SelectedItem as Product;
            if (p != null)
            {
                OrderDAL dal = new OrderDAL();
                Order ord = new Order();
                ord.ProductID = p.ProductID;
                ord.ProductPrice = p.ProductPrice;
                ord.ProductQty = Convert.ToInt32(txt_itemqty.Text);
                ord.OrderAddress = txt_address.Text;
                ord.CustomerID = Convert.ToInt32(App.Current.Properties["cid"]);
                dal.PlaceOrder(ord);
                MessageBox.Show("Order placed succesfully!!" + ord.OrderID);
            }
            else
            {
                MessageBox.Show("Select a Product");
            }
        }
    }
}
