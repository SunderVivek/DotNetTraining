﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Databinding
{
    /// <summary>
    /// Interaction logic for Window_ShowProduct.xaml
    /// </summary>
    public partial class Window_ShowProduct : Window
    {
        public Window_ShowProduct()
        {
            InitializeComponent();
        }

        private void btn_Find_Click(object sender, RoutedEventArgs e)
        {
            ProductDAL dal = new ProductDAL();
            stp_Product.DataContext = dal.GetProduct(Convert.ToInt32(txt_pid.Text));
        }
    }
}
