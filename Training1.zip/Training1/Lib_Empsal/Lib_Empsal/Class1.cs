﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lib_Empsal
{
    public class Empsal
    {
        double per_day_sal;
        int no_of_days;
        public Empsal(double perday, int totday)
        {
            per_day_sal = perday;
            no_of_days=totday;
        }
        public double GetSal()
        {
            return per_day_sal * no_of_days;
        }
    }
}
