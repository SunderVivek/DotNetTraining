Create table EmployeeLogin
(
EmployeeID int identity(1000,1) primary key,
EmployeeName varchar(20),
EmployeeCity varchar(15),
)
select * from EmployeeLogin