﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_first
{
    public partial class Form_Login : Form
    {
        public Form_Login()
        {

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = textBox_Login.Text;
            string pass = textBox_pass.Text;
            if (id == "")
                MessageBox.Show("Enter userid");
            else if(pass =="")
                MessageBox.Show("Enter password");
            else
            {
                if (id == "sunder" && pass == "hyd")
                {
                    MessageBox.Show("Login succesful");
                    Form_Home obj = new Form_Home();
                    obj.Show();
                }
                else
                    MessageBox.Show("Login failed");
            }
        }
    }
}
