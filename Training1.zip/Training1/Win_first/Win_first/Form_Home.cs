﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_first
{
    public partial class Form_Home : Form
    {
        public Form_Home()
        {
            InitializeComponent();
        }

       
        private void list_city_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button_getcity_Click(object sender, EventArgs e)
        {



            if (chk_orderstatus.Checked)
            {
                MessageBox.Show("Order completed");
            }
            else {
                MessageBox.Show("Order discarded");
            }
            String city = list_city.Text;
            if (city == "")
                MessageBox.Show("Select a city");
            else
                MessageBox.Show(city);
        }

        private void cmb_items_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form_Home_Load(object sender, EventArgs e)
        {
            list_city.Items.Add("Chennai");
            list_city.Items.Add("pune");
            list_city.Items.Add("hyd");

            cmb_items.Items.Add("CD");
            cmb_items.Items.Add("Pendrive");
            cmb_items.Items.Add("RAM-1GB");


        }

        private void chk_orderstatus_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
