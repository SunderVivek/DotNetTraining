﻿namespace Win_first
{
    partial class Form_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.list_city = new System.Windows.Forms.ListBox();
            this.button_getcity = new System.Windows.Forms.Button();
            this.cmb_items = new System.Windows.Forms.ComboBox();
            this.chk_orderstatus = new System.Windows.Forms.CheckBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 27.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(198, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Home";
            // 
            // list_city
            // 
            this.list_city.FormattingEnabled = true;
            this.list_city.Location = new System.Drawing.Point(31, 112);
            this.list_city.Name = "list_city";
            this.list_city.Size = new System.Drawing.Size(120, 95);
            this.list_city.TabIndex = 1;
            this.list_city.SelectedIndexChanged += new System.EventHandler(this.list_city_SelectedIndexChanged);
            // 
            // button_getcity
            // 
            this.button_getcity.Location = new System.Drawing.Point(256, 137);
            this.button_getcity.Name = "button_getcity";
            this.button_getcity.Size = new System.Drawing.Size(114, 44);
            this.button_getcity.TabIndex = 2;
            this.button_getcity.Text = "Get city";
            this.button_getcity.UseVisualStyleBackColor = true;
            this.button_getcity.Click += new System.EventHandler(this.button_getcity_Click);
            // 
            // cmb_items
            // 
            this.cmb_items.FormattingEnabled = true;
            this.cmb_items.Location = new System.Drawing.Point(82, 271);
            this.cmb_items.Name = "cmb_items";
            this.cmb_items.Size = new System.Drawing.Size(121, 21);
            this.cmb_items.TabIndex = 3;
            this.cmb_items.SelectedIndexChanged += new System.EventHandler(this.cmb_items_SelectedIndexChanged);
            // 
            // chk_orderstatus
            // 
            this.chk_orderstatus.AutoSize = true;
            this.chk_orderstatus.Location = new System.Drawing.Point(349, 271);
            this.chk_orderstatus.Name = "chk_orderstatus";
            this.chk_orderstatus.Size = new System.Drawing.Size(76, 17);
            this.chk_orderstatus.TabIndex = 4;
            this.chk_orderstatus.Text = "Completed";
            this.chk_orderstatus.UseVisualStyleBackColor = true;
            this.chk_orderstatus.CheckedChanged += new System.EventHandler(this.chk_orderstatus_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(232, 325);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 5;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(232, 348);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(85, 17);
            this.radioButton2.TabIndex = 6;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // Form_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 431);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.chk_orderstatus);
            this.Controls.Add(this.cmb_items);
            this.Controls.Add(this.button_getcity);
            this.Controls.Add(this.list_city);
            this.Controls.Add(this.label1);
            this.Name = "Form_Home";
            this.Text = "Form_Home";
            this.Load += new System.EventHandler(this.Form_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox list_city;
        private System.Windows.Forms.Button button_getcity;
        private System.Windows.Forms.ComboBox cmb_items;
        private System.Windows.Forms.CheckBox chk_orderstatus;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}