﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ProductDAL dal = new ProductDAL();
            gv_ProducList.DataSource = dal.GetProducts();
            gv_ProducList.DataBind();
        }

    }
    protected void gv_ProducList_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label lbl = gv_ProducList.SelectedRow.FindControl("lbl_pid") as Label;
        int pid = Convert.ToInt32(lbl.Text);
        Response.Redirect("~/ProductDetails.aspx?pid=" + pid);
    }
}