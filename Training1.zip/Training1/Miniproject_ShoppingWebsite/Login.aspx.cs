﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_userid.Text, txt_password.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_userid.Text, chk_remember.Checked);            
            Response.Redirect("~/CustomerHome.aspx?cid="+txt_userid.Text);
        }
        else
        {
            lbl_msg.Text = "Invalid UserID or Password";
        }
    }
    protected void btn_AddCustomer_Click(object sender, EventArgs e)
    {
        Customer c = new Customer();
        c.CustomerName = txt_custname.Text;
        c.CustomerContactNum = Convert.ToInt32(txt_cust_contnum.Text);
        CustomerDAL dal = new CustomerDAL();
        if (dal.AddCustomer(c, txt_custemail.Text, txt_custpwd.Text, txt_securityquestion.Text, txt_securityanswer.Text))
        {
            lbl_status.Text = "Customer Created";
            txt_custid.Text = c.CustomerID.ToString();
        }
        else
        {
            lbl_status.Text = "Customer Not Created";
        }
    }
    protected void btn_admin_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/ProductEntry.aspx");
    }
}