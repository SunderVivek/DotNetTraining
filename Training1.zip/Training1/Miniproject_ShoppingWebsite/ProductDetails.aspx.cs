﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class ProductDetails : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int pid = Convert.ToInt32(Request.QueryString["pid"].ToString());
            ProductDAL dal = new ProductDAL();
            Product p = dal.GetProduct(pid);
            lbl_prodname.Text = p.ProductName;
            lbl_prodmodel.Text = p.ProductModel;
            lbl_proddescription.Text = p.ProductDesc;
            lbl_prodprice.Text = Convert.ToString(p.ProductPrice);
            img_product.ImageUrl= p.ProductImageAddress;
            
        }
    }
    protected void btn_addtocart_Click(object sender, EventArgs e)
    {
        Customer c = new Customer();
        c.CustomerID = Convert.ToInt32(Page.User.Identity.Name);
        Product p = new Product();
        p.productid = Convert.ToInt32(Request.QueryString["pid"]);

        CustomerDAL dal = new CustomerDAL();
        if (dal.AddToCart(c, p))
        {
            lbl_addtocart_stat.Text = "Product Added to Cart";
        }
        else
        {
            lbl_addtocart_stat.Text = "Product Not Added to Cart";
        }
    }


    
}