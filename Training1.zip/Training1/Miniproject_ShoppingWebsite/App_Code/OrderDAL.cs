﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for OrderDAL
/// </summary>
public class OrderDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public void CreateOrder(Order o)
    {
        SqlCommand com_insertorder = new SqlCommand("insert Orders values(@custid,@pid,@qty,@price,getDate())", con);
        com_insertorder.Parameters.AddWithValue("@custid", o.customerid);
        com_insertorder.Parameters.AddWithValue("@pid", o.productid);
        com_insertorder.Parameters.AddWithValue("@qty", o.quantity);
        com_insertorder.Parameters.AddWithValue("@price", o.price);
        con.Open();
        com_insertorder.ExecuteNonQuery();
        SqlCommand com_orderid = new SqlCommand("select @@identity", con);
        o.orderid=Convert.ToInt32(com_orderid.ExecuteScalar());//delete from Cart where ProductID in (select ProductID from Orders where OrderID=@oid)

        SqlCommand com_delete_fromcart = new SqlCommand("Delete from Cart where ProductID in (select ProductID from Orders where OrderID=@oid)", con);
        com_delete_fromcart.Parameters.AddWithValue("@oid", o.orderid);
        com_delete_fromcart.ExecuteNonQuery();
        con.Close();
       
    }

    public List<Order> GetOrders(int custid)        //MyOrders of Customer
    {
        List<Order> ordlist = new List<Order>();
        SqlCommand com_getorders = new SqlCommand("select * from Orders where CustomerID=@custid", con);
        com_getorders.Parameters.AddWithValue("@custid", custid);
        con.Open();
        SqlDataReader dr = com_getorders.ExecuteReader();
        while (dr.Read())
        {
            Order o = new Order();
            o.orderid = dr.GetInt32(0);
            o.customerid = dr.GetInt32(1);
            o.productid = dr.GetInt32(2);
            o.quantity = dr.GetInt32(3);
            o.price = dr.GetInt32(4);
            o.orderdate = dr.GetDateTime(5);
            ordlist.Add(o);
        }
        con.Close();
        return ordlist;
    }

    public List<Order> GetOrders()        //My Orders of Admin
    {
        List<Order> ordlist = new List<Order>();
        SqlCommand com_getorders = new SqlCommand("select * from Orders", con);
        
        con.Open();
        SqlDataReader dr = com_getorders.ExecuteReader();
        while (dr.Read())
        {
            Order o = new Order();
            o.orderid = dr.GetInt32(0);
            o.customerid = dr.GetInt32(1);
            o.productid = dr.GetInt32(2);
            o.quantity = dr.GetInt32(3);
            o.price = dr.GetInt32(4);
            o.orderdate = dr.GetDateTime(5);
            ordlist.Add(o);
        }
        con.Close();
        return ordlist;
    }

    public Order GetOrder(int orderid)        //For Order Details after placing order
    {        
        SqlCommand com_getorder = new SqlCommand("select * from Orders where OrderID=@oid", con);
        com_getorder.Parameters.AddWithValue("oid", orderid);
        Order o = null;
        con.Open();
        SqlDataReader dr = com_getorder.ExecuteReader();
        if (dr.Read())
        {
            o = new Order();
            o.orderid = dr.GetInt32(0);
            o.customerid = dr.GetInt32(1);
            o.productid = dr.GetInt32(2);
            o.quantity = dr.GetInt32(3);
            o.price = dr.GetInt32(4);
            o.orderdate = dr.GetDateTime(5);
           
        }
        con.Close();
        return o;
    }
}