﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for ProductDAL
/// </summary>
public class ProductDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    
    public bool AddProduct(Product p)
    {
        SqlCommand com_insertproduct = new SqlCommand("insert Products values(@prodname,@prodprice,@proddesc,@prodmodel,@prodcategory,null)",con);
        com_insertproduct.Parameters.AddWithValue("@prodname", p.ProductName);
        com_insertproduct.Parameters.AddWithValue("@prodprice",p.ProductPrice);
        com_insertproduct.Parameters.AddWithValue("@proddesc",p.ProductDesc);
        com_insertproduct.Parameters.AddWithValue("@prodmodel",p.ProductModel);
        com_insertproduct.Parameters.AddWithValue("@prodcategory", p.ProductCategory);

        con.Open();
        com_insertproduct.ExecuteNonQuery();

        SqlCommand com_prodid = new SqlCommand("select @@identity", con);
        p.productid = Convert.ToInt32(com_prodid.ExecuteScalar());

        p.ProductImageAddress="~/ProductImages/"+p.productid+".jpg";

        SqlCommand com_update_imgaddr = new SqlCommand("update Products set ProductImageAddress=@imgaddr where ProductID=@pid",con);
        com_update_imgaddr.Parameters.AddWithValue("@imgaddr", p.ProductImageAddress);
        com_update_imgaddr.Parameters.AddWithValue("pid", p.productid);
        com_update_imgaddr.ExecuteNonQuery();
        con.Close();
        return true;
    }

    public List<Product> GetProducts()
    {
        List<Product> prodlist = new List<Product>();
        SqlCommand com_getprod=new SqlCommand("select * from Products",con);
        con.Open();
        SqlDataReader dr=com_getprod.ExecuteReader();
        while (dr.Read())
        {
            Product p = new Product();
            p.productid = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductDesc = dr.GetString(3);
            p.ProductModel = dr.GetString(4);
            p.ProductCategory = dr.GetString(5);
            p.ProductImageAddress = dr.GetString(6);
            prodlist.Add(p);
        }
        con.Close();
        return prodlist;
    }

    public Product GetProduct(int pid)
    {
        Product p = null;
        SqlCommand com_getprod = new SqlCommand("select * from Products where ProductID=@pid",con);
        com_getprod.Parameters.AddWithValue("@pid", pid);
        con.Open();
        SqlDataReader dr = com_getprod.ExecuteReader();
        if (dr.Read())
        {
            p = new Product();
            p.productid = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductDesc = dr.GetString(3);
            p.ProductModel = dr.GetString(4);
            p.ProductCategory = dr.GetString(5);
            p.ProductImageAddress = dr.GetString(6);
            
        }
        con.Close();
        return p;
    }
}