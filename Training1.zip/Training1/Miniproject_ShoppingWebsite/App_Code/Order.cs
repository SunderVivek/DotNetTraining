﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Order
/// </summary>
public class Order
{
    public int orderid { get; set; }
    public int customerid { get; set; }
    public int productid { get; set; }
    public int quantity { get; set; }
    public int price { get; set; }
    public DateTime orderdate { get; set; }
}