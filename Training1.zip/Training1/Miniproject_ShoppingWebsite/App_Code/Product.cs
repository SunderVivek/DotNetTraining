﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


/// <summary>
/// Summary description for Product
/// </summary>
public class Product
{
    public int productid { get; set; }
    public string ProductName { get; set; }
    public int ProductPrice { get; set; }
    public string ProductDesc { get; set; }
    public string ProductModel { get; set; }
    public string ProductCategory { get; set; }
    public string ProductImageAddress { get; set; }
}