﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

    public bool AddCustomer(Customer c, string email, string password, string question, string answer)
    {

        SqlCommand com_insertcustomer = new SqlCommand("insert Customers values(@custname,@custcont)", con);
        com_insertcustomer.Parameters.AddWithValue("@custname", c.CustomerName);
        com_insertcustomer.Parameters.AddWithValue("@custcont", c.CustomerContactNum);
        con.Open();
        com_insertcustomer.ExecuteNonQuery();

        SqlCommand com_custid = new SqlCommand("select @@identity", con);
        c.CustomerID = Convert.ToInt32(com_custid.ExecuteScalar());

        con.Close();

        MembershipCreateStatus status;
        Membership.CreateUser(c.CustomerID.ToString(), password, email, question, answer, true, out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

        public bool AddToCart(Customer c,Product p)
        {
            SqlCommand com_insert_cart = new SqlCommand("insert Cart values(@custid,@pid,getDate())", con);
            com_insert_cart.Parameters.AddWithValue("@custid", c.CustomerID);
            com_insert_cart.Parameters.AddWithValue("@pid", p.productid);
            con.Open();
            com_insert_cart.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public List<Product> GetCart(int custid)
        {
            SqlCommand com_getcart = new SqlCommand("select * from Products where productid in (select ProductID from Cart where CustomerID=@custid)", con);
            com_getcart.Parameters.AddWithValue("@custid",custid);
            con.Open();
            SqlDataReader dr= com_getcart.ExecuteReader();
            
            List<Product> prodlist=new List<Product>();
            while (dr.Read())
            {
                Product p = new Product();
                p.productid = dr.GetInt32(0);
                p.ProductName = dr.GetString(1);
                p.ProductPrice = dr.GetInt32(2);
                p.ProductDesc = dr.GetString(3);
                p.ProductModel = dr.GetString(4);
                p.ProductCategory = dr.GetString(5);
                p.ProductImageAddress = dr.GetString(6);
                prodlist.Add(p);
            }

            con.Close();
            return prodlist;

        }
    
}