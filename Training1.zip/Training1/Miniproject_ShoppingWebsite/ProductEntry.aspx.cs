﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ProductEntry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_addproduct_Click(object sender, EventArgs e)
    {
        Product p = new Product();
        p.ProductName = txt_productname.Text;
        p.ProductModel = txt_productmodel.Text;
        p.ProductDesc = txt_productdescription.Text;
        p.ProductCategory = txt_productcategory.Text;
        p.ProductPrice = Convert.ToInt32(txt_productprice.Text);

        ProductDAL dal = new ProductDAL();
        if (dal.AddProduct(p))
        {
            lbl_status.Text = "ProductAdded";
        }
        imgup_prod.SaveAs(MapPath(p.ProductImageAddress));

    }
}