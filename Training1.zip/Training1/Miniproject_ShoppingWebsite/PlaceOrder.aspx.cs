﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PlaceOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int pid = Convert.ToInt32(Request.QueryString["pid"]);
            ProductDAL dal = new ProductDAL();
            Product p = dal.GetProduct(pid);
            lbl_pid.Text = p.productid.ToString();
            lbl_pname.Text = p.ProductName;
            lbl_price.Text = p.ProductPrice.ToString();
           
            ddl_qty.Items.Add("select");
            ddl_qty.Items.Add("1");
            ddl_qty.Items.Add("2");
            ddl_qty.Items.Add("3");
            ddl_qty.Items.Add("4");
            ddl_qty.Items.Add("5");
        }
    }
    protected void btn_PlaceOrder_Click(object sender, EventArgs e)
    {
        Order o = new Order();
        o.productid = Convert.ToInt32(Request.QueryString["pid"]);
        o.customerid = Convert.ToInt32(Page.User.Identity.Name);
        o.quantity = Convert.ToInt32(ddl_qty.Text);
        o.price = Convert.ToInt32(lbl_price.Text);

        OrderDAL dal = new OrderDAL();
        dal.CreateOrder(o);
        Response.Redirect("~/OrderPlaced.aspx?oid=" + o.orderid);
    }
}