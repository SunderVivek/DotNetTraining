﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyCartItems : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int custid = Convert.ToInt32(Page.User.Identity.Name);
            CustomerDAL dal = new CustomerDAL();
            gv_cart.DataSource= dal.GetCart(custid);
            gv_cart.DataBind();
            
        }
        
     }
    protected void gv_cart_SelectedIndexChanged(object sender, EventArgs e)
    {

        Label lbl = gv_cart.SelectedRow.FindControl("lbl_pid") as Label;
        int pid = Convert.ToInt32(lbl.Text);
        Response.Redirect("~/PlaceOrder.aspx?pid="+pid);
    }
}