﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OrderPlaced : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Order o=new Order();
            OrderDAL dal = new OrderDAL();
            o=dal.GetOrder(Convert.ToInt32(Request.QueryString["oid"]));
            lbl_orderid.Text = o.orderid.ToString();
            lbl_prodid.Text = o.productid.ToString();
            lbl_qty.Text = o.quantity.ToString();
            lbl_price.Text = o.price.ToString();
            lbl_orderdate.Text = o.orderdate.ToLongDateString();
            }
    }


    protected void btn_Home_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/CustomerHome.aspx");
    }
}