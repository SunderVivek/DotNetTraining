Create database Miniproject



use Miniproject



Create table Customers

(
CustomerID int identity(1000,1) primary key,

CustomerName varchar(20),

CustomerContactNumber int,

)


Create table Products

(
ProductID int identity(1000,1) primary key,

ProductName varchar(20),

ProductPrice int,

ProductDesc varchar(100),

ProductModel varchar(30),

ProductCategory varchar(20),

ProductImageAddress varchar(100)
)



Create table Orders

(
OrderID int identity(2000,1) primary key,

CustomerID int foreign key references Customers(CustomerID),

ProductID int foreign key references Products(ProductID),

Quantity int,
Price int,
OrderDate datetime
)



Create Trigger trg_cartdelete 
on Orders

for delete

as

begin

declare @oid int

select @oid=OrderID from inserted

delete from Cart where ProductID in (select ProductID from Orders where OrderID=@oid)

end





Create table Cart

(
CustomerID int foreign key references Customers(CustomerID),

ProductID int foreign key references Products(ProductID),

AddedDate datetime
)