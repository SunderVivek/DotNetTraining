﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowProductDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int pid = Convert.ToInt32(Request.QueryString["pid"]);
        ProductsDAL dal = new ProductsDAL();
        Product p = dal.GetProduct(pid);

        lbl_productid.Text = p.ProductId.ToString();
        lbl_productname.Text = p.ProductName.ToString();
        lbl_productprice.Text = p.ProductPrice.ToString();
        img_productimage.ImageUrl = p.ProductImageAddress;
    }
}