﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btn_addproduct_Click(object sender, EventArgs e)
    {
        Product p = new Product();
        p.ProductName = txt_productname.Text;
        p.ProductPrice = Convert.ToInt32(txt_productprice.Text);

        ProductsDAL dal = new ProductsDAL();
        dal.AddProduct(p); //adding product,generating productid, updating address of the image
        fileupload_productimage.SaveAs(MapPath(p.ProductImageAddress));
        txt_productid.Text = p.ProductId.ToString();

        Response.Write("<script>alert('Product Added Successfully');</script>");
    }
}