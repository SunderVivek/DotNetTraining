﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ProductsDAL
/// </summary>
public class ProductsDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public bool AddProduct(Product p)
    {
        SqlCommand com_product_insert = new SqlCommand("insert products values(@pname,@pprice,null)", con);
        com_product_insert.Parameters.AddWithValue("@pname", p.ProductName);
        com_product_insert.Parameters.AddWithValue("@pprice", p.ProductPrice);
        con.Open();
        com_product_insert.ExecuteNonQuery();

        SqlCommand com_productid = new SqlCommand("select @@identity", con);
        int productid = Convert.ToInt32(com_productid.ExecuteScalar());
        p.ProductId = productid;

        p.ProductImageAddress = "~/ProductImages/" + productid + ".jpg";

        SqlCommand com_product_update_image_address = new SqlCommand("update products set ProductImageAddress=@address where ProductID=@pid", con);
        com_product_update_image_address.Parameters.AddWithValue("@pid", p.ProductId);
        com_product_update_image_address.Parameters.AddWithValue("@address", p.ProductImageAddress);
        com_product_update_image_address.ExecuteNonQuery();
        con.Close();

        return true;
    }

    public List<Product> GetProducts()
    {
        List<Product> list_products = new List<Product>();
        SqlCommand com_products = new SqlCommand("select * from products",con);
        con.Open();
        SqlDataReader dr = com_products.ExecuteReader();
        while (dr.Read())
        {
            Product p = new Product();
            p.ProductId = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductImageAddress = dr.GetString(3);
            list_products.Add(p);
        }
        con.Close();
        return list_products;
    }

    public Product GetProduct(int productid)
    {
        SqlCommand com_product = new SqlCommand("select * from products where productid=@pid", con);
        com_product.Parameters.AddWithValue("@pid", productid);
        con.Open();
        SqlDataReader dr = com_product.ExecuteReader();
        Product p = new Product();
        if (dr.Read())
        {
            p.ProductId = dr.GetInt32(0);
            p.ProductName = dr.GetString(1);
            p.ProductPrice = dr.GetInt32(2);
            p.ProductImageAddress = dr.GetString(3);
        }
        con.Close();
        return p;
    }
}