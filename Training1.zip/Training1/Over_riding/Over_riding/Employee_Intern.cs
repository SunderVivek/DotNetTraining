﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding
{
    class Employee_Intern : Employee
    {
        public Employee_Intern(int EmpId, String EmpName, int basicsal)
            : base(EmpId, EmpName, basicsal)
        { }

        public override int GetSalary()
        {
            return basicsal;
        }
        public override string GetWork()
        {
            return "Working as a Intern";
        }
    }
}
