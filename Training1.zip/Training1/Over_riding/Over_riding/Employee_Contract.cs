﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding
{
    class Employee_Contract : Employee
    {
        public Employee_Contract(int Empid, string EmpName, int basicsal)
            : base(Empid, EmpName, basicsal)
        { 
        }
        public sealed override int GetSalary()
        {
            return basicsal + 1000;
        }
    }
}
