﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding
{
    class Employee
    {
        String EmpName;
        int EmpId;
       protected  int basicsal;
        public Employee(int EmpId, String EmpName,int basicsal)
        {
            this.EmpId = EmpId;
            this.EmpName = EmpName;
            this.basicsal = basicsal;
        }
        public virtual string GetWork()
        {
            return "Working as a programmer";
         }
        public string GetDetails()
        {
            return EmpId + " " + EmpName;
         }
        public virtual  int GetSalary()
        {
            int tax = 1200;
            return basicsal + 2500 - tax;
        }
    }
}
