﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the EmpId");
            int EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ënter EmpName");
            string empname = Console.ReadLine();
            Console.WriteLine("Enter salary");
            int basic = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee type");
            String Emp_Type=Console.ReadLine();
            Employee obj;
            if (Emp_Type == "Employee")
            {
                obj = new Employee(EmpId, empname, basic);
            }
            else if (Emp_Type == "Intern")
            {
                obj = new Employee_Intern(EmpId, empname, basic);
            }
            else
            {
                obj = new Employee_Contract(EmpId, empname, basic);
            }
            Console.WriteLine(obj.GetDetails());
            Console.WriteLine(obj.GetWork());
            Console.WriteLine(obj.GetSalary());
            Console.ReadLine();
        }
    }
}
