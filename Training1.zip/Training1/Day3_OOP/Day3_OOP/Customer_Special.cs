﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day3_OOP
{
    class Customer_Special : Customer
    {
        String Customer_addr;
        int Credit_limit;
        bool payment_status;
        public Customer_Special(int CustomerId,String CustomerName,string Customer_addr,int Credit_limit) : base(CustomerId,CustomerName)
        {
            this.Customer_addr = Customer_addr;
            this.Credit_limit = Credit_limit;
        }
        public string GetAddress()
        {
            return Customer_addr;
        }
    }
}
