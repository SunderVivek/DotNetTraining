﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day3_OOP
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter CustomerId:");
            int custid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter CustomerName");
            String custname = Console.ReadLine();
            Console.WriteLine("Enter type of Customer");
            string type = Console.ReadLine();
            if (type == "Customer")
            {
                Customer obj = new Customer(custid, custname);
                String details = obj.GetDetails();
                Console.WriteLine(details);
            }
            else {
                Console.WriteLine("Enter Address:");
                String address = Console.ReadLine();
                Customer_Special obj = new Customer_Special(custid,custname,address,1000);
                String details = obj.GetDetails();
                Console.WriteLine(details);
                Console.WriteLine(obj.GetAddress());
            }
            
            Console.ReadLine();
        }
    }
}
