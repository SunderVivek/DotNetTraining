﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day3_OOP
{
    class Customer
    {
        int CustomerId;
        String CustomerName;
        public Customer(int CustomerId, String CustomerName)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
        }
        public Customer(int CustomerId)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = "ABC";
        }
        public String GetDetails()
        {
            return CustomerId + " " + CustomerName;

        }

    }
}
