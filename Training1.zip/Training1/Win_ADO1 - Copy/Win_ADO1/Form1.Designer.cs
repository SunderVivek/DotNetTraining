﻿namespace Win_ADO1
{
    partial class Frm_EmpDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_EmpID = new System.Windows.Forms.Label();
            this.label_EmpName = new System.Windows.Forms.Label();
            this.label_EmployeeCity = new System.Windows.Forms.Label();
            this.label_EmpAge = new System.Windows.Forms.Label();
            this.label_EmpPass = new System.Windows.Forms.Label();
            this.txt_EmpID = new System.Windows.Forms.TextBox();
            this.txt_EmpName = new System.Windows.Forms.TextBox();
            this.txt_EmpAge = new System.Windows.Forms.TextBox();
            this.txt_EmpPass = new System.Windows.Forms.TextBox();
            this.btn_AddEmp = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_findEmp = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.cmb_Empcity = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label_EmpID
            // 
            this.label_EmpID.AutoSize = true;
            this.label_EmpID.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmpID.Location = new System.Drawing.Point(43, 22);
            this.label_EmpID.Name = "label_EmpID";
            this.label_EmpID.Size = new System.Drawing.Size(118, 20);
            this.label_EmpID.TabIndex = 0;
            this.label_EmpID.Text = "EmployeeID";
            // 
            // label_EmpName
            // 
            this.label_EmpName.AutoSize = true;
            this.label_EmpName.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmpName.Location = new System.Drawing.Point(46, 63);
            this.label_EmpName.Name = "label_EmpName";
            this.label_EmpName.Size = new System.Drawing.Size(150, 20);
            this.label_EmpName.TabIndex = 1;
            this.label_EmpName.Text = "EmployeeName";
            // 
            // label_EmployeeCity
            // 
            this.label_EmployeeCity.AutoSize = true;
            this.label_EmployeeCity.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmployeeCity.Location = new System.Drawing.Point(46, 106);
            this.label_EmployeeCity.Name = "label_EmployeeCity";
            this.label_EmployeeCity.Size = new System.Drawing.Size(140, 20);
            this.label_EmployeeCity.TabIndex = 2;
            this.label_EmployeeCity.Text = "EmployeeCity";
            // 
            // label_EmpAge
            // 
            this.label_EmpAge.AutoSize = true;
            this.label_EmpAge.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmpAge.Location = new System.Drawing.Point(46, 146);
            this.label_EmpAge.Name = "label_EmpAge";
            this.label_EmpAge.Size = new System.Drawing.Size(133, 20);
            this.label_EmpAge.TabIndex = 3;
            this.label_EmpAge.Text = "EmployeeAge";
            // 
            // label_EmpPass
            // 
            this.label_EmpPass.AutoSize = true;
            this.label_EmpPass.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EmpPass.Location = new System.Drawing.Point(49, 187);
            this.label_EmpPass.Name = "label_EmpPass";
            this.label_EmpPass.Size = new System.Drawing.Size(194, 20);
            this.label_EmpPass.TabIndex = 4;
            this.label_EmpPass.Text = "EmployeePassword";
            // 
            // txt_EmpID
            // 
            this.txt_EmpID.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmpID.Location = new System.Drawing.Point(249, 22);
            this.txt_EmpID.Name = "txt_EmpID";
            this.txt_EmpID.Size = new System.Drawing.Size(100, 27);
            this.txt_EmpID.TabIndex = 5;
            // 
            // txt_EmpName
            // 
            this.txt_EmpName.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmpName.Location = new System.Drawing.Point(249, 63);
            this.txt_EmpName.Name = "txt_EmpName";
            this.txt_EmpName.Size = new System.Drawing.Size(100, 27);
            this.txt_EmpName.TabIndex = 6;
            // 
            // txt_EmpAge
            // 
            this.txt_EmpAge.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmpAge.Location = new System.Drawing.Point(249, 143);
            this.txt_EmpAge.Name = "txt_EmpAge";
            this.txt_EmpAge.Size = new System.Drawing.Size(100, 27);
            this.txt_EmpAge.TabIndex = 9;
            // 
            // txt_EmpPass
            // 
            this.txt_EmpPass.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_EmpPass.Location = new System.Drawing.Point(249, 184);
            this.txt_EmpPass.Name = "txt_EmpPass";
            this.txt_EmpPass.PasswordChar = '*';
            this.txt_EmpPass.Size = new System.Drawing.Size(100, 27);
            this.txt_EmpPass.TabIndex = 10;
            // 
            // btn_AddEmp
            // 
            this.btn_AddEmp.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddEmp.Location = new System.Drawing.Point(31, 245);
            this.btn_AddEmp.Name = "btn_AddEmp";
            this.btn_AddEmp.Size = new System.Drawing.Size(85, 34);
            this.btn_AddEmp.TabIndex = 11;
            this.btn_AddEmp.Text = "Add Employee";
            this.btn_AddEmp.UseVisualStyleBackColor = true;
            this.btn_AddEmp.Click += new System.EventHandler(this.btn_AddEmp_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.Location = new System.Drawing.Point(171, 245);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(76, 34);
            this.btn_Clear.TabIndex = 12;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_findEmp
            // 
            this.btn_findEmp.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_findEmp.Location = new System.Drawing.Point(409, 22);
            this.btn_findEmp.Name = "btn_findEmp";
            this.btn_findEmp.Size = new System.Drawing.Size(109, 55);
            this.btn_findEmp.TabIndex = 13;
            this.btn_findEmp.Text = "Find Employee";
            this.btn_findEmp.UseVisualStyleBackColor = true;
            this.btn_findEmp.Click += new System.EventHandler(this.btn_findEmp_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(307, 245);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(96, 34);
            this.btn_update.TabIndex = 14;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // cmb_Empcity
            // 
            this.cmb_Empcity.FormattingEnabled = true;
            this.cmb_Empcity.Location = new System.Drawing.Point(249, 97);
            this.cmb_Empcity.Name = "cmb_Empcity";
            this.cmb_Empcity.Size = new System.Drawing.Size(121, 21);
            this.cmb_Empcity.TabIndex = 15;
            this.cmb_Empcity.Text = "Choose";
            // 
            // Frm_EmpDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 453);
            this.Controls.Add(this.cmb_Empcity);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_findEmp);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_AddEmp);
            this.Controls.Add(this.txt_EmpPass);
            this.Controls.Add(this.txt_EmpAge);
            this.Controls.Add(this.txt_EmpName);
            this.Controls.Add(this.txt_EmpID);
            this.Controls.Add(this.label_EmpPass);
            this.Controls.Add(this.label_EmpAge);
            this.Controls.Add(this.label_EmployeeCity);
            this.Controls.Add(this.label_EmpName);
            this.Controls.Add(this.label_EmpID);
            this.Name = "Frm_EmpDetails";
            this.Text = "Frm_EmpDetails";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_EmpID;
        private System.Windows.Forms.Label label_EmpName;
        private System.Windows.Forms.Label label_EmployeeCity;
        private System.Windows.Forms.Label label_EmpAge;
        private System.Windows.Forms.Label label_EmpPass;
        private System.Windows.Forms.TextBox txt_EmpID;
        private System.Windows.Forms.TextBox txt_EmpName;
        private System.Windows.Forms.TextBox txt_EmpAge;
        private System.Windows.Forms.TextBox txt_EmpPass;
        private System.Windows.Forms.Button btn_AddEmp;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_findEmp;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.ComboBox cmb_Empcity;
    }
}

