﻿namespace Win_ADO1
{
    partial class Frm_disconnected
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_showEmp = new System.Windows.Forms.Button();
            this.dg_employees = new System.Windows.Forms.DataGridView();
            this.btn_SearchEmp = new System.Windows.Forms.Button();
            this.txt_city = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_showEmp
            // 
            this.btn_showEmp.Location = new System.Drawing.Point(58, 12);
            this.btn_showEmp.Name = "btn_showEmp";
            this.btn_showEmp.Size = new System.Drawing.Size(139, 81);
            this.btn_showEmp.TabIndex = 0;
            this.btn_showEmp.Text = "Show Employees";
            this.btn_showEmp.UseVisualStyleBackColor = true;
            this.btn_showEmp.Click += new System.EventHandler(this.btn_showEmp_Click);
            // 
            // dg_employees
            // 
            this.dg_employees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employees.Location = new System.Drawing.Point(12, 99);
            this.dg_employees.Name = "dg_employees";
            this.dg_employees.Size = new System.Drawing.Size(510, 291);
            this.dg_employees.TabIndex = 1;
            // 
            // btn_SearchEmp
            // 
            this.btn_SearchEmp.Location = new System.Drawing.Point(224, 12);
            this.btn_SearchEmp.Name = "btn_SearchEmp";
            this.btn_SearchEmp.Size = new System.Drawing.Size(160, 80);
            this.btn_SearchEmp.TabIndex = 2;
            this.btn_SearchEmp.Text = "Search Employees";
            this.btn_SearchEmp.UseVisualStyleBackColor = true;
            this.btn_SearchEmp.Click += new System.EventHandler(this.btn_SearchEmp_Click);
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(411, 37);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 20);
            this.txt_city.TabIndex = 3;
            // 
            // Frm_disconnected
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 402);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.btn_SearchEmp);
            this.Controls.Add(this.dg_employees);
            this.Controls.Add(this.btn_showEmp);
            this.Name = "Frm_disconnected";
            this.Text = "Frm_disconnected";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_showEmp;
        private System.Windows.Forms.DataGridView dg_employees;
        private System.Windows.Forms.Button btn_SearchEmp;
        private System.Windows.Forms.TextBox txt_city;
    }
}