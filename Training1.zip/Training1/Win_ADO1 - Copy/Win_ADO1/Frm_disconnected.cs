﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Win_ADO1
{
    public partial class Frm_disconnected : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Frm_disconnected()
        {
            InitializeComponent();
        }

        private void btn_showEmp_Click(object sender, EventArgs e)
        {
            
            SqlDataAdapter data = new SqlDataAdapter("select * from employees", con);
            DataSet ds = new DataSet();
            data.Fill(ds, "emp");
            dg_employees.DataSource = ds.Tables["emp"];
        }

        private void btn_SearchEmp_Click(object sender, EventArgs e)
        {
            SqlDataAdapter data_employees = new SqlDataAdapter("Select * from employees where employeecity=@city", con);
            data_employees.SelectCommand.Parameters.AddWithValue("@city", txt_city.Text);
            DataSet ds = new DataSet();
            data_employees.Fill(ds, "emp");
            dg_employees.DataSource = ds.Tables["emp"];
        }
    }
}
