﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO1
{
    public partial class Frm_EmpDetails : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            
        public Frm_EmpDetails()
        {
            InitializeComponent();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            txt_EmpID.Text = "";
            txt_EmpName.Text = "";
           
            txt_EmpAge.Text = "";
            txt_EmpPass.Text = "";
        }

        private void btn_AddEmp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_emp_insert = new SqlCommand("Insert Employees values(@empname,@empcity,@empage,@emppwd)", con);
            com_emp_insert.Parameters.AddWithValue("@empname", txt_EmpName.Text);
            com_emp_insert.Parameters.AddWithValue("@empcity", cmb_Empcity.Text);
            com_emp_insert.Parameters.AddWithValue("@empage", txt_EmpAge.Text);
            com_emp_insert.Parameters.AddWithValue("@emppwd", txt_EmpPass.Text);
            com_emp_insert.ExecuteNonQuery();
            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int empid = Convert.ToInt32(com_empid.ExecuteScalar());
            txt_EmpID.Text = empid.ToString();
            con.Close();
            MessageBox.Show("Employee added succesfully:"+empid);
             
        }

        private void btn_findEmp_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_find_emp = new SqlCommand("Select * from Employees where EmployeeID=@empid", con);
            com_find_emp.Parameters.AddWithValue("@empid", txt_EmpID.Text);
            SqlDataReader dr = com_find_emp.ExecuteReader();
            if (dr.Read())
            {
                txt_EmpID.Text = dr.GetInt32(0).ToString();
                txt_EmpName.Text = dr.GetString(1);
                cmb_Empcity.Text = dr.GetString(2);
                txt_EmpAge.Text = dr.GetInt32(3).ToString();
                txt_EmpPass.Text = dr.GetString(4);
            }
            else { MessageBox.Show("Employee not found"); }
            con.Close();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_update_emp=new SqlCommand("update employees set employeename=@empname,employeecity=@empcity where employeeid=@empid",con);
            com_update_emp.Parameters.AddWithValue("@empname", txt_EmpName.Text);
            com_update_emp.Parameters.AddWithValue("@empcity", cmb_Empcity.Text);
            com_update_emp.Parameters.AddWithValue("@empid", txt_EmpID.Text);

            int rowsaffected = com_update_emp.ExecuteNonQuery();
            con.Close();
            if (rowsaffected > 0)
            {
                MessageBox.Show("Emplyee updated");
            }
            else { MessageBox.Show("Employee not found"); }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
