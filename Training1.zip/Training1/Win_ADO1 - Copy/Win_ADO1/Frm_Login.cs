﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO1
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand com_login = new SqlCommand("Select * from Employees where employeeid=@empid and employeepassword=@emppwd", con);
            com_login.Parameters.AddWithValue("@empid", txt_EmpID.Text);
            com_login.Parameters.AddWithValue("@emppwd", txt_pwd.Text);
            con.Open();
            int count = Convert.ToInt32(com_login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                MessageBox.Show("Valid user");
                Frm_EmpDetails obj = new Frm_EmpDetails();
                obj.Show();
            }
            else {
                MessageBox.Show("Invalid user");
            }

        }
    }
}
