﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Generic
{
    class Test
    {
        public T GetData<T>(T str)
        {
            return str;
        }
    }
}
