﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Console_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> marks = new List<int>();
            marks.Add(80);
            marks.Add(75);
            marks.Add(90);

            foreach (int i in marks)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine(marks.Count());


            /*
             ArrayList list = new ArrayList();
            list.Add("abc");//0
            list.Add(1200);//1
            list.Add(true);//2
            int i = 100;
            list.Add(i);//3      

            int x = Convert.ToInt32(list[1]);
            string str = list[0].ToString();
            bool y = Convert.ToBoolean(list[2]);
            Console.WriteLine(x);
            Console.WriteLine(str);
            Console.WriteLine(y);
            /*
            Test obj = new Test();
            int i = obj.GetData<int>(100);
            string str = obj.GetData<string>("hello");
            Console.WriteLine(i);
            Console.WriteLine(str);
          */
            Console.ReadLine();
        }
    }
}
