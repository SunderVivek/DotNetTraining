﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Company_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            
            String name, city;
            Company com = new Company(2000,"Inautix");
            bool flag = true;
            Employee e;
            while (flag)
            {
                Console.WriteLine("1.Add 2.Remove 3.Find 4.Show 5.Exit 6.CompanyApproval");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        Console.WriteLine("Enter the Empid");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("EmpName:");
                        name = Console.ReadLine();
                        Console.WriteLine("EmpCity:");
                        city = Console.ReadLine();
                        e = new Employee(id,name,city);
                        com.AddEmployee(e);
                        break;
                    case 2:
                        Console.WriteLine("Enter empid:");
                        id = Convert.ToInt32(Console.ReadLine());
                        com.RemoveEmployee(id);
                        break;
                    case 3:
                        Console.WriteLine("Enter empid:");
                        id = Convert.ToInt32(Console.ReadLine());
                        e=com.SearchEmployee(id);
                        if (e == null)
                            Console.WriteLine("Employee not found");
                        else {
                            Console.WriteLine("Enter 1:show 2:Leave Request");
                            int option = Convert.ToInt32(Console.ReadLine());
                            if (option == 1)
                                Console.WriteLine(e.ToString());
                            else {
                                Console.WriteLine("Enter reason");
                                String reason = Console.ReadLine();
                                e.Req_leave(reason);
                            }
                        }
                            
                            break;
                    case 4:
                        com.ShowEmployees();
                        break;
                    case 5:
                        flag = false;
                        break;
                    case 6:
                        com.employee_leave_request_approval();
                        break;
                }
 

            }
        }
    }
}
