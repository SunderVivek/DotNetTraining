﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_Company_Employee
{
    class Company
    {
        int Comapny_ID;
        string CompanyName;
        List<Employee> emplist=new List<Employee>();
        List<Employee> emplist_leave_req = new List<Employee>();
        public Company(int CompanyID, string CompanyName)
        {
            this.Comapny_ID = CompanyID;
            this.CompanyName = CompanyName;

        }
        public void employee_leave_request_approval()
        {
            foreach (Employee e in emplist_leave_req)
            {
                e.leave_approval();
            }
            emplist_leave_req.Clear();
        }
        public void notify(int EmpID, string msg)
        {
            Console.WriteLine("Company:" + EmpID + ":" + msg);
            emplist_leave_req.Add(SearchEmployee(EmpID));
        }
        public void AddEmployee(Employee emp)
        {
            emplist.Add(emp);
            emp.evt_leave_request += new Employee.delleave(notify);
        }
        public bool RemoveEmployee(int EmpID)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpID)
                {
                    emplist.Remove(e);
                }
            }
            return false;
        }
        public Employee SearchEmployee(int EmpId)
        {
            foreach (Employee e in emplist)
            {
                if (e.PEmpID == EmpId)
                {
                    return e;
                }
            }
            return null;
        }

        public void ShowEmployees()
        {
            foreach (Employee e in emplist)
            {
                Console.WriteLine(e.ToString());
            }
        }

    }
}
