﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_DAL_Ticket
{
    class Ticket
    {
        public int ticketnum { get; set; }
        public String MovieName { get; set; }
        public DateTime MovieDate { get;set;}
        public int num_of_tkts { get; set; }
        public string timings { get; set; }
        public DateTime tktdate { get; set; }

       

    }
  }
