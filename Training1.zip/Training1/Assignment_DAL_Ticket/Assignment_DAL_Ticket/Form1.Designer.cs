﻿namespace Assignment_DAL_Ticket
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_MovieName = new System.Windows.Forms.Label();
            this.lbl_MovieDate = new System.Windows.Forms.Label();
            this.dt_picker_moviedate = new System.Windows.Forms.DateTimePicker();
            this.lbl_AccountNum = new System.Windows.Forms.Label();
            this.txt_MovName = new System.Windows.Forms.TextBox();
            this.txt_accountnum = new System.Windows.Forms.TextBox();
            this.lbl_Numoftkts = new System.Windows.Forms.Label();
            this.txt_num_of_tkts = new System.Windows.Forms.TextBox();
            this.btn_Buytkt = new System.Windows.Forms.Button();
            this.lbl_Tkttimings = new System.Windows.Forms.Label();
            this.txt_timings = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_MovieName
            // 
            this.lbl_MovieName.AutoSize = true;
            this.lbl_MovieName.Location = new System.Drawing.Point(93, 18);
            this.lbl_MovieName.Name = "lbl_MovieName";
            this.lbl_MovieName.Size = new System.Drawing.Size(67, 13);
            this.lbl_MovieName.TabIndex = 0;
            this.lbl_MovieName.Text = "Movie Name";
            // 
            // lbl_MovieDate
            // 
            this.lbl_MovieDate.AutoSize = true;
            this.lbl_MovieDate.Location = new System.Drawing.Point(93, 94);
            this.lbl_MovieDate.Name = "lbl_MovieDate";
            this.lbl_MovieDate.Size = new System.Drawing.Size(59, 13);
            this.lbl_MovieDate.TabIndex = 1;
            this.lbl_MovieDate.Text = "MovieDate";
            // 
            // dt_picker_moviedate
            // 
            this.dt_picker_moviedate.Location = new System.Drawing.Point(186, 94);
            this.dt_picker_moviedate.Name = "dt_picker_moviedate";
            this.dt_picker_moviedate.Size = new System.Drawing.Size(200, 20);
            this.dt_picker_moviedate.TabIndex = 2;
            // 
            // lbl_AccountNum
            // 
            this.lbl_AccountNum.AutoSize = true;
            this.lbl_AccountNum.Location = new System.Drawing.Point(96, 142);
            this.lbl_AccountNum.Name = "lbl_AccountNum";
            this.lbl_AccountNum.Size = new System.Drawing.Size(84, 13);
            this.lbl_AccountNum.TabIndex = 3;
            this.lbl_AccountNum.Text = "AccountNumber";
            // 
            // txt_MovName
            // 
            this.txt_MovName.Location = new System.Drawing.Point(186, 18);
            this.txt_MovName.Name = "txt_MovName";
            this.txt_MovName.Size = new System.Drawing.Size(100, 20);
            this.txt_MovName.TabIndex = 4;
            // 
            // txt_accountnum
            // 
            this.txt_accountnum.Location = new System.Drawing.Point(186, 142);
            this.txt_accountnum.Name = "txt_accountnum";
            this.txt_accountnum.Size = new System.Drawing.Size(100, 20);
            this.txt_accountnum.TabIndex = 5;
            // 
            // lbl_Numoftkts
            // 
            this.lbl_Numoftkts.AutoSize = true;
            this.lbl_Numoftkts.Location = new System.Drawing.Point(92, 52);
            this.lbl_Numoftkts.Name = "lbl_Numoftkts";
            this.lbl_Numoftkts.Size = new System.Drawing.Size(88, 13);
            this.lbl_Numoftkts.TabIndex = 6;
            this.lbl_Numoftkts.Text = "NumberofTickets";
            // 
            // txt_num_of_tkts
            // 
            this.txt_num_of_tkts.Location = new System.Drawing.Point(186, 52);
            this.txt_num_of_tkts.Name = "txt_num_of_tkts";
            this.txt_num_of_tkts.Size = new System.Drawing.Size(100, 20);
            this.txt_num_of_tkts.TabIndex = 7;
            // 
            // btn_Buytkt
            // 
            this.btn_Buytkt.Location = new System.Drawing.Point(124, 301);
            this.btn_Buytkt.Name = "btn_Buytkt";
            this.btn_Buytkt.Size = new System.Drawing.Size(107, 56);
            this.btn_Buytkt.TabIndex = 8;
            this.btn_Buytkt.Text = "Buy Ticket";
            this.btn_Buytkt.UseVisualStyleBackColor = true;
            this.btn_Buytkt.Click += new System.EventHandler(this.btn_Buytkt_Click);
            // 
            // lbl_Tkttimings
            // 
            this.lbl_Tkttimings.AutoSize = true;
            this.lbl_Tkttimings.Location = new System.Drawing.Point(99, 185);
            this.lbl_Tkttimings.Name = "lbl_Tkttimings";
            this.lbl_Tkttimings.Size = new System.Drawing.Size(43, 13);
            this.lbl_Tkttimings.TabIndex = 9;
            this.lbl_Tkttimings.Text = "Timings";
            // 
            // txt_timings
            // 
            this.txt_timings.Location = new System.Drawing.Point(186, 182);
            this.txt_timings.Name = "txt_timings";
            this.txt_timings.Size = new System.Drawing.Size(100, 20);
            this.txt_timings.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 427);
            this.Controls.Add(this.txt_timings);
            this.Controls.Add(this.lbl_Tkttimings);
            this.Controls.Add(this.btn_Buytkt);
            this.Controls.Add(this.txt_num_of_tkts);
            this.Controls.Add(this.lbl_Numoftkts);
            this.Controls.Add(this.txt_accountnum);
            this.Controls.Add(this.txt_MovName);
            this.Controls.Add(this.lbl_AccountNum);
            this.Controls.Add(this.dt_picker_moviedate);
            this.Controls.Add(this.lbl_MovieDate);
            this.Controls.Add(this.lbl_MovieName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_MovieName;
        private System.Windows.Forms.Label lbl_MovieDate;
        private System.Windows.Forms.DateTimePicker dt_picker_moviedate;
        private System.Windows.Forms.Label lbl_AccountNum;
        private System.Windows.Forms.TextBox txt_MovName;
        private System.Windows.Forms.TextBox txt_accountnum;
        private System.Windows.Forms.Label lbl_Numoftkts;
        private System.Windows.Forms.TextBox txt_num_of_tkts;
        private System.Windows.Forms.Button btn_Buytkt;
        private System.Windows.Forms.Label lbl_Tkttimings;
        private System.Windows.Forms.TextBox txt_timings;
    }
}

