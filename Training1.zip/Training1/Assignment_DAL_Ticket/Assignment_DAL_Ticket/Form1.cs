﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Assignment_DAL_Ticket
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Buytkt_Click(object sender, EventArgs e)
        {
            Ticket tkt = new Ticket();
            tkt.MovieName = txt_MovName.Text;
            tkt.num_of_tkts = Convert.ToInt32(txt_num_of_tkts.Text);
            tkt.MovieDate = Convert.ToDateTime(dt_picker_moviedate.Text);
            tkt.timings = txt_timings.Text;

            BankTrans bank = new BankTrans();
            bank.AccountNum = Convert.ToInt32(txt_accountnum.Text);
            bank.Amount = tkt.num_of_tkts * 150;
            
                  
            TicketDAL dal = new TicketDAL();
            dal.BuyTicket(bank,tkt);
        

        }
    }
}
