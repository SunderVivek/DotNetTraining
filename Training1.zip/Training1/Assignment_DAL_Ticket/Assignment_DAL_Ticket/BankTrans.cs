﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment_DAL_Ticket
{
    class BankTrans
    {
        public int transid { get; set; }
        public int AccountNum { get; set; }
        public int Amount { get; set; }
        public DateTime TransDate { get; set; }


    }
}
