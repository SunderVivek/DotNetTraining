﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Assignment_DAL_Ticket
{
    class TicketDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public void BuyTicket(BankTrans bank,Ticket tkt)
        {
            con.Open();
            SqlTransaction trans = con.BeginTransaction();
            SqlCommand com_charge_tkt = new SqlCommand("insert Banktransactions values(@Accountnum,@Amount,getDate())",con);
            com_charge_tkt.Parameters.AddWithValue("@Accountnum", bank.AccountNum);
            com_charge_tkt.Parameters.AddWithValue("@Amount", bank.Amount);
            com_charge_tkt.Transaction = trans;
            com_charge_tkt.ExecuteNonQuery();

            SqlCommand com_transid = new SqlCommand("select @@identity", con);
            com_transid.Transaction = trans;
            bank.transid = Convert.ToInt32(com_transid.ExecuteScalar());

            SqlCommand com_book_tkt = new SqlCommand("insert Tickets values(@moviename,@moviedate,@timings,@num_of_tkts,@Transid,getDate())", con);
            com_book_tkt.Parameters.AddWithValue("@moviename", tkt.MovieName);
            com_book_tkt.Parameters.AddWithValue("@moviedate", tkt.MovieDate);
            com_book_tkt.Parameters.AddWithValue("@timings", tkt.timings);
            com_book_tkt.Parameters.AddWithValue("@num_of_tkts", tkt.num_of_tkts);
            com_book_tkt.Parameters.AddWithValue("@Transid", bank.transid);
            com_book_tkt.Transaction = trans;
            com_book_tkt.ExecuteNonQuery();

            SqlCommand com_tktid = new SqlCommand("select @@identity", con);
            com_tktid.Transaction = trans;
            tkt.ticketnum = Convert.ToInt32(com_tktid.ExecuteScalar());


            System.Windows.Forms.MessageBox.Show("Transaction Number:" + bank.transid+"\nTicketNumber:"+tkt.ticketnum+"Amount:"+bank.Amount);
            trans.Commit();
            con.Close();

        }
    }
}
