﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for CustomerDAL
/// </summary>
public class CustomerDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);


    public bool AddCustomer(Customer cust,string Customerpassword,string customeremail,string securityquestion,string securityanswer)
    {

        SqlCommand com_insertcust = new SqlCommand("insert CustomerAsp values(@custname,@custdesg)", con);
        com_insertcust.Parameters.AddWithValue("@custname", cust.CustomerName);
        com_insertcust.Parameters.AddWithValue("@custdesg", cust.CustomerDesignation);
        con.Open();
        com_insertcust.ExecuteNonQuery();

        SqlCommand com_custid = new SqlCommand("select @@identity",con);
        cust.CustomerID = Convert.ToInt32(com_custid.ExecuteScalar());
        
        con.Close();
        MembershipCreateStatus status;
        Membership.CreateUser(cust.CustomerID.ToString(), Customerpassword, customeremail, securityquestion, securityanswer, true, out status);
        if (status == MembershipCreateStatus.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}