﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddl_LoginType.Items.Add("Select");
            ddl_LoginType.Items.Add("Customer");
            ddl_LoginType.Items.Add("Employee");
        }
    }
    protected void btn_Login_Click(object sender, EventArgs e)
    {
        if (Membership.ValidateUser(txt_CustomerID.Text, txt_Password.Text))
        {
            FormsAuthentication.SetAuthCookie(txt_userid.Text, chk_RememberMe.Checked);
            Response.Redirect("~/CustomerHome.aspx");
        }
        


    }
    protected void btn_AddCustomer_Click(object sender, EventArgs e)
    {
        Customer c = new Customer();
        c.CustomerName = txt_CustomerName.Text;
        c.CustomerDesignation = txt_CustomerDesignation.Text;

        CustomerDAL dal = new CustomerDAL();
        if (dal.AddCustomer(c,txt_CustomerPassword.Text , txt_CustomerEmail.Text, txt_SecurityQuestion.Text, txt_SecurityAnswer.Text))
        {
            txt_CustomerID.Text = c.CustomerID.ToString();
            lbl_status.Text = "Customer Created";
        }
        else
        {
            lbl_status.Text = "Check Details";
        }

        
    }
}