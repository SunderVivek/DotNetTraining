﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_day1
{
    class Program
    {
        
        static void Main(string[] args)
        {
          /*  Console.WriteLine("Hai this is sunder buddy , cool!");
            DateTime d = DateTime.Now;
            Console.WriteLine(d.ToShortTimeString());
           
            DateTime d1 = Convert.ToDateTime("12/12/2017");
            DateTime d2 = d1.AddDays(60);
            TimeSpan d3 = d1-d2;
            Console.WriteLine(d2.ToShortDateString());
            Console.WriteLine(d3.ToString());
            Program p= new Program();
            /*for(;p.i<10;p.i++)
            {
                Console.WriteLine(p.i);
            }*/

            int option=Convert.ToInt32(Console.ReadLine());
            switch (option)
            {
                case 1:
                    Console.WriteLine("One");
                    break;
                case 2:
                    Console.WriteLine("Two");
                    break;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
            
            
            }


            
            
            
            Console.ReadLine();

        
        }
    }
}
