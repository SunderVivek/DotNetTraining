﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_Account
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter AccountID:");
                int acc_id=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter CustomerName:");
            String Cust_name=Console.ReadLine();
            Console.WriteLine("Enter account balance");
            int acc_bal=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter type of account");
            String type=Console.ReadLine();
            Account obj;
            if(type=="Saving")
                obj=new Saving(acc_id,Cust_name,acc_bal);
            else
                obj=new Current(acc_id,Cust_name,acc_bal);
            int bal=obj.GetBalance();
            Console.WriteLine("Balance:"+bal);
            obj.Deposit(2500);
            bal = obj.GetBalance();
            Console.WriteLine("Balance:" + bal);
            obj.Withdraw(2000);
                bal = obj.GetBalance();
            Console.WriteLine("Balance:" + bal);
            obj.StopPayment();
            Console.ReadLine();
        }
    }
}
