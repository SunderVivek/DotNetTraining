﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstract_Account
{
    abstract class Account
    {
        protected int AccountID;
        protected string CustomerName;
        protected int AccountBal;

        public Account(int AccountID, string CustomerName, int AccountBal)
        {
            this.AccountID = AccountID;
            this.AccountBal = AccountBal;
            this.CustomerName = CustomerName;
            Console.WriteLine("Account obj created");
        }
        public void StopPayment()
        {
            Console.WriteLine("StopPaymwnt");
        }
        public int GetBalance()
        {
            return AccountBal;
        }
        public void GetStatement()
        {
            Console.WriteLine("Bank Statement");
        }
        public abstract bool Withdraw(int amt);
        public abstract bool Deposit(int amt);
    }
}
