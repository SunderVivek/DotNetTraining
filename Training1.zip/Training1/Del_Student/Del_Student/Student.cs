﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Del_Student
{
    class Student
    {
        String Stud_name;
        int Stud_id;

        public Student(int Stud_id, String Stud_name)
        {
            this.Stud_id = Stud_id;
            this.Stud_name = Stud_name;
        }
    }
}
