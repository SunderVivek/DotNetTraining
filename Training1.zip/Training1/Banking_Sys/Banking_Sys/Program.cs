﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Banking_Sys
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            bool flag = true;
            String Cust_name,Cust_addr,account_type;
            double balance=0,deposit,withdraw;
            Console.WriteLine("\tWelcome to JSV Bank");
            while (flag)
            {
                Console.WriteLine("\n1.Create a New Account");
                Console.WriteLine("2.Deposit to your account");
                Console.WriteLine("3.Withdraw from your account");
                Console.WriteLine("4.Check your balance");
                Console.WriteLine("5.Exit\n\n");
                Console.Write("Enter your choice:");
                choice=Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:     //New Account 
                        Console.Write("\nEnter your Name(Full Name):");
                        Cust_name = Console.ReadLine();

                        Console.Write("\nEnter your address:");
                        Cust_addr = Console.ReadLine();

                        Console.Write("\nËnter type of account:(savings/current):");
                        account_type = Console.ReadLine();

                        Console.Write("\nEnter the Amount:");
                        balance = Convert.ToDouble(Console.ReadLine());

                        while (balance < 1000)
                        {
                            Console.WriteLine("\nMinimum Starting amount is Rs.1000");
                            Console.Write("\nEnter the Amount:");
                            balance = Convert.ToDouble(Console.ReadLine());
                        }

                        break;
                    case 2:     //Deposit
                        Console.Write("\nEnter the amount for deposit:");
                        deposit = Convert.ToDouble(Console.ReadLine());
                        while (deposit < 500)
                        {
                            Console.WriteLine("\nMinimum deposit is Rs.500");
                            Console.Write("\nEnter the amount for deposit:");
                            deposit = Convert.ToDouble(Console.ReadLine());
                         }
                        balance+=deposit;
                        Console.WriteLine("\nAmount Deposited");
                        break;
                    case 3:     //withdraw
                        Console.Write("\nEnter the amount to be withdrawn:");
                        withdraw = Convert.ToDouble(Console.ReadLine());
                        balance -= withdraw;
                        Console.WriteLine("\nAmount Withdrawn");
                        break;
                    case 4:     //Check balance

                        Console.WriteLine("\nYour balance is Rs." + balance);
                        break;

                    case 5:
                        flag = false;
                        break;
                
                
                }
                }
                 
            }

        }
    }

