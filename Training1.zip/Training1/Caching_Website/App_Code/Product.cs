﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Product
/// </summary>
public class Product
{
    public int productid { get; set; }
    public string productname { get; set; }
    public int productprice { get; set; }

}