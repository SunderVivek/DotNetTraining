﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default_DataCaching : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_getproductdetails_Click(object sender, EventArgs e)
    {
        if (Cache["product"] == null)
        {
            //DAL

            Product p = new Product();
            p.productid = 1000;
            p.productname = "Laptop";
            p.productprice = 15000;

    // Absolute Cache.Insert("product", p, null, DateTime.Now.AddSeconds(20), TimeSpan.Zero);
       //                 btn_getproductdetails.Text="Data from DAL";
                Cache.Insert("product", p, null, DateTime.MaxValue, TimeSpan.FromSeconds(20));
                   btn_getproductdetails.Text = "Data from DAL";
        
        lbl_pid.Text = p.productid.ToString();
        lbl_pname.Text = p.productname;
        lbl_pprice.Text = p.productprice.ToString();
    }

        else
        {
            Product p=Cache["product"] as Product;
            btn_getproductdetails.Text="Data from Cache";
            lbl_pid.Text = p.productid.ToString();
            lbl_pname.Text = p.productname;
            lbl_pprice.Text = p.productprice.ToString();
        }
}
}