﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    int orderid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_getorderid_Click(object sender, EventArgs e)
    {
        orderid = Convert.ToInt32(txt_orderid.Text);
        ViewState["oid"] = orderid;

    }
    protected void btn_showorderid_Click(object sender, EventArgs e)
    {
        orderid = Convert.ToInt32(ViewState["oid"]);
        lbl_showorderid.Text = orderid.ToString();
    }
    protected void btn_getorders_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/showdetails.aspx?oid="+txt_orderid.Text+"&cid="+txt_cid.Text);
    }
}