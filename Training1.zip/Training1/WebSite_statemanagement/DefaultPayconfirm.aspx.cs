﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DefaultPayconfirm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        accntvalue.Text = Session["accountid"].ToString();
        amtvalue.Text = Session["amount"].ToString();
    }
    protected void btn_Pay_Click(object sender, EventArgs e)
    {
        lbl_sessionid.Text = Session.SessionID;
    }
}