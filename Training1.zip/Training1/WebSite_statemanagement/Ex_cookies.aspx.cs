﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Ex_cookies : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_createcookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = new HttpCookie("pid",txt_productid.Text);
        c.Expires = Convert.ToDateTime("12/12/2017");
        Response.Cookies.Add(c);

    }
    protected void btn_readcookie_Click(object sender, EventArgs e)
    {
        HttpCookie c = Request.Cookies["pid"];
        lbl_productid.Text = c.Value;
    }
}