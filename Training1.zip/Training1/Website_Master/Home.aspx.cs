﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected override void OnPreInit(EventArgs e)
    {
        this.MasterPageFile = "~/INautix_master.master";
        
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       Label lbl= this.Master.FindControl("lbl_msg") as Label;
       lbl.Text = "Hello from Content Page";
    }
}