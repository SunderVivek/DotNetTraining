﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Program
    {
        static void Main(string[] args)
        {
            Event_testing obj=new Event_testing();
            obj.bind();
            obj.fire();

           // Test t = new Test();
           // t.bind();
            Console.ReadLine();
        }
    }
}
