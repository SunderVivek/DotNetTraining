﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Test
    {
        public delegate void del (string str);
        public void GetData(string msg)
        {
            Console.WriteLine("getdata func:" + msg);
        }
        public void SetData(string str)
        {
            Console.WriteLine("setdata func:" + str);
        }
        public void bind()
        {
            del obj = new del(GetData);
            obj += new del(SetData);
            obj -= new del(GetData);
            obj += delegate(string str)
            {
                Console.WriteLine(str);
            };
            obj("Hello");
        }
    }
}
