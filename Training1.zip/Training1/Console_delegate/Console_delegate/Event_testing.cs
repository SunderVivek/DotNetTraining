﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_delegate
{
    class Event_testing
    {
        public delegate void delevt(string msg);
        public event delevt evt;
        public void fire()
        {
            if (evt != null)
            evt("Hello from event");
        }    
            public void call(string str)
            {
                Console.WriteLine("call "+str);
                
            }
        public void bind()
        {
            delevt obj=new delevt(call);
            this.evt += obj;
        }

            }

    }

