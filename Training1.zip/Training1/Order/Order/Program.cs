﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Order
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int id, qty,choice;
            double price,total;
            String name;
            bool flag = true;
            while (flag)
            {
                Console.Write("Enter name:");
                name = Console.ReadLine();
                Console.Write("\nEnter Item Id:");
                id = Convert.ToInt32(Console.ReadLine());
                Console.Write("\nEnter Price:");
                price = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter the quantity:");
                qty = Convert.ToInt32(Console.ReadLine());

                Order ord = new Order(name,id,price,qty);
                total=ord.getPrice();
                Console.WriteLine("Order_id:"+ord.Porder_id+"\nTotal Price:"+total);
                Console.WriteLine("Do you want to place a new order?\nPress 1 if yes\npress 0 if no");
                choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 0)
                    flag = false;
                
            }
            Console.WriteLine("The No.of orders=" + ord.Porder_id);
            Console.ReadLine();
        }
    } 
}
