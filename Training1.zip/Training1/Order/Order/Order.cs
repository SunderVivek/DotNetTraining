﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Order
{
    class Order
    {
        int Item_id, Item_qty;
        double Item_price, Order_value;
        String Cust_name;
        static int Order_id;
        public int Porder_id
        {
            get {

                return Order_id;
            }
        }
        public Order(int qty,double price)
        {
            this.Item_price = price;
            this.Item_qty = qty;
 
        }
        
        public Order(String name,int id,double price,int qty): this(qty,price)
        {                    
            
            this.Item_id = id;
            this.Cust_name = name;
            ++Order_id;
        }
        public double getPrice()
        {
            this.Order_value = Item_price * Item_qty;
            return Order_value;
        }
    }
}
