﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowEmployees : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_ShowEmployees_Click(object sender, EventArgs e)
    {
        EmployeesDAL dal=new EmployeesDAL();
        gv_EmployeeDetails.DataSource = dal.GetEmployees();
        gv_EmployeeDetails.DataBind();
    }

    protected void gv_EmployeeDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}