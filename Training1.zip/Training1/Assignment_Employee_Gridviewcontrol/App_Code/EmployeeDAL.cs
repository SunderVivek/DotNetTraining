﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


    public class EmployeesDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool login(Employees obj)
        {
            con.Open();
            SqlCommand com_customer_login = new SqlCommand("Select count(*) from employee where EmpID=@empid and EmployeePassword=@emppwd", con);
            com_customer_login.Parameters.AddWithValue("@empid", obj.employee_id);
            com_customer_login.Parameters.AddWithValue("@emppwd", obj.employee_password);
            int count = Convert.ToInt32(com_customer_login.ExecuteScalar());
            con.Close();
            if (count > 0)
                return true;
            else
                return false;
        }
        public bool AddEmployee(Employees obj)
        {
            SqlCommand com_addemp = new SqlCommand("insert employee values(@empname,@empexp,@emppwd,@empdept,@empdsgn,@empmgrid)", con);
            com_addemp.Parameters.AddWithValue("@empname", obj.employee_name);
            com_addemp.Parameters.AddWithValue("@empexp", obj.employee_experience);
            com_addemp.Parameters.AddWithValue("@emppwd", obj.employee_password);
            com_addemp.Parameters.AddWithValue("@empdept", obj.employee_department);
            com_addemp.Parameters.AddWithValue("@empdsgn", obj.employee_designation);
            com_addemp.Parameters.AddWithValue("@empmgrid", obj.managerid);
            con.Open();
            com_addemp.ExecuteNonQuery();
            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int empid = Convert.ToInt32(com_empid.ExecuteScalar());
            obj.employee_id = empid;
            con.Close();
            return true;
        }
        public Employees GetEmployee(int employeeid)
        {
            Employees p = new Employees();
            SqlCommand com_findemployee = new SqlCommand("select * from employee where empid=@empid", con);
            com_findemployee.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_findemployee.ExecuteReader();
            if (dr.Read())
            {
                p.employee_id = dr.GetInt32(0);
                p.employee_name = dr.GetString(1);
                p.employee_experience = dr.GetInt32(2);
                p.employee_department = dr.GetString(4);
                p.employee_designation = dr.GetString(5);
            }
            con.Close();
            return p;
        }

        public List<Employees> GetEmployees()
        {

            List<Employees> EmpList = new List<Employees>();
            SqlCommand com_findemployee = new SqlCommand("select * from employee ", con);
            
            con.Open();
            SqlDataReader dr = com_findemployee.ExecuteReader();
            while (dr.Read())
            {
                Employees p = new Employees();
                p.employee_id = dr.GetInt32(0);
                p.employee_name = dr.GetString(1);
                p.employee_experience = dr.GetInt32(2);
                p.employee_department = dr.GetString(4);
                p.employee_designation = dr.GetString(5);
                EmpList.Add(p);
            }
            con.Close();
            return EmpList;
        }

    }
