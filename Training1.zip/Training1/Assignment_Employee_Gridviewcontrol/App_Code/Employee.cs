﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;


   public  class Employees
    {
        public int employee_id { get; set; }
        public string employee_name { get; set; }
        public int employee_experience { get; set; }
        public string employee_password { get; set; }
        public string employee_department { get; set; }
        public string employee_designation { get; set; }
        public int managerid { get; set; }
    }
