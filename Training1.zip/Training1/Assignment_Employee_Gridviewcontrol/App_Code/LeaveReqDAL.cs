﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

    public  class LeaveRequestDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool Getleavereq(LeaveRequests l)
        {
            SqlCommand com_leaverequest = new SqlCommand("insert leaverequest values(@empid,getdate(),@leavedate,@noofdays,@leavetype,@reason,@leavestatus,@mgrid)", con);
            com_leaverequest.Parameters.AddWithValue("@empid", l.employeeid);
            com_leaverequest.Parameters.AddWithValue("@leavedate", l.leave_date);
            com_leaverequest.Parameters.AddWithValue("@noofdays", l.leave_days);
            com_leaverequest.Parameters.AddWithValue("@leavetype", l.leave_type);
            com_leaverequest.Parameters.AddWithValue("@reason", l.leave_reason);
            com_leaverequest.Parameters.AddWithValue("@leavestatus", l.leave_status);
            com_leaverequest.Parameters.AddWithValue("@mgrid", l.managerid);
            con.Open();
            com_leaverequest.ExecuteNonQuery();

            SqlCommand com_leaveid = new SqlCommand("Select @@identity", con);
            int leaveid = Convert.ToInt32(com_leaveid.ExecuteScalar());
            l.leaveid = leaveid;
            con.Close();
            return true;
        }
        public List<LeaveRequests> GetRequests(int employeeid)
        {
            List<LeaveRequests> requestlist = new List<LeaveRequests>();
            SqlCommand com_requests = new SqlCommand("select * from leaverequest where empid=@empid", con);
            com_requests.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_requests.ExecuteReader();
            while (dr.Read())
            {
                LeaveRequests lev = new LeaveRequests();
                lev.leaveid = dr.GetInt32(0);
                lev.employeeid = dr.GetInt32(1);
                lev.leave_requestdate = dr.GetDateTime(2);
                lev.leave_date = dr.GetDateTime(3);
                lev.leave_days = dr.GetInt32(4);
                lev.leave_type = dr.GetString(5);
                lev.leave_reason = dr.GetString(6);
                lev.leave_status = dr.GetString(7);
                lev.managerid = dr.GetInt32(8);
                requestlist.Add(lev);
            }
            con.Close();
            return requestlist;
        }
    }
