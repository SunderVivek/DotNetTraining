﻿

/// <summary>
/// Summary description for sample
/// </summary>
public class sample
{
	public sample()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}