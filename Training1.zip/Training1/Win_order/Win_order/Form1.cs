﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Win_order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmb_city.Items.Add("Hyderabad");
            cmb_city.Items.Add("Chennai");
            cmb_city.Items.Add("Delhi");
            cmb_city.Items.Add("Mumbai");


        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button_reset_Click(object sender, EventArgs e)
        {
            txt_Orderid.Text = "";
            txt_CustName.Text = "";
            txt_Itemid.Text = "";
            txt_Itemqty.Text = "";
            txt_Itemprice.Text = "";
            txt_addr.Text = "";
            cmb_city.Text="";
            txt_date.Text = "";
            rad_Creditcard.Checked = false;
            rad_Debitcard.Checked = false;
            rad_ondelivery.Checked = false;
            rad_voucher.Checked = false;

        }

        private void button_Placeord_Click(object sender, EventArgs e)
        {
            if (txt_Orderid.Text == "")
                MessageBox.Show("Enter order id");
            else if (txt_CustName.Text == "")
                MessageBox.Show("Enter Customer Name");
            else if (txt_Itemid.Text == "")
                MessageBox.Show("Enter Itemid");
            else if (txt_Itemqty.Text == "")
                MessageBox.Show("Enter Itemqty");
            else if (txt_Itemprice.Text == "")
                MessageBox.Show("Enter ItemPrice");
            else if (txt_addr.Text == "")
                MessageBox.Show("Enter Delivery Addr");
            else if (cmb_city.Text == "city")
                MessageBox.Show("Enter OrderCity");
            else if (txt_date.Text == "")
                MessageBox.Show("Enter Order Date");
            else if (rad_Creditcard.Checked == false && rad_Debitcard.Checked == false && rad_ondelivery.Checked == false && rad_voucher.Checked == false)
                MessageBox.Show("Enter the Payment Option");
            else
            {
                int orderid, itemid, item_qty;
                Double item_price;
                String Cust_name, order_date, Del_addr, order_city, pay_opt = "";

                orderid = Convert.ToInt32(txt_Orderid.Text);
                itemid = Convert.ToInt32(txt_Itemid.Text);
                item_qty = Convert.ToInt32(txt_Itemqty.Text);
                item_price = Convert.ToDouble(txt_Itemprice.Text);
                Cust_name = txt_CustName.Text;
                order_date = txt_date.Text;
                Del_addr = txt_addr.Text;
                order_city = cmb_city.Text;

                if (rad_Creditcard.Checked == true)
                    pay_opt = rad_Creditcard.Text;
                else if (rad_Debitcard.Checked == true)
                    pay_opt = rad_Debitcard.Text;
                else if (rad_ondelivery.Checked == true)
                    pay_opt = rad_ondelivery.Text;
                else if (rad_voucher.Checked == true)
                    pay_opt = rad_voucher.Text;


                Order obj = new Order(orderid, itemid, item_qty, item_price, Cust_name, order_date, Del_addr, order_city, pay_opt);
                MessageBox.Show("The Total price:" + obj.GetOrderValue());
            }
        }
    }
}
