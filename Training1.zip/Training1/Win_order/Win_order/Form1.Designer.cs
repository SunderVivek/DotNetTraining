﻿namespace Win_order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OrderId = new System.Windows.Forms.Label();
            this.CustName = new System.Windows.Forms.Label();
            this.Itemid = new System.Windows.Forms.Label();
            this.ItemQty = new System.Windows.Forms.Label();
            this.ItemPrice = new System.Windows.Forms.Label();
            this.DeliveryAddr = new System.Windows.Forms.Label();
            this.OrderCity = new System.Windows.Forms.Label();
            this.OrderDate = new System.Windows.Forms.Label();
            this.Payment_opt = new System.Windows.Forms.Label();
            this.txt_Orderid = new System.Windows.Forms.TextBox();
            this.txt_CustName = new System.Windows.Forms.TextBox();
            this.txt_Itemid = new System.Windows.Forms.TextBox();
            this.txt_Itemqty = new System.Windows.Forms.TextBox();
            this.txt_Itemprice = new System.Windows.Forms.TextBox();
            this.txt_addr = new System.Windows.Forms.TextBox();
            this.txt_date = new System.Windows.Forms.TextBox();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.rad_Debitcard = new System.Windows.Forms.RadioButton();
            this.rad_Creditcard = new System.Windows.Forms.RadioButton();
            this.rad_ondelivery = new System.Windows.Forms.RadioButton();
            this.rad_voucher = new System.Windows.Forms.RadioButton();
            this.button_Placeord = new System.Windows.Forms.Button();
            this.button_reset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OrderId
            // 
            this.OrderId.AutoSize = true;
            this.OrderId.Location = new System.Drawing.Point(92, 38);
            this.OrderId.Name = "OrderId";
            this.OrderId.Size = new System.Drawing.Size(42, 13);
            this.OrderId.TabIndex = 0;
            this.OrderId.Text = "OrderId";
            // 
            // CustName
            // 
            this.CustName.AutoSize = true;
            this.CustName.Location = new System.Drawing.Point(92, 74);
            this.CustName.Name = "CustName";
            this.CustName.Size = new System.Drawing.Size(56, 13);
            this.CustName.TabIndex = 1;
            this.CustName.Text = "CustName";
            // 
            // Itemid
            // 
            this.Itemid.AutoSize = true;
            this.Itemid.Location = new System.Drawing.Point(92, 98);
            this.Itemid.Name = "Itemid";
            this.Itemid.Size = new System.Drawing.Size(35, 13);
            this.Itemid.TabIndex = 2;
            this.Itemid.Text = "Itemid";
            this.Itemid.Click += new System.EventHandler(this.label3_Click);
            // 
            // ItemQty
            // 
            this.ItemQty.AutoSize = true;
            this.ItemQty.Location = new System.Drawing.Point(92, 126);
            this.ItemQty.Name = "ItemQty";
            this.ItemQty.Size = new System.Drawing.Size(43, 13);
            this.ItemQty.TabIndex = 3;
            this.ItemQty.Text = "ItemQty";
            // 
            // ItemPrice
            // 
            this.ItemPrice.AutoSize = true;
            this.ItemPrice.Location = new System.Drawing.Point(92, 156);
            this.ItemPrice.Name = "ItemPrice";
            this.ItemPrice.Size = new System.Drawing.Size(51, 13);
            this.ItemPrice.TabIndex = 4;
            this.ItemPrice.Text = "ItemPrice";
            // 
            // DeliveryAddr
            // 
            this.DeliveryAddr.AutoSize = true;
            this.DeliveryAddr.Location = new System.Drawing.Point(95, 189);
            this.DeliveryAddr.Name = "DeliveryAddr";
            this.DeliveryAddr.Size = new System.Drawing.Size(70, 13);
            this.DeliveryAddr.TabIndex = 5;
            this.DeliveryAddr.Text = "Delivery Addr";
            // 
            // OrderCity
            // 
            this.OrderCity.AutoSize = true;
            this.OrderCity.Location = new System.Drawing.Point(92, 222);
            this.OrderCity.Name = "OrderCity";
            this.OrderCity.Size = new System.Drawing.Size(50, 13);
            this.OrderCity.TabIndex = 6;
            this.OrderCity.Text = "OrderCity";
            // 
            // OrderDate
            // 
            this.OrderDate.AutoSize = true;
            this.OrderDate.Location = new System.Drawing.Point(92, 249);
            this.OrderDate.Name = "OrderDate";
            this.OrderDate.Size = new System.Drawing.Size(56, 13);
            this.OrderDate.TabIndex = 7;
            this.OrderDate.Text = "OrderDate";
            // 
            // Payment_opt
            // 
            this.Payment_opt.AutoSize = true;
            this.Payment_opt.Location = new System.Drawing.Point(92, 275);
            this.Payment_opt.Name = "Payment_opt";
            this.Payment_opt.Size = new System.Drawing.Size(80, 13);
            this.Payment_opt.TabIndex = 8;
            this.Payment_opt.Text = "Payment option";
            // 
            // txt_Orderid
            // 
            this.txt_Orderid.Location = new System.Drawing.Point(206, 38);
            this.txt_Orderid.Name = "txt_Orderid";
            this.txt_Orderid.Size = new System.Drawing.Size(100, 20);
            this.txt_Orderid.TabIndex = 11;
            // 
            // txt_CustName
            // 
            this.txt_CustName.Location = new System.Drawing.Point(206, 74);
            this.txt_CustName.Name = "txt_CustName";
            this.txt_CustName.Size = new System.Drawing.Size(100, 20);
            this.txt_CustName.TabIndex = 12;
            // 
            // txt_Itemid
            // 
            this.txt_Itemid.Location = new System.Drawing.Point(206, 95);
            this.txt_Itemid.Name = "txt_Itemid";
            this.txt_Itemid.Size = new System.Drawing.Size(100, 20);
            this.txt_Itemid.TabIndex = 13;
            // 
            // txt_Itemqty
            // 
            this.txt_Itemqty.Location = new System.Drawing.Point(206, 126);
            this.txt_Itemqty.Name = "txt_Itemqty";
            this.txt_Itemqty.Size = new System.Drawing.Size(100, 20);
            this.txt_Itemqty.TabIndex = 14;
            // 
            // txt_Itemprice
            // 
            this.txt_Itemprice.Location = new System.Drawing.Point(206, 156);
            this.txt_Itemprice.Name = "txt_Itemprice";
            this.txt_Itemprice.Size = new System.Drawing.Size(100, 20);
            this.txt_Itemprice.TabIndex = 15;
            // 
            // txt_addr
            // 
            this.txt_addr.Location = new System.Drawing.Point(206, 186);
            this.txt_addr.Name = "txt_addr";
            this.txt_addr.Size = new System.Drawing.Size(100, 20);
            this.txt_addr.TabIndex = 16;
            // 
            // txt_date
            // 
            this.txt_date.Location = new System.Drawing.Point(206, 246);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(100, 20);
            this.txt_date.TabIndex = 18;
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(206, 213);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(121, 21);
            this.cmb_city.TabIndex = 22;
            this.cmb_city.Text = "City";
            // 
            // rad_Debitcard
            // 
            this.rad_Debitcard.AutoSize = true;
            this.rad_Debitcard.Location = new System.Drawing.Point(206, 273);
            this.rad_Debitcard.Name = "rad_Debitcard";
            this.rad_Debitcard.Size = new System.Drawing.Size(71, 17);
            this.rad_Debitcard.TabIndex = 23;
            this.rad_Debitcard.TabStop = true;
            this.rad_Debitcard.Text = "Debitcard";
            this.rad_Debitcard.UseVisualStyleBackColor = true;
            // 
            // rad_Creditcard
            // 
            this.rad_Creditcard.AutoSize = true;
            this.rad_Creditcard.Location = new System.Drawing.Point(297, 275);
            this.rad_Creditcard.Name = "rad_Creditcard";
            this.rad_Creditcard.Size = new System.Drawing.Size(73, 17);
            this.rad_Creditcard.TabIndex = 24;
            this.rad_Creditcard.TabStop = true;
            this.rad_Creditcard.Text = "Creditcard";
            this.rad_Creditcard.UseVisualStyleBackColor = true;
            // 
            // rad_ondelivery
            // 
            this.rad_ondelivery.AutoSize = true;
            this.rad_ondelivery.Location = new System.Drawing.Point(396, 275);
            this.rad_ondelivery.Name = "rad_ondelivery";
            this.rad_ondelivery.Size = new System.Drawing.Size(78, 17);
            this.rad_ondelivery.TabIndex = 25;
            this.rad_ondelivery.TabStop = true;
            this.rad_ondelivery.Text = "On delivery";
            this.rad_ondelivery.UseVisualStyleBackColor = true;
            // 
            // rad_voucher
            // 
            this.rad_voucher.AutoSize = true;
            this.rad_voucher.Location = new System.Drawing.Point(480, 275);
            this.rad_voucher.Name = "rad_voucher";
            this.rad_voucher.Size = new System.Drawing.Size(83, 17);
            this.rad_voucher.TabIndex = 26;
            this.rad_voucher.TabStop = true;
            this.rad_voucher.Text = "Gift voucher";
            this.rad_voucher.UseVisualStyleBackColor = true;
            // 
            // button_Placeord
            // 
            this.button_Placeord.Location = new System.Drawing.Point(114, 327);
            this.button_Placeord.Name = "button_Placeord";
            this.button_Placeord.Size = new System.Drawing.Size(75, 23);
            this.button_Placeord.TabIndex = 27;
            this.button_Placeord.Text = "Place order";
            this.button_Placeord.UseVisualStyleBackColor = true;
            this.button_Placeord.Click += new System.EventHandler(this.button_Placeord_Click);
            // 
            // button_reset
            // 
            this.button_reset.Location = new System.Drawing.Point(248, 327);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(75, 23);
            this.button_reset.TabIndex = 28;
            this.button_reset.Text = "Reset";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 506);
            this.Controls.Add(this.button_reset);
            this.Controls.Add(this.button_Placeord);
            this.Controls.Add(this.rad_voucher);
            this.Controls.Add(this.rad_ondelivery);
            this.Controls.Add(this.rad_Creditcard);
            this.Controls.Add(this.rad_Debitcard);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.txt_addr);
            this.Controls.Add(this.txt_Itemprice);
            this.Controls.Add(this.txt_Itemqty);
            this.Controls.Add(this.txt_Itemid);
            this.Controls.Add(this.txt_CustName);
            this.Controls.Add(this.txt_Orderid);
            this.Controls.Add(this.Payment_opt);
            this.Controls.Add(this.OrderDate);
            this.Controls.Add(this.OrderCity);
            this.Controls.Add(this.DeliveryAddr);
            this.Controls.Add(this.ItemPrice);
            this.Controls.Add(this.ItemQty);
            this.Controls.Add(this.Itemid);
            this.Controls.Add(this.CustName);
            this.Controls.Add(this.OrderId);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OrderId;
        private System.Windows.Forms.Label CustName;
        private System.Windows.Forms.Label Itemid;
        private System.Windows.Forms.Label ItemQty;
        private System.Windows.Forms.Label ItemPrice;
        private System.Windows.Forms.Label DeliveryAddr;
        private System.Windows.Forms.Label OrderCity;
        private System.Windows.Forms.Label OrderDate;
        private System.Windows.Forms.Label Payment_opt;
        private System.Windows.Forms.TextBox txt_Orderid;
        private System.Windows.Forms.TextBox txt_CustName;
        private System.Windows.Forms.TextBox txt_Itemid;
        private System.Windows.Forms.TextBox txt_Itemqty;
        private System.Windows.Forms.TextBox txt_Itemprice;
        private System.Windows.Forms.TextBox txt_addr;
        private System.Windows.Forms.TextBox txt_date;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.RadioButton rad_Debitcard;
        private System.Windows.Forms.RadioButton rad_Creditcard;
        private System.Windows.Forms.RadioButton rad_ondelivery;
        private System.Windows.Forms.RadioButton rad_voucher;
        private System.Windows.Forms.Button button_Placeord;
        private System.Windows.Forms.Button button_reset;
    }
}

