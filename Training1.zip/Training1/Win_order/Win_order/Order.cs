﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Win_order
{
    class Order
    {
        int orderid,itemid,item_qty;
        Double item_price;
        String Cust_name, order_date,Del_addr,order_city,pay_opt;
        
      public  Order(int orderid, int itemid, int item_qty, double item_price, String Cust_name, String order_date, String Del_addr, String order_city, String pay_opt)
        {
            this.orderid = orderid;
            this.itemid = itemid;
            this.item_qty = item_qty;
            this.item_price = item_price;
            this.Cust_name = Cust_name;
            this.order_date = order_date;
            this.Del_addr = Del_addr;
            this.order_city = order_city;
            this.pay_opt = pay_opt;
         }

        public double GetOrderValue()
        {
            return item_price*item_qty;
        }
    }
}
