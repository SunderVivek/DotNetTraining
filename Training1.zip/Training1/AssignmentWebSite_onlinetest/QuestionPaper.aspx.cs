﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class QuestionPaper : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_showquestions_Click(object sender, EventArgs e)
    {
        QuestionsDAL dal = new QuestionsDAL();
        dl_Questions.DataSource=dal.GetQuestions();
        dl_Questions.DataBind();
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        QuestionsDAL dal = new QuestionsDAL();
        int result = 0;
        foreach (DataListItem item in dl_Questions.Items)
        {
            int flag = 0;
            RadioButton r1 = item.FindControl("rad_option1") as RadioButton;
            RadioButton r2 = item.FindControl("rad_option2") as RadioButton;
            RadioButton r3 = item.FindControl("rad_option3") as RadioButton;
            RadioButton r4 = item.FindControl("rad_option4") as RadioButton;
            if(r1.Checked)
                {
                    flag = 1;
                }
            else if (r2.Checked)
            {
                flag = 2;
            }
            else if (r3.Checked)
            {
                flag = 3;
            }
            else if (r4.Checked)
            {
                flag = 4;
            }
            Label lbl = item.FindControl("lbl_qid") as Label;
            int qid = Convert.ToInt32(lbl.Text);
            result += dal.GetQuestionAnswer(qid, flag);
        }
        lbl_Result.Text = "Result:" + result;
    }
}