﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for QuestionsDAL
/// </summary>
public class QuestionsDAL
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    public List<Questions> GetQuestions()
   {
       SqlCommand com_getquestions = new SqlCommand("Select questionid,question,option1,option2,option3,option4 from questions", con);
       List<Questions> list_questions = new List<Questions>();
       con.Open();
       SqlDataReader dr = com_getquestions.ExecuteReader();
       while (dr.Read())
       {
           Questions q = new Questions();
           q.questionid = dr.GetInt32(0);
           q.question = dr.GetString(1);
           q.option1 = dr.GetString(2);
           q.option2 = dr.GetString(3);
           q.option3 = dr.GetString(4);
           q.option4 = dr.GetString(5);
           list_questions.Add(q);
       }
        con.Close();
        return list_questions;
    }

    public int GetQuestionAnswer(int qid, int userans)
    {
        SqlCommand com_question_check = new SqlCommand("select count(*) from questions where questionid=@qid and answer=@userans", con);
        com_question_check.Parameters.AddWithValue("@qid", qid);
        com_question_check.Parameters.AddWithValue("@userans", userans);
        con.Open();
        int answer = Convert.ToInt32(com_question_check.ExecuteScalar());
        con.Close();
        return answer;

    }
}