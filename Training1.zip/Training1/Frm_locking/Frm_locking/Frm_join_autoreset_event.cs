﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Frm_locking
{
    public partial class Frm_join_autoreset_event : Form
    {
        public Frm_join_autoreset_event()
        {
            InitializeComponent();
        }
        public void call()
        {
            MessageBox.Show("Call function1");
            wait.Set();
            MessageBox.Show("Call function2");
        }
        AutoResetEvent wait = new AutoResetEvent(false);
        private void btn_join_Click(object sender, EventArgs e)
        {
            Thread th = new Thread(call);
            th.Start();     //DB update
            MessageBox.Show("Main thread1");
            wait.WaitOne();
            //th.Join();      //DB read
            MessageBox.Show("Main thread2");
           

        }
    }
}
