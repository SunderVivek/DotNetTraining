﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Frm_locking
{
    public partial class Frm_locking : Form
    {
        public Frm_locking()
        {
            InitializeComponent();
        }
        int total;
        public void sum()
        {
            
            //int total; lock(this){}
            if (Monitor.TryEnter(this))
            {
                int num1 = Convert.ToInt32(txt_num1.Text);
                int num2 = Convert.ToInt32(txt_num2.Text);
                total = num1 + num2;
                Thread.Sleep(15000);
                MessageBox.Show("Total:" + total);
                Monitor.Exit(this);
            }
            else {
                MessageBox.Show("Object is locked , try after sometime");
                 }
           
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_thread1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(sum);
            th1.Start();
            th1.IsBackground = true;
        }

        private void btn_thread2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(sum);
            th2.Start();
            th2.IsBackground = true;
        }
    }
}
