﻿namespace Frm_locking
{
    partial class Frm_Async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_async = new System.Windows.Forms.Button();
            this.lst_results = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_async
            // 
            this.btn_async.Location = new System.Drawing.Point(55, 12);
            this.btn_async.Name = "btn_async";
            this.btn_async.Size = new System.Drawing.Size(140, 76);
            this.btn_async.TabIndex = 0;
            this.btn_async.Text = "Async Call";
            this.btn_async.UseVisualStyleBackColor = true;
            this.btn_async.Click += new System.EventHandler(this.btn_async_Click);
            // 
            // lst_results
            // 
            this.lst_results.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_results.FormattingEnabled = true;
            this.lst_results.ItemHeight = 22;
            this.lst_results.Location = new System.Drawing.Point(55, 122);
            this.lst_results.Name = "lst_results";
            this.lst_results.Size = new System.Drawing.Size(120, 92);
            this.lst_results.TabIndex = 1;
            // 
            // Frm_Async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lst_results);
            this.Controls.Add(this.btn_async);
            this.Name = "Frm_Async";
            this.Text = "Frm_Async";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_async;
        private System.Windows.Forms.ListBox lst_results;
    }
}