﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Frm_locking
{
    public partial class Frm_Async : Form
    {
        public Frm_Async()
        {
            InitializeComponent();
        }
        public delegate int del_sum(int n1,int n2);
        public int GetSum(int n1, int n2)
        {
            MessageBox.Show("GetSum");
            return n1 + n2;
        }
        public delegate void del();
        public void callback(IAsyncResult res)
        {
            MessageBox.Show("GetSum called succesfully");
            int result = obj.EndInvoke(res);
            //MessageBox.Show("Result:"+res.AsyncState+":" + result);
            del delobj = delegate()
                {
                    lst_results.Items.Add(res.AsyncState + ":" + result);
                };
            this.BeginInvoke(delobj);
        }
        del_sum obj;
        private void btn_async_Click(object sender, EventArgs e)
        {
            obj = new del_sum(GetSum);
            obj.BeginInvoke(100, 200, new AsyncCallback(callback), "100+200");
            obj.BeginInvoke(100, 300, new AsyncCallback(callback), "100+300");
            MessageBox.Show("Main thread");


        }
    }
}
