Create table questions
(
questionid int identity(1000,1) primary key,
question varchar(100),
option1 varchar(100),
option2 varchar(100),
option3 varchar(100),
option4 varchar(100),
answer int
)

insert questions values('Who is better?','Siri','Cortana','Alexa','GoogleAssistant',1)
insert questions values('Which city is the best?','Chennai','Hyderabad','Delhi','Pune',2)
insert questions values('Who is DarthVader?','LukeSkyWalker','Yoda','Obi Wan','Anikan SkyWalker',4)
insert questions values('Which is better?','Physics','Pscycology','Mathematics','Chemistry',3)
insert questions values('Who is the better wrestler??','AJ Styles','Edge','John Cena','Undertaker',1)