﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace wpf_employeeleaveassignment
{
    class LeaveRequests
    {
        public int leaveid { get; set; }
        public int employeeid { get; set; }
        public DateTime leave_requestdate { get; set; }
        public DateTime leave_date { get; set; }
        public int leave_days { get; set; }
        public string leave_type { get; set; }
        public string leave_reason { get; set; }
        public string leave_status { get; set; }
        public int managerid { get; set; }
    }
}
