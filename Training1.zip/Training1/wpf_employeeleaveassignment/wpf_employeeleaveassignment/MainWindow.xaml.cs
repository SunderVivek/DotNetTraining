﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf_employeeleaveassignment
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            EmployeesDAL dal = new EmployeesDAL();
            Employees emp = new Employees();
            emp.employee_id = Convert.ToInt32(txt_username.Text);
            emp.employee_password = txt_password.Password;
            if (dal.login(emp))
            {
                MessageBox.Show("Authorized User");
                App.Current.Properties.Add("empid", txt_username.Text);
                win_home obj = new win_home();
                obj.Show();
                this.Close();
            }
            else
                MessageBox.Show("Unauthorized User");
        }

        private void btn_signup_Click(object sender, RoutedEventArgs e)
        {
            win_addemployee obj = new win_addemployee();
            obj.Show();
        }
    }
}

