﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_employeeleaveassignment
{
    /// <summary>
    /// Interaction logic for win_addemployee.xaml
    /// </summary>
    public partial class win_addemployee : Window
    {
        public win_addemployee()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, RoutedEventArgs e)
        {
            EmployeesDAL dal = new EmployeesDAL();
            Employees l = new Employees();
            l.employee_id  = Convert.ToInt32(App.Current.Properties["empid"]);
            l.employee_name = txt_empname.Text;
            l.employee_experience = Convert.ToInt32(txt_empexp.Text);
            l.employee_designation = txt_empdesignation.Text;
            l.employee_department = txt_empdept.Text;
            l.employee_password = txt_pwd.Password;
            l.managerid = Convert.ToInt32(txt_mgrid.Text);
            dal.AddEmployee(l);
            win_messagefornewemp obj = new win_messagefornewemp();
            obj.Show();
            MessageBox.Show("You are successfully added and your employee id is :" + l.employee_id);
        }
    }
}
