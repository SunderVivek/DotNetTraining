﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace wpf_employeeleaveassignment
{
    class FindEmployeesDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public Employees GetEmployee(int employeeid)
        {
            Employees p = new Employees();
            SqlCommand com_findemployee = new SqlCommand("select * from employee where employeeid=@empid", con);
            com_findemployee.Parameters.AddWithValue("@empid", employeeid);
            con.Open();
            SqlDataReader dr = com_findemployee.ExecuteReader();
            if (dr.Read())
            {
                p.employee_id = dr.GetInt32(0);
                p.employee_name = dr.GetString(1);
                p.employee_experience = dr.GetInt32(2);
                p.employee_department = dr.GetString(4);
                p.employee_designation = dr.GetString(5);
            }
            con.Close();
            return p;
        }
    }
}
