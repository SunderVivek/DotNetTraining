﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace wpf_employeeleaveassignment
{
    class EmployeesDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public bool login(Employees obj)
        {
            con.Open();
            SqlCommand com_customer_login = new SqlCommand("Select count(*) from employee where EmployeeID=@empid and EmployeePassword=@emppwd", con);
            com_customer_login.Parameters.AddWithValue("@empid", obj.employee_id);
            com_customer_login.Parameters.AddWithValue("@emppwd", obj.employee_password);
            int count = Convert.ToInt32(com_customer_login.ExecuteScalar());
            con.Close();
            if (count > 0)
                return true;
            else
                return false;
        }
        public bool AddEmployee(Employees obj)
        {
            SqlCommand com_addemp = new SqlCommand("insert employee values(@empname,@empexp,@emppwd,@empdept,@empdsgn,@empmgrid)",con);
            com_addemp.Parameters.AddWithValue("@empname", obj.employee_name);
            com_addemp.Parameters.AddWithValue("@empexp", obj.employee_experience);
            com_addemp.Parameters.AddWithValue("@emppwd", obj.employee_password);
            com_addemp.Parameters.AddWithValue("@empdept", obj.employee_department);
            com_addemp.Parameters.AddWithValue("@empdsgn", obj.employee_designation);
            com_addemp.Parameters.AddWithValue("@empmgrid", obj.managerid);
            con.Open();
            com_addemp.ExecuteNonQuery();
            SqlCommand com_empid = new SqlCommand("Select @@identity", con);
            int empid = Convert.ToInt32(com_empid.ExecuteScalar());
            obj.employee_id = empid;
            con.Close();
            return true;
        }
    }
}