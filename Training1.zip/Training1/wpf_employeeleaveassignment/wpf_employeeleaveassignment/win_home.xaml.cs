﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_employeeleaveassignment
{
    /// <summary>
    /// Interaction logic for win_home.xaml
    /// </summary>
    public partial class win_home : Window
    {
        public win_home()
        {
            InitializeComponent();
        }

        private void btn_findemp_Click(object sender, RoutedEventArgs e)
        {
            win_findemployee obj = new win_findemployee();
            obj.Show();
        }

        private void btn_reqleave_Click(object sender, RoutedEventArgs e)
        {
            win_leaverequest obj = new win_leaverequest();
            obj.Show();
        }

        private void btn_showleaves_Click(object sender, RoutedEventArgs e)
        {
            win_showrequests obj = new win_showrequests();
            obj.Show();
        }

        private void btn_logout_Click(object sender, RoutedEventArgs e)
        {
            win_final obj = new win_final();
            obj.Show();
        }
    }
}
