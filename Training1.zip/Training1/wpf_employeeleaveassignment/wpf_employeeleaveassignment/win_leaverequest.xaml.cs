﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpf_employeeleaveassignment
{
    /// <summary>
    /// Interaction logic for win_leaverequest.xaml
    /// </summary>
    public partial class win_leaverequest : Window
    {
        public win_leaverequest()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_days.Items.Add("1");
            txt_days.Items.Add("2");
            txt_days.Items.Add("3");
            txt_days.Items.Add("4");
            txt_days.Items.Add("5");
            txt_days.Items.Add(">5");
            txt_type.Items.Add("Medical");
            txt_type.Items.Add("Function");
            txt_type.Items.Add("Casual");
            txt_type.Items.Add("On-Duty");
            txt_type.Items.Add("Emergency");
            txt_empid.Text = App.Current.Properties["empid"].ToString();
        }

        private void btn_apply_Click(object sender, RoutedEventArgs e)
        {
            LeaveRequestDAL dal = new LeaveRequestDAL();
            LeaveRequests l = new LeaveRequests();
            l.employeeid = Convert.ToInt32(App.Current.Properties["empid"]);
            l.leave_date = Convert.ToDateTime(txt_leavedate.Text);
            l.leave_days = Convert.ToInt32(txt_days.Text);
            l.leave_reason = txt_reason.Text;
            l.leave_status = txt_status.Text;
            l.leave_type = txt_type.Text;
            l.managerid = Convert.ToInt32(txt_mgrid.Text);
            dal.Getleavereq(l);
            MessageBox.Show("Your leave request was applied successfully and your leave request id is :" + l.leaveid);
        }

        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            txt_leavedate.Text = "";
            txt_mgrid.Text = "";
            txt_reason.Text = "";
            txt_status.Text = "";
            txt_days.Text = "";
            txt_type.Text = "";
        }
    }
}