﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_Assignment_Employee
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public String EmployeeName { get; set; }
        public int EmployeeExperience { get; set; }
        public String EmployeePassword { get; set; }
        public String EmployeeDept { get; set; }
        public String EmployeeDesignation { get; set; }
        public int ManagerID { get; set; }

    }
}
