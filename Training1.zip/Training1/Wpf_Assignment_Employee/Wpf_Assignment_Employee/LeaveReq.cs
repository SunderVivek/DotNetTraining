﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Wpf_Assignment_Employee
{
    class LeaveReq
    {
        public int LeaveID { get; set; }
        public int EmployeeID { get; set; }
        public DateTime LeaveRequestDate { get; set; }
        public DateTime LeaveDate { get; set; }
        public int Num_of_days { get; set; }
        public String Leavetype { get; set; }
        public String LeaveStatus { get; set; }
        public String Reason { get; set; }
        public String ManagerID { get; set; }

    }
}
