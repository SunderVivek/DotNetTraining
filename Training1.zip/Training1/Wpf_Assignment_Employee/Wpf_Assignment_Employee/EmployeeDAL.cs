﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;

namespace Wpf_Assignment_Employee
{
    class EmployeeDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public void AddEmployee(Employee emp)
        {
            SqlCommand com_insertemp = new SqlCommand("insert Employee values(@empname,@empexp,@emppwd,@empdept,@empdesignation,@managerid)",con);
            com_insertemp.Parameters.AddWithValue("@empname", emp.EmployeeName);
            com_insertemp.Parameters.AddWithValue("@empexp", emp.EmployeeExperience);
            com_insertemp.Parameters.AddWithValue("@emppwd", emp.EmployeePassword);
            com_insertemp.Parameters.AddWithValue("@empdept", emp.EmployeeDept);
            com_insertemp.Parameters.AddWithValue("@empdesignation", emp.EmployeeDesignation);
            com_insertemp.Parameters.AddWithValue("@managerid", emp.ManagerID);
            con.Open();
            com_insertemp.ExecuteNonQuery();

            SqlCommand com_empid=new SqlCommand("select @@identity");
            emp.EmployeeID = Convert.ToInt32(com_empid.ExecuteScalar());

            System.Windows.MessageBox.Show("Employee Added.ID=" + emp.EmployeeID);
            con.Close();
        }

        public Employee FindEmployee(int empid)
        {
            SqlCommand com_findemployee = new SqlCommand("Select * from Employee where EmpID=@empid",con);
            com_findemployee.Parameters.AddWithValue("@empid", empid);
            con.Open();
            SqlDataReader dr = com_findemployee.ExecuteReader();
            Employee emp = new Employee();
            if (dr.Read())
            {
                emp.EmployeeID = dr.GetInt32(0);
                emp.EmployeeName = dr.GetString(1);
                emp.EmployeeExperience = dr.GetInt32(2);
                emp.EmployeePassword = dr.GetString(3);
                emp.EmployeeDept = dr.GetString(4);
                emp.EmployeeDesignation = dr.GetString(5);
                emp.ManagerID = dr.GetInt32(6);
            }
            else 
            {
                emp = null;
                System.Windows.MessageBox.Show("Employee not found");
            }
            return emp;
        }

    }
}
