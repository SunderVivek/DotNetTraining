﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_Assignment_Employee
{
    /// <summary>
    /// Interaction logic for Win_NewEmployee.xaml
    /// </summary>
    public partial class Win_NewEmployee : Window
    {
        public Win_NewEmployee()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            emp.EmployeeName = txt_EmployeeName.Text;
            emp.EmployeePassword = txt_employeepassword.Password;
            emp.EmployeeExperience = Convert.ToInt32(txt_empexperience.Text);
            emp.EmployeeDept = txt_empdept.Text;
            emp.EmployeeDesignation = txt_designation.Text;
            emp.ManagerID = Convert.ToInt32(txt_managerid.Text);

            EmployeeDAL dal = new EmployeeDAL();
            dal.AddEmployee(emp);

        }
    }
}
