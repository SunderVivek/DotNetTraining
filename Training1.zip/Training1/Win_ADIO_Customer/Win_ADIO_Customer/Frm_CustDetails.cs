﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADIO_Customer
{
    public partial class Frm_CustDetails : Form
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public Frm_CustDetails()
        {
            InitializeComponent();
        }

        private void btn_AddCust_Click(object sender, EventArgs e)
        {
            SqlCommand cmd_addCust = new SqlCommand("insert Customers values(@custname,@custcity,@custage,getDate())", con);
            cmd_addCust.Parameters.AddWithValue("@custname", txt_Custname.Text);
            cmd_addCust.Parameters.AddWithValue("@custcity", cmb_City.Text);
            cmd_addCust.Parameters.AddWithValue("@custage", txt_age.Text);
           // cmd_addCust.Parameters.AddWithValue("@custdoj", txt_DOJ.Text);
            con.Open();
            cmd_addCust.ExecuteNonQuery();
           SqlCommand com_custid = new SqlCommand("select @@identity", con);
           int custid = Convert.ToInt32(com_custid.ExecuteScalar());
           txt_CustID.Text = custid.ToString();
         
            con.Close();
            MessageBox.Show("Customer added\nCustomerID:"+custid);
        }

        private void Frm_CustDetails_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand com_cities = new SqlCommand("Select cityname from cities", con);
            SqlDataReader dr = com_cities.ExecuteReader();
            while (dr.Read())
            {
                cmb_City.Items.Add(dr.GetString(0));
            }
            con.Close();
        }

        
    }
}
