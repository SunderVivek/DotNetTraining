﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADIO_Customer
{
    public partial class Form1 : Form
    {
      
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
            SqlCommand cmd_Login = new SqlCommand("Select * from employees where employeeid=@empid and employeepassword=@emppwd", con);
            cmd_Login.Parameters.AddWithValue("@empid", txt_EmpID.Text);
            cmd_Login.Parameters.AddWithValue("@emppwd", txt_pwd.Text);
            con.Open();
            int count = Convert.ToInt32(cmd_Login.ExecuteScalar());
            con.Close();
            if (count > 0)
            {
                MessageBox.Show("Valid user");
                Frm_CustDetails obj = new Frm_CustDetails();
                obj.Show();
            }
            else
            {
                MessageBox.Show("Invalid user");
            }

        }
    }
}
