﻿namespace Win_ADIO_Customer
{
    partial class Frm_CustDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_AddCust = new System.Windows.Forms.Button();
            this.txt_CustID = new System.Windows.Forms.TextBox();
            this.txt_Custname = new System.Windows.Forms.TextBox();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.cmb_City = new System.Windows.Forms.ComboBox();
            this.txt_DOJ = new System.Windows.Forms.TextBox();
            this.lbl_Custname = new System.Windows.Forms.Label();
            this.lbl_Custid = new System.Windows.Forms.Label();
            this.lbl_Custcity = new System.Windows.Forms.Label();
            this.lbl_age = new System.Windows.Forms.Label();
            this.lbl_DOJ = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_AddCust
            // 
            this.btn_AddCust.Location = new System.Drawing.Point(98, 332);
            this.btn_AddCust.Name = "btn_AddCust";
            this.btn_AddCust.Size = new System.Drawing.Size(96, 39);
            this.btn_AddCust.TabIndex = 0;
            this.btn_AddCust.Text = "AddCustomer";
            this.btn_AddCust.UseVisualStyleBackColor = true;
            this.btn_AddCust.Click += new System.EventHandler(this.btn_AddCust_Click);
            // 
            // txt_CustID
            // 
            this.txt_CustID.Location = new System.Drawing.Point(320, 39);
            this.txt_CustID.Name = "txt_CustID";
            this.txt_CustID.Size = new System.Drawing.Size(100, 20);
            this.txt_CustID.TabIndex = 1;
            // 
            // txt_Custname
            // 
            this.txt_Custname.Location = new System.Drawing.Point(320, 103);
            this.txt_Custname.Name = "txt_Custname";
            this.txt_Custname.Size = new System.Drawing.Size(100, 20);
            this.txt_Custname.TabIndex = 2;
            // 
            // txt_age
            // 
            this.txt_age.Location = new System.Drawing.Point(320, 212);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(100, 20);
            this.txt_age.TabIndex = 3;
            // 
            // cmb_City
            // 
            this.cmb_City.FormattingEnabled = true;
            this.cmb_City.Location = new System.Drawing.Point(320, 145);
            this.cmb_City.Name = "cmb_City";
            this.cmb_City.Size = new System.Drawing.Size(121, 21);
            this.cmb_City.TabIndex = 4;
            this.cmb_City.Text = "choose";
            // 
            // txt_DOJ
            // 
            this.txt_DOJ.Location = new System.Drawing.Point(320, 258);
            this.txt_DOJ.Name = "txt_DOJ";
            this.txt_DOJ.Size = new System.Drawing.Size(100, 20);
            this.txt_DOJ.TabIndex = 5;
            // 
            // lbl_Custname
            // 
            this.lbl_Custname.AutoSize = true;
            this.lbl_Custname.Location = new System.Drawing.Point(138, 103);
            this.lbl_Custname.Name = "lbl_Custname";
            this.lbl_Custname.Size = new System.Drawing.Size(56, 13);
            this.lbl_Custname.TabIndex = 6;
            this.lbl_Custname.Text = "CustName";
            // 
            // lbl_Custid
            // 
            this.lbl_Custid.AutoSize = true;
            this.lbl_Custid.Location = new System.Drawing.Point(138, 42);
            this.lbl_Custid.Name = "lbl_Custid";
            this.lbl_Custid.Size = new System.Drawing.Size(39, 13);
            this.lbl_Custid.TabIndex = 7;
            this.lbl_Custid.Text = "CustID";
            // 
            // lbl_Custcity
            // 
            this.lbl_Custcity.AutoSize = true;
            this.lbl_Custcity.Location = new System.Drawing.Point(138, 153);
            this.lbl_Custcity.Name = "lbl_Custcity";
            this.lbl_Custcity.Size = new System.Drawing.Size(24, 13);
            this.lbl_Custcity.TabIndex = 8;
            this.lbl_Custcity.Text = "City";
            // 
            // lbl_age
            // 
            this.lbl_age.AutoSize = true;
            this.lbl_age.Location = new System.Drawing.Point(138, 219);
            this.lbl_age.Name = "lbl_age";
            this.lbl_age.Size = new System.Drawing.Size(26, 13);
            this.lbl_age.TabIndex = 9;
            this.lbl_age.Text = "Age";
            // 
            // lbl_DOJ
            // 
            this.lbl_DOJ.AutoSize = true;
            this.lbl_DOJ.Location = new System.Drawing.Point(138, 261);
            this.lbl_DOJ.Name = "lbl_DOJ";
            this.lbl_DOJ.Size = new System.Drawing.Size(75, 13);
            this.lbl_DOJ.TabIndex = 10;
            this.lbl_DOJ.Text = "Date of joining";
            // 
            // Frm_CustDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(501, 420);
            this.Controls.Add(this.lbl_DOJ);
            this.Controls.Add(this.lbl_age);
            this.Controls.Add(this.lbl_Custcity);
            this.Controls.Add(this.lbl_Custid);
            this.Controls.Add(this.lbl_Custname);
            this.Controls.Add(this.txt_DOJ);
            this.Controls.Add(this.cmb_City);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.txt_Custname);
            this.Controls.Add(this.txt_CustID);
            this.Controls.Add(this.btn_AddCust);
            this.Name = "Frm_CustDetails";
            this.Text = "Frm_CustDetails";
            this.Load += new System.EventHandler(this.Frm_CustDetails_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_AddCust;
        private System.Windows.Forms.TextBox txt_CustID;
        private System.Windows.Forms.TextBox txt_Custname;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.ComboBox cmb_City;
        private System.Windows.Forms.TextBox txt_DOJ;
        private System.Windows.Forms.Label lbl_Custname;
        private System.Windows.Forms.Label lbl_Custid;
        private System.Windows.Forms.Label lbl_Custcity;
        private System.Windows.Forms.Label lbl_age;
        private System.Windows.Forms.Label lbl_DOJ;
    }
}