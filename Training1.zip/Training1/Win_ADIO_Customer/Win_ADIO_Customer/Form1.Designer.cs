﻿namespace Win_ADIO_Customer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_EmpID = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.lbl_EmpID = new System.Windows.Forms.Label();
            this.lbl_Emppwd = new System.Windows.Forms.Label();
            this.btn_Login = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_EmpID
            // 
            this.txt_EmpID.Location = new System.Drawing.Point(305, 38);
            this.txt_EmpID.Name = "txt_EmpID";
            this.txt_EmpID.Size = new System.Drawing.Size(100, 20);
            this.txt_EmpID.TabIndex = 0;
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(305, 116);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.PasswordChar = '*';
            this.txt_pwd.Size = new System.Drawing.Size(100, 20);
            this.txt_pwd.TabIndex = 1;
            // 
            // lbl_EmpID
            // 
            this.lbl_EmpID.AutoSize = true;
            this.lbl_EmpID.Location = new System.Drawing.Point(80, 41);
            this.lbl_EmpID.Name = "lbl_EmpID";
            this.lbl_EmpID.Size = new System.Drawing.Size(39, 13);
            this.lbl_EmpID.TabIndex = 2;
            this.lbl_EmpID.Text = "EmpID";
            // 
            // lbl_Emppwd
            // 
            this.lbl_Emppwd.AutoSize = true;
            this.lbl_Emppwd.Location = new System.Drawing.Point(80, 123);
            this.lbl_Emppwd.Name = "lbl_Emppwd";
            this.lbl_Emppwd.Size = new System.Drawing.Size(48, 13);
            this.lbl_Emppwd.TabIndex = 3;
            this.lbl_Emppwd.Text = "Emppwd";
            // 
            // btn_Login
            // 
            this.btn_Login.Location = new System.Drawing.Point(52, 192);
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Size = new System.Drawing.Size(124, 60);
            this.btn_Login.TabIndex = 4;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 362);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.lbl_Emppwd);
            this.Controls.Add(this.lbl_EmpID);
            this.Controls.Add(this.txt_pwd);
            this.Controls.Add(this.txt_EmpID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_EmpID;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.Label lbl_EmpID;
        private System.Windows.Forms.Label lbl_Emppwd;
        private System.Windows.Forms.Button btn_Login;
    }
}

