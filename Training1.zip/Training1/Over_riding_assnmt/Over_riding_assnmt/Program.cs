﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding_assnmt
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name:");
            String name = Console.ReadLine();
            Console.WriteLine("Enter price:");
            double price=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter qty");
            int qty = Convert.ToInt32(Console.ReadLine());
            Order or;
            Console.WriteLine("Enter what order:");
            String ord = Console.ReadLine();
            if (ord == "seas")
                or = new Order_overseas(id, qty, name, price);
            else
                or = new Order(id, qty, name, price);
            Console.WriteLine(or.getorderamount());
            Console.ReadLine();


        }
    }
}
