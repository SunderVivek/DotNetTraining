﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding_assnmt
{
    class Order_overseas:Order
    {
       public Order_overseas(int order_id, int item_qty, String Cust_Name,double item_price):base(order_id,item_qty,Cust_Name,item_price)
        {
            
         }
       public override double getorderamount()
       {
           double tot=item_qty * item_price;
           return tot + tot * 15 / 100;
       }
    }
}
