﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Over_riding_assnmt
{
    class Order
    {
        protected int order_id, item_qty;
        protected double item_price;
        protected String Cust_Name;
        public Order(int order_id, int item_qty, String Cust_Name,double item_price)
        {
            this.order_id = order_id;
            this.item_qty = item_qty;
            this.Cust_Name = Cust_Name;
            this.item_price = item_price;
         }
        public virtual double getorderamount()
        {
            return item_qty * item_price;
        }
    }
}
