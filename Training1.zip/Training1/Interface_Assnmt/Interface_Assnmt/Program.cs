﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface_Assnmt
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
