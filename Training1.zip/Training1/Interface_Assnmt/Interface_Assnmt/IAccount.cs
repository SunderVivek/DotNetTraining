﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface_Assnmt
{
    interface IAccount
    {
        int GetSal();
        int GetEmpid();
        int GetAcc_num();
    }
}
