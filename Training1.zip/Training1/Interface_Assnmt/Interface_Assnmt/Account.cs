﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface_Assnmt
{
    class Account
    {
        public void GetSal(IAccount obj)
        {
            obj.GetSal();
        }
        public void GetAcc_num(IAccount obj)
        {
            obj.GetAcc_num();
        }
        public void GetEmpid(IAccount obj)
        {
            obj.GetEmpid();        
        }
    }
}
