﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface_Assnmt
{
    class HR
    {
        public void GetEmp_Address(IHR obj)
        {
            obj.GetEmpAddress();
        }
        public void GetSal(IHR obj)
        {
            obj.GetSal();
        }
        public void GetEmpid(IHR obj)
        {
            obj.GetEmpid();
        }
    }
}
