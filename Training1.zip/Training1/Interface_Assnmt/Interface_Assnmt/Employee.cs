﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface_Assnmt
{
    class Employee:IHR,IAccount
    {
        int id,exp,accnt_num,age,salary;
        String name,city,addr,proj_det,bank_name;

        public Employee(string name, string city, string addr, string proj_det, string bank_name, int id, int exp, int accnt_num, int age, int salary)
        {
            this.name=name;
            this.city=city;
            this.addr=addr;
            this.proj_det=proj_det;
            this.bank_name=bank_name;
            this.id=id;
            this.exp=exp;
            this.accnt_num=accnt_num;
            this.age = age;
            this.salary = salary;
        }



        #region IHR Members

        public string GetEmpAddress()
        {
            return addr;
            throw new NotImplementedException();
        }

        public int GetSal()
        {
            return salary;
            throw new NotImplementedException();
        }

        public int GetEmpid()
        {
            return id;
            throw new NotImplementedException();
        }

        #endregion

        #region IAccount Members


        public int GetAcc_num()
        {
            return accnt_num;
            throw new NotImplementedException();
        }

        #endregion
    }
}
