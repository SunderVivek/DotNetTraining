﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_firstApplication
{
    /// <summary>
    /// Interaction logic for Win_controls.xaml
    /// </summary>
    public partial class Win_controls : Window
    {
        public Win_controls()
        {
            InitializeComponent();
        }

        private void s1_number_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
           if (s1_number.Value != null && txt_number!=null)
            {
                txt_number.Text = s1_number.Value.ToString();
            }
        }
    }
}
