﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Wpf_firstApplication
{
    /// <summary>
    /// Interaction logic for Wpf_cust.xaml
    /// </summary>
    public partial class Wpf_cust : Window
    {
        public Wpf_cust()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txt_CustomerID.Text = App.Current.Properties["user_id"].ToString();
        }

        
    }
}
