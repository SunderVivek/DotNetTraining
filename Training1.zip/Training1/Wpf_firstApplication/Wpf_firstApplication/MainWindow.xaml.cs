﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_firstApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (txt_loginid.Text == "user1"
                && txt_password.Password == "pass@123")
            {
                MessageBox.Show("Valid user");
                App.Current.Properties.Add("user_id", txt_loginid.Text);
                Wpf_cust obj = new Wpf_cust();
                obj.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid User");

            }
        }
    }
}
