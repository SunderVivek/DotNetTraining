Create database InautixASPNET
use InautixASPNET

Create table CustomerAsp
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(20),
CustomerDesignation varchar(20)
)

select * from CustomerAsp