﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day_2
{
    class Student
    {
        int Stud_id,Stud_marks;
        public int PStud_marks
        {
            get {
                return Stud_marks;

            }
            set {
                if (value < 0 || value > 100)
                    this.PStud_marks=0;
                else
                    this.Stud_marks = value;
                if (Stud_marks < 50)
                    Stud_status = false;
                else
                    Stud_status = true;
            }
        }
        bool Stud_status;
        String Stud_name;


        public Student(int Stud_id, String Stud_name)
        {
            this.Stud_id = Stud_id;
            this.Stud_name = Stud_name;
        
        }
        public Student(int Stud_id)
    {
        this.Stud_id = Stud_id;
            //db code
        this.Stud_name = "abcde";
        this.Stud_marks = 70;
    }


    }
}
