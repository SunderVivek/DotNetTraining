﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Day_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s=new Student(37,"xyz");
            Console.WriteLine(s.PStud_id);
            s.PStud_id = 71;
            Console.WriteLine(s.PStud_id);
            
            
            
            Console.ReadLine();
        }
    }
}
