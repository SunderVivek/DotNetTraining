﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    class Program
    {
        static void Main(string[] args)
        {
            using (XYZ obj = new XYZ())
            { }
          /*  int i = 0;
            while (i < 5)
            {
                Test obj = new Test();
                if (i == 3)
                    GC.SuppressFinalize(obj);
                obj = null;
                i++;
            }
            GC.Collect();
            */
            
            Console.ReadLine();
        }
    }
}
