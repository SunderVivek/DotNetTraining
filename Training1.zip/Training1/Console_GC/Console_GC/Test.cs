﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console_GC
{
    class Test
    {
        public Test()
        {
            Console.WriteLine("Constructer called");

        }
        ~Test()
        {
            Console.WriteLine("Destructer called");
           
        }
    }
}
